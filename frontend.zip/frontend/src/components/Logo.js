export const Logo = ({ className = "w-9 h-9" }) => (
  <svg 
    viewBox="0 0 200 200" 
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6"/>
        <stop offset="100%" stopColor="#1d4ed8"/>
      </linearGradient>
    </defs>
    
    {/* Rounded Square Background */}
    <rect x="15" y="15" width="170" height="170" rx="40" fill="url(#logoGrad)"/>
    
    {/* W Letter */}
    <path 
      d="M50 60 L70 140 L100 85 L130 140 L150 60" 
      fill="none" 
      stroke="#ffffff" 
      strokeWidth="12" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
    
    {/* Subtle circle accent */}
    <circle cx="100" cy="100" r="70" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.2"/>
  </svg>
);

export default Logo;
