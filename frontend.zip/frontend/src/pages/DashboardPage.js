import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { domainsApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { 
  Globe, Plus, LogOut, CheckCircle2, XCircle, 
  ExternalLink, Trash2, Edit, Loader2, Search,
  FileText, File, Tag, Users, Settings, Sparkles, UsersRound,
  Filter, ArrowUpDown, Book
} from 'lucide-react';
import Logo from '../components/Logo';

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const [domains, setDomains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editDomain, setEditDomain] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all'); // all, connected, disconnected
  const [sortBy, setSortBy] = useState('newest'); // newest, oldest, a-z, z-a
  const [itemsPerPage, setItemsPerPage] = useState('10'); // 10, 20, 50, 100, all

  useEffect(() => {
    fetchDomains();
  }, []);

  const fetchDomains = async () => {
    try {
      const response = await domainsApi.list();
      setDomains(response.data);
    } catch (error) {
      toast.error('Failed to load domains');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Are you sure you want to delete "${name}"?`)) return;

    try {
      await domainsApi.delete(id);
      toast.success('Domain deleted successfully');
      fetchDomains();
    } catch (error) {
      toast.error('Failed to delete domain');
    }
  };

  // Filter and sort domains
  const filteredDomains = domains
    .filter(d => {
      // Search filter
      const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           d.url.toLowerCase().includes(searchQuery.toLowerCase());
      // Status filter
      const matchesStatus = filterStatus === 'all' ||
                           (filterStatus === 'connected' && d.is_connected) ||
                           (filterStatus === 'disconnected' && !d.is_connected);
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at || 0) - new Date(a.created_at || 0);
        case 'oldest':
          return new Date(a.created_at || 0) - new Date(b.created_at || 0);
        case 'a-z':
          return a.name.localeCompare(b.name);
        case 'z-a':
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });

  // Apply pagination
  const displayedDomains = itemsPerPage === 'all' 
    ? filteredDomains 
    : filteredDomains.slice(0, parseInt(itemsPerPage));

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Logo className="w-9 h-9 rounded-lg" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-zinc-400 mr-2">
                {user?.name}
              </span>
              <Button
                size="sm"
                asChild
                className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white"
              >
                <Link to="/auto-post" data-testid="auto-post-btn">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Auto Post
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                asChild
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <Link to="/team" data-testid="team-btn">
                  <UsersRound className="w-4 h-4 mr-2" />
                  Team
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                asChild
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <Link to="/docs" data-testid="docs-btn">
                  <Book className="w-4 h-4 mr-2" />
                  Docs
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                asChild
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <Link to="/settings" data-testid="settings-btn">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                data-testid="logout-btn"
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-zinc-400 mt-1">Manage your WordPress sites</p>
          </div>

          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button 
                className="bg-indigo-500 hover:bg-indigo-600 text-white btn-primary-glow"
                data-testid="add-domain-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Domain
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
              <DialogHeader>
                <DialogTitle>Add New Domain</DialogTitle>
              </DialogHeader>
              <DomainForm
                onSuccess={() => {
                  setShowAddDialog(false);
                  fetchDomains();
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Search, Filter & Sort */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <Input
              placeholder="Search domains..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="search-domains-input"
              className="pl-10 bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:border-indigo-500"
            />
          </div>
          
          {/* Filter by Status */}
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[160px] bg-zinc-800/50 border-zinc-700 text-white">
              <Filter className="w-4 h-4 mr-2 text-zinc-500" />
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="all">All Domains</SelectItem>
              <SelectItem value="connected">Connected</SelectItem>
              <SelectItem value="disconnected">Disconnected</SelectItem>
            </SelectContent>
          </Select>
          
          {/* Sort */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px] bg-zinc-800/50 border-zinc-700 text-white">
              <ArrowUpDown className="w-4 h-4 mr-2 text-zinc-500" />
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="a-z">A - Z</SelectItem>
              <SelectItem value="z-a">Z - A</SelectItem>
            </SelectContent>
          </Select>
          
          {/* Items Per Page */}
          <Select value={itemsPerPage} onValueChange={setItemsPerPage}>
            <SelectTrigger className="w-[120px] bg-zinc-800/50 border-zinc-700 text-white">
              <SelectValue placeholder="Show" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="10">10</SelectItem>
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={<Globe className="w-5 h-5" />}
            label="Total Domains"
            value={domains.length}
            testId="stat-total-domains"
          />
          <StatCard
            icon={<CheckCircle2 className="w-5 h-5 text-emerald-400" />}
            label="Connected"
            value={domains.filter(d => d.is_connected).length}
            testId="stat-connected"
          />
          <StatCard
            icon={<XCircle className="w-5 h-5 text-zinc-400" />}
            label="Disconnected"
            value={domains.filter(d => !d.is_connected).length}
            testId="stat-disconnected"
          />
          <StatCard
            icon={<FileText className="w-5 h-5 text-indigo-400" />}
            label="Last Added"
            value={domains.length > 0 ? new Date(domains[domains.length - 1]?.created_at).toLocaleDateString() : '-'}
            testId="stat-last-added"
          />
        </div>

        {/* Domains Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-indigo-500 spinner" />
          </div>
        ) : filteredDomains.length === 0 ? (
          <div className="text-center py-20">
            <Globe className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">
              {searchQuery ? 'No domains found' : 'No domains yet'}
            </h3>
            <p className="text-zinc-400 mb-6">
              {searchQuery ? 'Try a different search term' : 'Add your first WordPress site to get started'}
            </p>
            {!searchQuery && (
              <Button
                onClick={() => setShowAddDialog(true)}
                className="bg-indigo-500 hover:bg-indigo-600 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Domain
              </Button>
            )}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayedDomains.map((domain, index) => (
                <DomainCard
                  key={domain.id}
                  domain={domain}
                  index={index}
                  onDelete={handleDelete}
                  onEdit={setEditDomain}
                  onRefresh={fetchDomains}
                />
              ))}
            </div>
            
            {/* Pagination Info */}
            {filteredDomains.length > 0 && (
              <div className="mt-6 text-center text-sm text-zinc-500">
                Menampilkan {displayedDomains.length} dari {filteredDomains.length} domain
                {filteredDomains.length !== domains.length && (
                  <span> (Total: {domains.length})</span>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* Edit Dialog */}
      <Dialog open={!!editDomain} onOpenChange={(open) => !open && setEditDomain(null)}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Edit Domain</DialogTitle>
          </DialogHeader>
          {editDomain && (
            <DomainForm
              domain={editDomain}
              onSuccess={() => {
                setEditDomain(null);
                fetchDomains();
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatCard({ icon, label, value, testId }) {
  return (
    <Card className="bg-zinc-900/50 border-zinc-800" data-testid={testId}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center text-indigo-400">
            {icon}
          </div>
          <div>
            <p className="text-sm text-zinc-400">{label}</p>
            <p className="text-xl font-bold text-white">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function DomainCard({ domain, index, onDelete, onEdit, onRefresh }) {
  const [testing, setTesting] = useState(false);

  const handleTest = async () => {
    setTesting(true);
    try {
      const response = await domainsApi.test(domain.id);
      if (response.data.success) {
        toast.success('Connection successful!');
        onRefresh();
      } else {
        toast.error(response.data.message || 'Connection failed');
      }
    } catch (error) {
      toast.error('Connection test failed');
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card 
      className="bg-zinc-900/80 border-zinc-800 domain-card animate-fade-in"
      style={{ animationDelay: `${index * 50}ms` }}
      data-testid={`domain-card-${domain.id}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full ${domain.is_connected ? 'status-connected' : 'status-disconnected'}`} />
            <CardTitle className="text-lg text-white truncate max-w-[180px]">
              {domain.name}
            </CardTitle>
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(domain)}
              data-testid={`edit-domain-${domain.id}`}
              className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-zinc-800"
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(domain.id, domain.name)}
              data-testid={`delete-domain-${domain.id}`}
              className="h-8 w-8 text-zinc-400 hover:text-red-400 hover:bg-red-500/10"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-zinc-400">
          <ExternalLink className="w-4 h-4" />
          <a 
            href={domain.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="truncate hover:text-indigo-400 transition-colors"
          >
            {domain.url.replace(/^https?:\/\//, '')}
          </a>
        </div>

        <div className="text-xs text-zinc-500">
          User: <span className="text-zinc-400 mono">{domain.wp_username}</span>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleTest}
            disabled={testing}
            data-testid={`test-connection-${domain.id}`}
            className="flex-1 bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700 hover:text-white"
          >
            {testing ? (
              <Loader2 className="w-4 h-4 spinner" />
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 mr-1" />
                Test
              </>
            )}
          </Button>
          <Button
            asChild
            size="sm"
            className="flex-1 bg-indigo-500 hover:bg-indigo-600 text-white"
            data-testid={`manage-domain-${domain.id}`}
          >
            <Link to={`/domains/${domain.id}`}>
              Manage
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function DomainForm({ domain, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: domain?.name || '',
    url: domain?.url || '',
    wp_username: domain?.wp_username || '',
    wp_app_password: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (domain) {
        // Update - only send non-empty password
        const updateData = { ...formData };
        if (!updateData.wp_app_password) {
          delete updateData.wp_app_password;
        }
        await domainsApi.update(domain.id, updateData);
        toast.success('Domain updated successfully');
      } else {
        await domainsApi.create(formData);
        toast.success('Domain added successfully');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label className="text-zinc-300">Site Name</Label>
        <Input
          placeholder="My WordPress Site"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
          data-testid="domain-name-input"
          className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-zinc-300">WordPress URL</Label>
        <Input
          placeholder="https://example.com"
          value={formData.url}
          onChange={(e) => setFormData({ ...formData, url: e.target.value })}
          required
          data-testid="domain-url-input"
          className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-zinc-300">WordPress Username</Label>
        <Input
          placeholder="admin"
          value={formData.wp_username}
          onChange={(e) => setFormData({ ...formData, wp_username: e.target.value })}
          required
          data-testid="domain-username-input"
          className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-zinc-300">
          Application Password
          {domain && <span className="text-zinc-500 text-xs ml-2">(leave empty to keep current)</span>}
        </Label>
        <Input
          type="password"
          placeholder={domain ? '••••••••••••••••' : 'xxxx xxxx xxxx xxxx xxxx xxxx'}
          value={formData.wp_app_password}
          onChange={(e) => setFormData({ ...formData, wp_app_password: e.target.value })}
          required={!domain}
          data-testid="domain-password-input"
          className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500 mono"
        />
        <p className="text-xs text-zinc-500">
          Generate at WordPress Admin → Users → Profile → Application Passwords
        </p>
      </div>

      <Button
        type="submit"
        disabled={loading}
        data-testid="domain-form-submit"
        className="w-full bg-indigo-500 hover:bg-indigo-600 text-white"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 spinner" />
            {domain ? 'Updating...' : 'Adding...'}
          </>
        ) : (
          domain ? 'Update Domain' : 'Add Domain'
        )}
      </Button>
    </form>
  );
}
