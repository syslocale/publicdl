import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import Logo from '../components/Logo';
import { ArrowLeft, Scale } from 'lucide-react';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/docs">Docs</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/fair-use">Fair Use</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center">
            <Scale className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Syarat dan Ketentuan Layanan</h1>
            <p className="text-zinc-400">Terakhir diperbarui: 18 Desember 2024</p>
          </div>
        </div>

        <div className="prose prose-invert prose-zinc max-w-none">
          <div className="space-y-8 text-zinc-300 text-sm leading-relaxed">
            
            {/* Preamble */}
            <section className="p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg">
              <p className="text-zinc-400 italic">
                Dokumen ini merupakan perjanjian hukum yang mengikat antara Anda (selanjutnya disebut 
                &quot;Pengguna&quot; atau &quot;Anda&quot;) dengan WPMTools (selanjutnya disebut &quot;Kami&quot;, 
                &quot;Layanan&quot;, atau &quot;Platform&quot;). Dengan mengakses atau menggunakan layanan kami, 
                Anda menyatakan telah membaca, memahami, dan menyetujui untuk terikat oleh syarat dan 
                ketentuan ini.
              </p>
            </section>

            {/* Section 1 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 1 - Definisi</h2>
              <div className="space-y-2">
                <p><strong className="text-white">1.1 &quot;Layanan&quot;</strong> mengacu pada platform WPMTools, termasuk namun tidak terbatas pada website, aplikasi, API, dan semua fitur yang disediakan.</p>
                <p><strong className="text-white">1.2 &quot;Pengguna&quot;</strong> adalah setiap individu atau entitas yang mengakses atau menggunakan Layanan.</p>
                <p><strong className="text-white">1.3 &quot;Konten&quot;</strong> meliputi teks, gambar, video, data, dan materi lainnya yang dibuat, diunggah, atau diproses melalui Layanan.</p>
                <p><strong className="text-white">1.4 &quot;Kredensial&quot;</strong> meliputi API key, password aplikasi WordPress, dan informasi otentikasi lainnya.</p>
                <p><strong className="text-white">1.5 &quot;Konten AI&quot;</strong> adalah konten yang dihasilkan menggunakan teknologi kecerdasan buatan melalui Layanan.</p>
              </div>
            </section>

            {/* Section 2 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 2 - Ruang Lingkup Layanan</h2>
              <div className="space-y-2">
                <p><strong className="text-white">2.1</strong> WPMTools menyediakan platform untuk mengelola multiple website WordPress, termasuk:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Manajemen posts, pages, categories, dan tags</li>
                  <li>Generasi konten menggunakan teknologi AI</li>
                  <li>Penjadwalan publikasi konten</li>
                  <li>Manajemen tim dan kolaborasi</li>
                  <li>Fitur-fitur lain yang mungkin ditambahkan dari waktu ke waktu</li>
                </ul>
                <p><strong className="text-white">2.2</strong> Kami berhak untuk mengubah, menangguhkan, atau menghentikan sebagian atau seluruh Layanan kapan saja dengan atau tanpa pemberitahuan sebelumnya.</p>
              </div>
            </section>

            {/* Section 3 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 3 - Pendaftaran dan Akun</h2>
              <div className="space-y-2">
                <p><strong className="text-white">3.1 Kelayakan:</strong> Anda harus berusia minimal 18 tahun atau usia dewasa menurut hukum yang berlaku di yurisdiksi Anda untuk menggunakan Layanan ini.</p>
                <p><strong className="text-white">3.2 Keakuratan Informasi:</strong> Anda wajib memberikan informasi yang akurat, lengkap, dan terkini saat mendaftar dan selama menggunakan Layanan.</p>
                <p><strong className="text-white">3.3 Keamanan Akun:</strong> Anda bertanggung jawab penuh untuk menjaga kerahasiaan kredensial akun Anda dan semua aktivitas yang terjadi di bawah akun Anda.</p>
                <p><strong className="text-white">3.4 Pemberitahuan Pelanggaran:</strong> Anda wajib segera memberitahu Kami jika mengetahui adanya penggunaan tidak sah atas akun Anda.</p>
              </div>
            </section>

            {/* Section 4 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 4 - Kredensial dan API Key</h2>
              <div className="space-y-2">
                <p><strong className="text-white">4.1 Kepemilikan:</strong> Semua API key (OpenAI, Gemini, Claude, dll) dan kredensial WordPress yang Anda masukkan tetap menjadi milik dan tanggung jawab Anda sepenuhnya.</p>
                <p><strong className="text-white">4.2 Penyimpanan:</strong> Kami menyimpan kredensial Anda dengan enkripsi untuk keamanan, namun Kami tidak bertanggung jawab atas penyalahgunaan yang terjadi di luar sistem Kami.</p>
                <p><strong className="text-white">4.3 Biaya Pihak Ketiga:</strong> Anda bertanggung jawab penuh atas semua biaya yang timbul dari penggunaan API pihak ketiga (seperti OpenAI) melalui Layanan Kami.</p>
                <p><strong className="text-white">4.4 Otorisasi:</strong> Dengan memasukkan kredensial WordPress, Anda menyatakan bahwa Anda memiliki otorisasi sah untuk mengakses dan mengelola website tersebut.</p>
              </div>
            </section>

            {/* Section 5 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 5 - Konten dan Hak Kekayaan Intelektual</h2>
              <div className="space-y-2">
                <p><strong className="text-white">5.1 Kepemilikan Konten Pengguna:</strong> Anda mempertahankan semua hak atas konten yang Anda buat atau unggah melalui Layanan. Kami tidak mengklaim kepemilikan atas konten Anda.</p>
                <p><strong className="text-white">5.2 Lisensi untuk Kami:</strong> Dengan menggunakan Layanan, Anda memberikan Kami lisensi terbatas untuk memproses, menyimpan, dan menampilkan konten Anda sebatas yang diperlukan untuk menyediakan Layanan.</p>
                <p><strong className="text-white">5.3 Konten AI:</strong> Konten yang dihasilkan oleh AI melalui Layanan Kami menjadi milik Anda, namun Anda bertanggung jawab penuh untuk memastikan konten tersebut tidak melanggar hak pihak ketiga.</p>
                <p><strong className="text-white">5.4 Kekayaan Intelektual Kami:</strong> Layanan, termasuk desain, kode, logo, dan materi lainnya adalah milik Kami dan dilindungi oleh hukum hak cipta dan kekayaan intelektual.</p>
              </div>
            </section>

            {/* Section 6 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 6 - Penggunaan yang Dilarang</h2>
              <div className="space-y-2">
                <p>Anda dilarang menggunakan Layanan untuk:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Aktivitas yang melanggar hukum atau peraturan yang berlaku</li>
                  <li>Menyebarkan konten yang melanggar hak cipta, merek dagang, atau hak kekayaan intelektual lainnya</li>
                  <li>Membuat atau menyebarkan konten yang mengandung SARA, pornografi, kekerasan, atau kebencian</li>
                  <li>Spam, phishing, atau aktivitas penipuan lainnya</li>
                  <li>Menyebarkan malware, virus, atau kode berbahaya lainnya</li>
                  <li>Mengakses website WordPress tanpa otorisasi yang sah</li>
                  <li>Melakukan reverse engineering, dekompilasi, atau modifikasi tidak sah terhadap Layanan</li>
                  <li>Mengganggu atau membebani infrastruktur Layanan</li>
                  <li>Menyalahgunakan fitur AI untuk menghasilkan konten palsu atau menyesatkan</li>
                </ul>
              </div>
            </section>

            {/* Section 7 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 7 - Penafian Konten dan Infrastruktur</h2>
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg mb-4">
                <p className="text-red-300 font-medium">PENTING: BACA DENGAN SEKSAMA</p>
              </div>
              <div className="space-y-2">
                <p><strong className="text-white">7.1 Status Platform:</strong> WPMTools adalah PLATFORM PENGHUBUNG (intermediary platform) yang HANYA menyediakan antarmuka untuk mengelola website WordPress milik Pengguna. Kami BUKAN penyedia konten, hosting, atau layanan AI.</p>
                
                <p><strong className="text-white">7.2 Kepemilikan Infrastruktur:</strong> Kami dengan tegas menyatakan bahwa:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Website WordPress yang dikelola adalah <strong className="text-white">milik dan tanggung jawab Pengguna sepenuhnya</strong></li>
                  <li>Server hosting WordPress adalah <strong className="text-white">milik dan tanggung jawab Pengguna atau penyedia hosting mereka</strong></li>
                  <li>API Key AI (OpenAI, Gemini, Claude, dll) adalah <strong className="text-white">milik dan tanggung jawab Pengguna</strong></li>
                  <li>Semua biaya yang timbul dari penggunaan API pihak ketiga adalah <strong className="text-white">tanggung jawab Pengguna</strong></li>
                </ul>

                <p><strong className="text-white">7.3 Tidak Menyimpan Konten:</strong> Kami TIDAK menyimpan, meng-host, atau memiliki salinan konten yang dibuat atau dikelola melalui platform Kami. Semua konten langsung disimpan di server WordPress milik Pengguna.</p>

                <p><strong className="text-white">7.4 Tidak Membuat Konten:</strong> Kami TIDAK membuat konten apapun. Konten yang dihasilkan melalui fitur AI sepenuhnya diproses oleh layanan AI pihak ketiga (seperti OpenAI) menggunakan API key yang disediakan oleh Pengguna sendiri.</p>

                <p><strong className="text-white">7.5 Tidak Menyediakan Layanan AI:</strong> Kami TIDAK menyediakan layanan AI. Kami hanya menyediakan antarmuka untuk menghubungkan Pengguna dengan layanan AI pihak ketiga menggunakan kredensial milik Pengguna.</p>

                <p><strong className="text-white">7.6 Tanggung Jawab Penuh Pengguna:</strong> Pengguna bertanggung jawab sepenuhnya atas:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Semua konten yang dibuat, diedit, atau dipublikasikan melalui platform</li>
                  <li>Keamanan dan kerahasiaan kredensial WordPress dan API key</li>
                  <li>Kepatuhan konten terhadap hukum yang berlaku</li>
                  <li>Review dan verifikasi keakuratan konten sebelum publikasi</li>
                  <li>Backup data dan konten WordPress</li>
                  <li>Biaya penggunaan API pihak ketiga</li>
                </ul>

                <p><strong className="text-white">7.7 Pembebasan Tanggung Jawab:</strong> Dengan menggunakan Layanan, Anda membebaskan Kami dari segala tuntutan, klaim, atau kerugian yang timbul dari:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Konten yang Anda buat atau publikasikan</li>
                  <li>Pelanggaran hak cipta, merek dagang, atau hak kekayaan intelektual</li>
                  <li>Konten yang melanggar UU ITE, pencemaran nama baik, atau hukum lainnya</li>
                  <li>Kerusakan atau kehilangan data di website WordPress Anda</li>
                  <li>Biaya atau tagihan dari penyedia layanan AI pihak ketiga</li>
                  <li>Akses tidak sah ke website WordPress akibat kelalaian menjaga kredensial</li>
                </ul>
              </div>
            </section>

            {/* Section 8 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 8 - Privasi dan Perlindungan Data</h2>
              <div className="space-y-2">
                <p><strong className="text-white">8.1 Pengumpulan Data:</strong> Kami mengumpulkan dan memproses data pribadi Anda sesuai dengan Kebijakan Privasi Kami.</p>
                <p><strong className="text-white">8.2 Keamanan Data:</strong> Kami menerapkan langkah-langkah keamanan yang wajar untuk melindungi data Anda, namun tidak ada sistem yang sepenuhnya aman.</p>
                <p><strong className="text-white">8.3 Pihak Ketiga:</strong> Penggunaan API pihak ketiga (OpenAI, dll) tunduk pada kebijakan privasi masing-masing penyedia layanan tersebut.</p>
              </div>
            </section>

            {/* Section 9 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 9 - Pembatasan Tanggung Jawab</h2>
              <div className="space-y-2">
                <p><strong className="text-white">9.1</strong> LAYANAN DISEDIAKAN &quot;SEBAGAIMANA ADANYA&quot; DAN &quot;SEBAGAIMANA TERSEDIA&quot; TANPA JAMINAN APAPUN, BAIK TERSURAT MAUPUN TERSIRAT.</p>
                <p><strong className="text-white">9.2</strong> Kami tidak menjamin bahwa Layanan akan selalu tersedia, bebas error, aman, atau memenuhi kebutuhan spesifik Anda.</p>
                <p><strong className="text-white">9.3</strong> Kami TIDAK bertanggung jawab atas konten, data, atau informasi apapun yang:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Dibuat, diedit, atau dipublikasikan oleh Pengguna melalui platform</li>
                  <li>Dihasilkan oleh layanan AI pihak ketiga menggunakan API key Pengguna</li>
                  <li>Disimpan di server WordPress milik Pengguna</li>
                  <li>Ditransmisikan antara platform Kami dan layanan pihak ketiga</li>
                </ul>
                <p><strong className="text-white">9.4</strong> Dalam keadaan apapun, Kami tidak bertanggung jawab atas:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Kerugian tidak langsung, insidental, khusus, atau konsekuensial</li>
                  <li>Kehilangan keuntungan, data, atau goodwill</li>
                  <li>Gangguan bisnis</li>
                  <li>Kerugian yang timbul dari penggunaan atau ketidakmampuan menggunakan Layanan</li>
                  <li>Konten yang dianggap melanggar hukum, menyesatkan, atau merugikan pihak lain</li>
                  <li>Biaya atau tagihan dari penyedia layanan pihak ketiga (hosting, AI, dll)</li>
                  <li>Kerusakan reputasi akibat konten yang dipublikasikan Pengguna</li>
                </ul>
                <p><strong className="text-white">9.5</strong> Total tanggung jawab Kami dalam keadaan apapun tidak akan melebihi jumlah yang Anda bayarkan kepada Kami dalam 12 bulan terakhir, atau Rp 0 (nol rupiah) jika Layanan diberikan secara gratis.</p>
              </div>
            </section>

            {/* Section 10 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 10 - Ganti Rugi</h2>
              <div className="space-y-2">
                <p>Anda setuju untuk membebaskan, membela, dan mengganti rugi Kami, afiliasi, direktur, karyawan, dan agen dari segala klaim, kerugian, tanggung jawab, dan biaya (termasuk biaya hukum) yang timbul dari:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Pelanggaran Anda terhadap Syarat dan Ketentuan ini</li>
                  <li>Pelanggaran Anda terhadap hak pihak ketiga</li>
                  <li>Konten yang Anda buat atau publikasikan melalui Layanan</li>
                  <li>Penggunaan kredensial WordPress tanpa otorisasi</li>
                </ul>
              </div>
            </section>

            {/* Section 11 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 11 - Penghentian</h2>
              <div className="space-y-2">
                <p><strong className="text-white">11.1 Oleh Pengguna:</strong> Anda dapat menghentikan penggunaan Layanan kapan saja dengan menghapus akun Anda.</p>
                <p><strong className="text-white">11.2 Oleh Kami:</strong> Kami berhak menangguhkan atau menghentikan akses Anda tanpa pemberitahuan sebelumnya jika:</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>Anda melanggar Syarat dan Ketentuan ini</li>
                  <li>Anda melakukan aktivitas yang dapat merugikan Kami atau pengguna lain</li>
                  <li>Diperlukan untuk kepatuhan hukum</li>
                </ul>
                <p><strong className="text-white">11.3 Efek Penghentian:</strong> Setelah penghentian, Anda tidak lagi memiliki akses ke Layanan dan data Anda mungkin dihapus sesuai kebijakan retensi data Kami.</p>
              </div>
            </section>

            {/* Section 12 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 12 - Perubahan Ketentuan</h2>
              <div className="space-y-2">
                <p><strong className="text-white">12.1</strong> Kami berhak mengubah Syarat dan Ketentuan ini kapan saja. Perubahan material akan diberitahukan melalui email atau pemberitahuan dalam Layanan.</p>
                <p><strong className="text-white">12.2</strong> Penggunaan berkelanjutan atas Layanan setelah perubahan berlaku dianggap sebagai penerimaan Anda terhadap perubahan tersebut.</p>
                <p><strong className="text-white">12.3</strong> Jika Anda tidak menyetujui perubahan, Anda harus berhenti menggunakan Layanan.</p>
              </div>
            </section>

            {/* Section 13 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 13 - Hukum yang Berlaku dan Penyelesaian Sengketa</h2>
              <div className="space-y-2">
                <p><strong className="text-white">13.1 Hukum yang Berlaku:</strong> Syarat dan Ketentuan ini diatur oleh dan ditafsirkan sesuai dengan hukum Republik Indonesia.</p>
                <p><strong className="text-white">13.2 Penyelesaian Sengketa:</strong> Setiap sengketa yang timbul akan diselesaikan secara musyawarah untuk mufakat. Jika tidak tercapai kesepakatan, sengketa akan diselesaikan melalui Badan Arbitrase Nasional Indonesia (BANI) atau pengadilan yang berwenang di Indonesia.</p>
              </div>
            </section>

            {/* Section 14 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 14 - Ketentuan Umum</h2>
              <div className="space-y-2">
                <p><strong className="text-white">14.1 Keseluruhan Perjanjian:</strong> Syarat dan Ketentuan ini merupakan keseluruhan perjanjian antara Anda dan Kami mengenai Layanan.</p>
                <p><strong className="text-white">14.2 Keterpisahan:</strong> Jika ada ketentuan yang dinyatakan tidak berlaku, ketentuan lainnya tetap berlaku sepenuhnya.</p>
                <p><strong className="text-white">14.3 Pengabaian:</strong> Kegagalan Kami untuk menegakkan hak tidak dianggap sebagai pengabaian hak tersebut.</p>
                <p><strong className="text-white">14.4 Pengalihan:</strong> Anda tidak dapat mengalihkan hak atau kewajiban Anda tanpa persetujuan tertulis dari Kami.</p>
              </div>
            </section>

            {/* Section 15 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">Pasal 15 - Kontak</h2>
              <div className="space-y-2">
                <p>Untuk pertanyaan mengenai Syarat dan Ketentuan ini, silakan hubungi Kami melalui:</p>
                <div className="p-4 bg-zinc-800/50 rounded-lg mt-2">
                  <p className="text-zinc-400">Email: support@wpmtools.com</p>
                </div>
              </div>
            </section>

            {/* Acceptance */}
            <section className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-blue-300">
                <strong>Dengan menggunakan Layanan WPMTools, Anda menyatakan telah membaca, memahami, 
                dan menyetujui Syarat dan Ketentuan ini secara keseluruhan.</strong>
              </p>
            </section>

          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">Dokumentasi</Link>
            <Link to="/terms" className="hover:text-white">Terms of Service</Link>
            <Link to="/fair-use" className="hover:text-white">Fair Use</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
