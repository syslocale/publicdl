import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import Logo from '../components/Logo';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import api from '../lib/api';
import {
  CheckCircle2, Database, User, Settings, Sparkles, ArrowRight, ArrowLeft,
  Loader2, Globe, Clock, Eye, EyeOff, Rocket
} from 'lucide-react';

const TIMEZONES = [
  { value: "Asia/Jakarta", label: "WIB - Jakarta (UTC+7)" },
  { value: "Asia/Makassar", label: "WITA - Makassar (UTC+8)" },
  { value: "Asia/Jayapura", label: "WIT - Jayapura (UTC+9)" },
  { value: "Asia/Singapore", label: "Singapore (UTC+8)" },
  { value: "Asia/Kuala_Lumpur", label: "Kuala Lumpur (UTC+8)" },
  { value: "Asia/Bangkok", label: "Bangkok (UTC+7)" },
  { value: "Asia/Ho_Chi_Minh", label: "Ho Chi Minh (UTC+7)" },
  { value: "Asia/Manila", label: "Manila (UTC+8)" },
  { value: "Asia/Tokyo", label: "Tokyo (UTC+9)" },
  { value: "Asia/Seoul", label: "Seoul (UTC+9)" },
  { value: "Asia/Shanghai", label: "Shanghai (UTC+8)" },
  { value: "Asia/Hong_Kong", label: "Hong Kong (UTC+8)" },
  { value: "Asia/Kolkata", label: "India (UTC+5:30)" },
  { value: "Asia/Dubai", label: "Dubai (UTC+4)" },
  { value: "Europe/London", label: "London (UTC+0/+1)" },
  { value: "Europe/Paris", label: "Paris (UTC+1/+2)" },
  { value: "Europe/Berlin", label: "Berlin (UTC+1/+2)" },
  { value: "Europe/Moscow", label: "Moscow (UTC+3)" },
  { value: "America/New_York", label: "New York (UTC-5/-4)" },
  { value: "America/Los_Angeles", label: "Los Angeles (UTC-8/-7)" },
  { value: "America/Chicago", label: "Chicago (UTC-6/-5)" },
  { value: "Australia/Sydney", label: "Sydney (UTC+10/+11)" },
  { value: "Pacific/Auckland", label: "Auckland (UTC+12/+13)" },
  { value: "UTC", label: "UTC (UTC+0)" },
];

const STEPS = [
  { id: 'welcome', title: 'Welcome', icon: Rocket },
  { id: 'database', title: 'Database', icon: Database },
  { id: 'account', title: 'Admin', icon: User },
  { id: 'settings', title: 'Settings', icon: Settings },
  { id: 'ai', title: 'AI Keys', icon: Sparkles },
  { id: 'complete', title: 'Complete', icon: CheckCircle2 },
];

export default function SetupWizardPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [checkingSetup, setCheckingSetup] = useState(true);
  const [dbStatus, setDbStatus] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Check if setup already completed - redirect if yes
  useEffect(() => {
    const checkSetupStatus = async () => {
      try {
        const response = await api.get('/setup/status');
        if (response.data.is_setup_complete) {
          // Setup already done, redirect to login
          toast.error('Setup sudah selesai. Silakan login.');
          navigate('/login', { replace: true });
        }
      } catch (error) {
        // If error, allow setup
      } finally {
        setCheckingSetup(false);
      }
    };
    checkSetupStatus();
  }, [navigate]);
  
  // Form data
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    name: '',
    appName: 'WPMTools',
    defaultLanguage: 'id',
    timezone: 'Asia/Jakarta',
    openaiApiKey: '',
    geminiApiKey: '',
    claudeApiKey: '',
  });

  // Check database connection on mount
  useEffect(() => {
    if (currentStep === 1) {
      checkDatabase();
    }
  }, [currentStep]);

  const checkDatabase = async () => {
    setLoading(true);
    try {
      const response = await api.get('/setup/check-db');
      setDbStatus(response.data);
    } catch (error) {
      setDbStatus({ connected: false, message: 'Failed to check database connection' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep = () => {
    switch (currentStep) {
      case 2: // Account
        if (!formData.username || formData.username.length < 3) {
          toast.error('Username minimal 3 karakter');
          return false;
        }
        if (!formData.name) {
          toast.error('Nama tidak boleh kosong');
          return false;
        }
        if (!formData.password || formData.password.length < 8) {
          toast.error('Password minimal 8 karakter');
          return false;
        }
        if (formData.password !== formData.confirmPassword) {
          toast.error('Password tidak cocok');
          return false;
        }
        return true;
      case 3: // Settings
        if (!formData.appName) {
          toast.error('Nama aplikasi tidak boleh kosong');
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const nextStep = () => {
    if (validateStep()) {
      setCurrentStep(prev => Math.min(prev + 1, STEPS.length - 1));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const completeSetup = async () => {
    setLoading(true);
    try {
      const response = await api.post('/setup/complete', {
        username: formData.username,
        password: formData.password,
        name: formData.name,
        app_name: formData.appName,
        default_language: formData.defaultLanguage,
        timezone: formData.timezone,
        openai_api_key: formData.openaiApiKey || null,
        gemini_api_key: formData.geminiApiKey || null,
        claude_api_key: formData.claudeApiKey || null,
      });

      if (response.data.success) {
        toast.success('Setup berhasil! Selamat datang di WPMTools!');
        // Auto login with returned token
        login(response.data.access_token, response.data.user);
        navigate('/dashboard');
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Setup gagal. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Welcome
        return (
          <div className="text-center space-y-6">
            <div className="w-24 h-24 mx-auto bg-gradient-to-br from-indigo-500 to-violet-600 rounded-2xl flex items-center justify-center">
              <Logo className="w-14 h-14" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Selamat Datang di WPMTools</h2>
              <p className="text-zinc-400">
                WordPress Management Tools - Kelola multiple WordPress sites dengan mudah menggunakan AI.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4 text-left max-w-md mx-auto">
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <Globe className="w-5 h-5 text-blue-400 mb-2" />
                <p className="text-sm text-white font-medium">Multi-Site</p>
                <p className="text-xs text-zinc-400">Kelola banyak WordPress</p>
              </div>
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <Sparkles className="w-5 h-5 text-violet-400 mb-2" />
                <p className="text-sm text-white font-medium">AI Powered</p>
                <p className="text-xs text-zinc-400">Generate konten otomatis</p>
              </div>
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <User className="w-5 h-5 text-emerald-400 mb-2" />
                <p className="text-sm text-white font-medium">Team</p>
                <p className="text-xs text-zinc-400">Kolaborasi dengan tim</p>
              </div>
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <Clock className="w-5 h-5 text-amber-400 mb-2" />
                <p className="text-sm text-white font-medium">Schedule</p>
                <p className="text-xs text-zinc-400">Jadwalkan publikasi</p>
              </div>
            </div>
            <p className="text-sm text-zinc-500">
              Wizard ini akan membantu Anda mengkonfigurasi WPMTools untuk pertama kali.
            </p>
          </div>
        );

      case 1: // Database
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-white mb-2">Koneksi Database</h2>
              <p className="text-zinc-400 text-sm">Memeriksa koneksi ke MongoDB...</p>
            </div>
            
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
              </div>
            ) : dbStatus ? (
              <div className={`p-4 rounded-lg border ${
                dbStatus.connected 
                  ? 'bg-emerald-500/10 border-emerald-500/20' 
                  : 'bg-red-500/10 border-red-500/20'
              }`}>
                <div className="flex items-center gap-3">
                  {dbStatus.connected ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  ) : (
                    <Database className="w-6 h-6 text-red-400" />
                  )}
                  <div>
                    <p className={`font-medium ${dbStatus.connected ? 'text-emerald-400' : 'text-red-400'}`}>
                      {dbStatus.connected ? 'Terhubung' : 'Tidak Terhubung'}
                    </p>
                    <p className="text-sm text-zinc-400">{dbStatus.message}</p>
                    {dbStatus.database && (
                      <p className="text-xs text-zinc-500 mt-1">Database: {dbStatus.database}</p>
                    )}
                  </div>
                </div>
              </div>
            ) : null}

            {!dbStatus?.connected && !loading && (
              <Button onClick={checkDatabase} variant="outline" className="w-full">
                Coba Lagi
              </Button>
            )}
          </div>
        );

      case 2: // Account
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-white mb-2">Buat Akun Administrator</h2>
              <p className="text-zinc-400 text-sm">Akun ini memiliki akses penuh ke seluruh sistem</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Lengkap</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  placeholder="admin"
                  value={formData.username}
                  onChange={(e) => handleInputChange('username', e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  className="bg-zinc-800 border-zinc-700"
                />
                <p className="text-xs text-zinc-500">Hanya huruf kecil, angka, dan underscore</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Minimal 8 karakter"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Konfirmasi Password</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? 'text' : 'password'}
                    placeholder="Ulangi password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    className="bg-zinc-800 border-zinc-700 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 3: // Settings
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-white mb-2">Pengaturan Aplikasi</h2>
              <p className="text-zinc-400 text-sm">Konfigurasi dasar aplikasi</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="appName">Nama Aplikasi</Label>
                <Input
                  id="appName"
                  placeholder="WPMTools"
                  value={formData.appName}
                  onChange={(e) => handleInputChange('appName', e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <p className="text-xs text-zinc-500">Ditampilkan di header dan judul halaman</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultLanguage">Bahasa Default</Label>
                <Select
                  value={formData.defaultLanguage}
                  onValueChange={(value) => handleInputChange('defaultLanguage', value)}
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="id">🇮🇩 Indonesia</SelectItem>
                    <SelectItem value="en">🇺🇸 English</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={formData.timezone}
                  onValueChange={(value) => handleInputChange('timezone', value)}
                >
                  <SelectTrigger className="bg-zinc-800 border-zinc-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {TIMEZONES.map((tz) => (
                      <SelectItem key={tz.value} value={tz.value}>
                        {tz.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-zinc-500">Timezone untuk scheduling post</p>
              </div>
            </div>
          </div>
        );

      case 4: // AI Keys
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-white mb-2">API Keys AI (Opsional)</h2>
              <p className="text-zinc-400 text-sm">Anda bisa melewati langkah ini dan mengatur nanti di Settings</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="openaiApiKey">OpenAI API Key</Label>
                <Input
                  id="openaiApiKey"
                  type="password"
                  placeholder="sk-..."
                  value={formData.openaiApiKey}
                  onChange={(e) => handleInputChange('openaiApiKey', e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <p className="text-xs text-zinc-500">
                  <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                    Dapatkan API key →
                  </a>
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="geminiApiKey">Google Gemini API Key</Label>
                <Input
                  id="geminiApiKey"
                  type="password"
                  placeholder="AI..."
                  value={formData.geminiApiKey}
                  onChange={(e) => handleInputChange('geminiApiKey', e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <p className="text-xs text-zinc-500">
                  <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                    Dapatkan API key →
                  </a>
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="claudeApiKey">Anthropic Claude API Key</Label>
                <Input
                  id="claudeApiKey"
                  type="password"
                  placeholder="sk-ant-..."
                  value={formData.claudeApiKey}
                  onChange={(e) => handleInputChange('claudeApiKey', e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <p className="text-xs text-zinc-500">
                  <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                    Dapatkan API key →
                  </a>
                </p>
              </div>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
              <p className="text-amber-400 text-sm">
                💡 API keys disimpan dengan enkripsi. Anda memerlukan minimal satu API key untuk menggunakan fitur AI.
              </p>
            </div>
          </div>
        );

      case 5: // Complete
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Siap Digunakan!</h2>
              <p className="text-zinc-400">
                Semua konfigurasi sudah lengkap. Klik tombol di bawah untuk menyelesaikan setup.
              </p>
            </div>

            <div className="text-left p-4 bg-zinc-800/50 rounded-lg space-y-2">
              <p className="text-sm"><span className="text-zinc-400">Username:</span> <span className="text-white">{formData.username}</span></p>
              <p className="text-sm"><span className="text-zinc-400">Nama:</span> <span className="text-white">{formData.name}</span></p>
              <p className="text-sm"><span className="text-zinc-400">Aplikasi:</span> <span className="text-white">{formData.appName}</span></p>
              <p className="text-sm"><span className="text-zinc-400">Bahasa:</span> <span className="text-white">{formData.defaultLanguage === 'id' ? 'Indonesia' : 'English'}</span></p>
              <p className="text-sm"><span className="text-zinc-400">Timezone:</span> <span className="text-white">{formData.timezone}</span></p>
              <p className="text-sm">
                <span className="text-zinc-400">AI Keys:</span>{' '}
                <span className="text-white">
                  {[
                    formData.openaiApiKey && 'OpenAI',
                    formData.geminiApiKey && 'Gemini',
                    formData.claudeApiKey && 'Claude'
                  ].filter(Boolean).join(', ') || 'Belum diatur'}
                </span>
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    if (currentStep === 1 && !dbStatus?.connected) return false;
    return true;
  };

  // Show loading while checking setup status
  if (checkingSetup) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b] flex items-center justify-center p-4">
      <Card className="w-full max-w-lg bg-zinc-900 border-zinc-800">
        {/* Progress */}
        <div className="p-4 border-b border-zinc-800">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div key={step.id} className="flex items-center">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center transition-colors
                    ${isCompleted ? 'bg-emerald-500' : isActive ? 'bg-indigo-500' : 'bg-zinc-800'}
                  `}>
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    ) : (
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-zinc-500'}`} />
                    )}
                  </div>
                  {index < STEPS.length - 1 && (
                    <div className={`w-6 h-0.5 mx-1 ${index < currentStep ? 'bg-emerald-500' : 'bg-zinc-800'}`} />
                  )}
                </div>
              );
            })}
          </div>
          <p className="text-center text-sm text-zinc-400 mt-2">
            Step {currentStep + 1} of {STEPS.length}: {STEPS[currentStep].title}
          </p>
        </div>

        <CardContent className="p-6">
          {renderStepContent()}
        </CardContent>

        {/* Navigation */}
        <div className="p-4 border-t border-zinc-800 flex justify-between">
          <Button
            variant="ghost"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="text-zinc-400"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali
          </Button>

          {currentStep === STEPS.length - 1 ? (
            <Button
              onClick={completeSetup}
              disabled={loading}
              className="bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-600 hover:to-violet-600"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  Selesai & Masuk
                  <Rocket className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          ) : (
            <Button
              onClick={nextStep}
              disabled={!canProceed()}
              className="bg-indigo-500 hover:bg-indigo-600"
            >
              Lanjut
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
