import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { teamApi, profileApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import {
  ArrowLeft, Users, UserPlus, Shield, Trash2,
  Loader2, LogOut, Lock, User, Edit, Save, X, Crown
} from 'lucide-react';
import Logo from '../components/Logo';

export default function TeamPage() {
  const { user, logout, refreshUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [members, setMembers] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Add member form
  const [newMember, setNewMember] = useState({ name: '', username: '', password: '' });
  
  // Profile edit
  const [profileEdit, setProfileEdit] = useState({ name: '' });
  const [passwordChange, setPasswordChange] = useState({ current_password: '', new_password: '', confirm_password: '' });

  const isSuperadmin = user?.role === 'superadmin';

  useEffect(() => {
    fetchMembers();
    if (user) {
      setProfileEdit({ name: user.name || '' });
    }
  }, [user]);

  const fetchMembers = async () => {
    try {
      const response = await teamApi.listMembers();
      setMembers(response.data.members || []);
    } catch (error) {
      console.error('Failed to load team members:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddMember = async (e) => {
    e.preventDefault();
    if (!newMember.username || !newMember.password) {
      toast.error('Username and password are required');
      return;
    }
    
    setSaving(true);
    try {
      // Send username to backend
      await teamApi.createMember({
        name: newMember.name || newMember.username,
        username: newMember.username,
        password: newMember.password
      });
      toast.success('Team member added successfully');
      setNewMember({ name: '', username: '', password: '' });
      setShowAddForm(false);
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to add member');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteMember = async (memberId, memberName) => {
    if (!window.confirm(`Are you sure you want to remove ${memberName} from the team?`)) return;
    
    try {
      await teamApi.deleteMember(memberId);
      toast.success('Team member removed');
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to remove member');
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await profileApi.update(profileEdit);
      toast.success('Profile updated');
      if (refreshUser) refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (passwordChange.new_password !== passwordChange.confirm_password) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordChange.new_password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    
    setSaving(true);
    try {
      await profileApi.changePassword({
        current_password: passwordChange.current_password,
        new_password: passwordChange.new_password
      });
      toast.success('Password changed successfully');
      setPasswordChange({ current_password: '', new_password: '', confirm_password: '' });
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to change password');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400 flex items-center gap-1">
                {user?.role === 'superadmin' && <Crown className="w-4 h-4 text-amber-400" />}
                {user?.name}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Users className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-[Chivo]">Team Management</h1>
            <p className="text-zinc-400 text-sm">Manage your team members and profile</p>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1">
            <TabsTrigger value="profile" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <User className="w-4 h-4 mr-2" />My Profile
            </TabsTrigger>
            <TabsTrigger value="team" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />Team Members
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            {/* Profile Info */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Edit className="w-5 h-5 text-indigo-400" />
                  Profile Information
                </CardTitle>
                <CardDescription className="text-zinc-500">
                  Update your personal information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Display Name</Label>
                      <Input
                        value={profileEdit.name}
                        onChange={(e) => setProfileEdit({ ...profileEdit, name: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder="Your name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Username</Label>
                      <Input
                        value={user?.username || ''}
                        disabled
                        className="bg-zinc-800 border-white/10 text-zinc-400 cursor-not-allowed"
                      />
                      <p className="text-xs text-zinc-600">Username cannot be changed</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-2">
                    <span className="text-xs text-zinc-500">Role:</span>
                    <span className={`text-xs px-2 py-1 rounded font-medium ${
                      user?.role === 'superadmin' 
                        ? 'bg-amber-500/20 text-amber-400' 
                        : 'bg-indigo-500/20 text-indigo-400'
                    }`}>
                      {user?.role === 'superadmin' ? 'Superadmin' : 'Admin'}
                    </span>
                  </div>
                  <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-500">
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Changes
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Change Password */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-amber-400" />
                  Change Password
                </CardTitle>
                <CardDescription className="text-zinc-500">
                  Update your password for security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-400">Current Password</Label>
                    <Input
                      type="password"
                      value={passwordChange.current_password}
                      onChange={(e) => setPasswordChange({ ...passwordChange, current_password: e.target.value })}
                      className="bg-zinc-900 border-white/10 text-white"
                      placeholder="••••••••"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-zinc-400">New Password</Label>
                      <Input
                        type="password"
                        value={passwordChange.new_password}
                        onChange={(e) => setPasswordChange({ ...passwordChange, new_password: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder="••••••••"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Confirm New Password</Label>
                      <Input
                        type="password"
                        value={passwordChange.confirm_password}
                        onChange={(e) => setPasswordChange({ ...passwordChange, confirm_password: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  <Button type="submit" disabled={saving} className="bg-amber-600 hover:bg-amber-500">
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Lock className="w-4 h-4 mr-2" />}
                    Change Password
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team Tab */}
          <TabsContent value="team" className="space-y-6">
            {/* Add Member Button */}
            {isSuperadmin && (
              <div className="flex justify-end">
                <Button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className={showAddForm ? "bg-zinc-700" : "bg-indigo-600 hover:bg-indigo-500"}
                >
                  {showAddForm ? <X className="w-4 h-4 mr-2" /> : <UserPlus className="w-4 h-4 mr-2" />}
                  {showAddForm ? 'Cancel' : 'Add Member'}
                </Button>
              </div>
            )}

            {/* Add Member Form */}
            {showAddForm && isSuperadmin && (
              <Card className="bg-zinc-900/50 border-zinc-800 border-indigo-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-indigo-400" />
                    Add New Team Member
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddMember} className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label className="text-zinc-400">Display Name <span className="text-zinc-600">(optional)</span></Label>
                        <Input
                          value={newMember.name}
                          onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-zinc-400">Username <span className="text-red-400">*</span></Label>
                        <Input
                          value={newMember.username}
                          onChange={(e) => setNewMember({ ...newMember, username: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="johndoe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-zinc-400">Password <span className="text-red-400">*</span></Label>
                        <Input
                          type="password"
                          value={newMember.password}
                          onChange={(e) => setNewMember({ ...newMember, password: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                    <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-500">
                      {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <UserPlus className="w-4 h-4 mr-2" />}
                      Add Member
                    </Button>
                  </form>
                </CardContent>
              </Card>
            )}

            {/* Team Members List */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-400" />
                  Team Members ({members.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {members.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center justify-between p-4 bg-zinc-800/50 border border-white/5 rounded-lg"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          member.role === 'superadmin' ? 'bg-amber-500/20' : 'bg-indigo-500/20'
                        }`}>
                          {member.role === 'superadmin' 
                            ? <Crown className="w-5 h-5 text-amber-400" />
                            : <User className="w-5 h-5 text-indigo-400" />
                          }
                        </div>
                        <div>
                          <p className="text-sm font-medium text-white flex items-center gap-2">
                            {member.name}
                            {member.id === user?.id && (
                              <span className="text-xs bg-zinc-700 px-2 py-0.5 rounded text-zinc-400">You</span>
                            )}
                          </p>
                          <p className="text-xs text-zinc-500 flex items-center gap-1">
                            <User className="w-3 h-3" />
                            @{member.username}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-xs px-2 py-1 rounded font-medium ${
                          member.role === 'superadmin' 
                            ? 'bg-amber-500/20 text-amber-400' 
                            : 'bg-indigo-500/20 text-indigo-400'
                        }`}>
                          {member.role === 'superadmin' ? 'Superadmin' : 'Admin'}
                        </span>
                        {isSuperadmin && member.role !== 'superadmin' && member.id !== user?.id && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteMember(member.id, member.name)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {!isSuperadmin && (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <p className="text-sm text-amber-400 flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Only Superadmin can add or remove team members
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
