from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt
from cryptography.fernet import Fernet
import httpx
import base64
import asyncio
from functools import lru_cache
import time
import json

ROOT_DIR = Path(__file__).parent

# In-memory cache for WordPress data
_wp_cache = {}
CACHE_TTL = {
    'stats': 86400,      # 1 day (24 hours)
    'posts': 86400,      # 1 day (24 hours)
    'pages': 86400,      # 1 day (24 hours)
    'tags': 86400,       # 1 day (24 hours)
    'categories': 86400, # 1 day (24 hours)
    'users': 86400       # 1 day (24 hours)
}

def get_cache(cache_key: str):
    """Get data from cache if not expired"""
    cached = _wp_cache.get(cache_key)
    if cached:
        cache_type = cache_key.split('_')[0]
        ttl = CACHE_TTL.get(cache_type, 60)
        if (time.time() - cached['timestamp']) < ttl:
            return cached['data']
    return None

def set_cache(cache_key: str, data):
    """Set data in cache"""
    _wp_cache[cache_key] = {
        'data': data,
        'timestamp': time.time()
    }

def clear_domain_cache(domain_id: str):
    """Clear all cache for a specific domain"""
    keys_to_delete = [k for k in _wp_cache.keys() if domain_id in k]
    for key in keys_to_delete:
        del _wp_cache[key]
    return len(keys_to_delete)

def clear_all_cache():
    """Clear all cache"""
    count = len(_wp_cache)
    _wp_cache.clear()
    return count
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Settings
JWT_SECRET = os.environ.get('JWT_SECRET', 'wpmtools-secret-key-change-in-production')
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Encryption key for WordPress passwords
ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY', Fernet.generate_key().decode())
fernet = Fernet(ENCRYPTION_KEY.encode() if isinstance(ENCRYPTION_KEY, str) else ENCRYPTION_KEY)

# Create the main app
app = FastAPI(title="WPMTools API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Security
security = HTTPBearer()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ==================== MODELS ====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    username: str  # Username untuk login
    password: str

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    username: str  # Username user
    name: str
    created_at: str
    role: str = "admin"  # superadmin or admin
    avatar: Optional[str] = None
    subscription: Optional[dict] = None  # Subscription status for non-superadmin

class TeamMemberCreate(BaseModel):
    username: str  # Username untuk login (bukan email)
    name: str
    password: str
    role: str = "admin"  # admin only, superadmin creates themselves

class TeamMemberUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None  # Bisa ganti username
    role: Optional[str] = None
    avatar: Optional[str] = None

class PasswordChange(BaseModel):
    current_password: str
    new_password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class DomainCreate(BaseModel):
    name: str
    url: str
    wp_username: str
    wp_app_password: str

class DomainUpdate(BaseModel):
    name: Optional[str] = None
    url: Optional[str] = None
    wp_username: Optional[str] = None
    wp_app_password: Optional[str] = None

class DomainResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    url: str
    wp_username: str
    user_id: str
    created_at: str
    last_connected: Optional[str] = None
    is_connected: bool = False

class WPStatsResponse(BaseModel):
    posts_count: int = 0
    pages_count: int = 0
    users_count: int = 0
    tags_count: int = 0
    categories_count: int = 0

class WPPostCreate(BaseModel):
    title: str
    content: str
    status: str = "draft"
    categories: Optional[List[int]] = None
    tags: Optional[List[int]] = None
    link_injection: Optional[dict] = None  # Link injection config

class WPPostUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    status: Optional[str] = None
    categories: Optional[List[int]] = None
    tags: Optional[List[int]] = None
    link_injection: Optional[dict] = None  # Link injection config

class WPCategoryCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    slug: Optional[str] = None
    parent: Optional[int] = None

class WPCategoryUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    slug: Optional[str] = None
    parent: Optional[int] = None

class AIGenerateRequest(BaseModel):
    title: str
    domain_id: str
    content_language: Optional[str] = "auto"  # "auto", "id", "en", etc.
    generate_featured_image: Optional[bool] = False  # Whether to generate featured image

class WPWidgetCreate(BaseModel):
    id_base: str  # widget type e.g. "text", "recent-posts", "categories"
    sidebar: str  # sidebar/widget area id e.g. "sidebar-1"
    instance: Optional[dict] = {}  # widget settings

class WPWidgetUpdate(BaseModel):
    sidebar: Optional[str] = None
    instance: Optional[dict] = None
    position: Optional[int] = None

class WPPageCreate(BaseModel):
    title: str
    content: str
    status: str = "draft"

class WPPageUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    status: Optional[str] = None

class WPTagCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    slug: Optional[str] = None

class WPTagUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    slug: Optional[str] = None

class WPUserCreate(BaseModel):
    username: str
    email: str
    password: str
    first_name: Optional[str] = ""
    last_name: Optional[str] = ""
    roles: List[str] = ["subscriber"]

class WPUserUpdate(BaseModel):
    email: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    roles: Optional[List[str]] = None

class UserSettingsUpdate(BaseModel):
    # Article AI Settings
    article_ai_provider: Optional[str] = "openai"  # openai, gemini, claude
    article_ai_model: Optional[str] = "gpt-4o-mini"
    openai_api_key: Optional[str] = None
    gemini_api_key: Optional[str] = None
    claude_api_key: Optional[str] = None
    # Image AI Settings
    image_ai_provider: Optional[str] = "openai"  # openai, gemini
    image_ai_enabled: Optional[bool] = False
    # Content Settings
    default_post_status: Optional[str] = "draft"
    auto_generate_tags: Optional[bool] = True
    auto_generate_categories: Optional[bool] = True
    auto_generate_seo: Optional[bool] = True
    ai_word_count: Optional[int] = 800
    language: Optional[str] = "id"
    # Custom Prompt
    custom_prompt_enabled: Optional[bool] = False
    custom_prompt: Optional[str] = None

class UserSettingsResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    # Article AI
    article_ai_provider: str = "openai"
    article_ai_model: str = "gpt-4o-mini"
    openai_api_key_set: bool = False
    gemini_api_key_set: bool = False
    claude_api_key_set: bool = False
    # Image AI
    image_ai_provider: str = "openai"
    image_ai_enabled: bool = False
    # Content Settings
    default_post_status: str = "draft"
    auto_generate_tags: bool = True
    auto_generate_categories: bool = True
    auto_generate_seo: bool = True
    ai_word_count: int = 800
    language: str = "id"
    # Custom Prompt
    custom_prompt_enabled: bool = False
    custom_prompt: str = ""

# App-wide limits (Superadmin only)
# -1 = Unlimited, 0 = Disabled, >0 = Limit active
class AppLimitsUpdate(BaseModel):
    max_domains: Optional[int] = None  # Max WordPress sites (-1 = unlimited)
    max_bulk_titles: Optional[int] = None  # Max titles per bulk operation (-1 = unlimited)
    max_concurrent_domains: Optional[int] = None  # Max domains processed at once (-1 = unlimited)
    delay_between_posts: Optional[int] = None  # Seconds between posts (0 = no delay)
    max_team_members: Optional[int] = None  # Max users excluding superadmin (-1 = unlimited)
    max_posts_per_day: Optional[int] = None  # Max auto-posts per day (-1 = unlimited)
    max_ai_requests_per_day: Optional[int] = None  # Max AI API calls per day (-1 = unlimited)

class AppLimitsResponse(BaseModel):
    max_domains: int = -1  # Default unlimited
    max_bulk_titles: int = 20
    max_concurrent_domains: int = 5
    delay_between_posts: int = 3
    max_team_members: int = -1  # Default unlimited
    max_posts_per_day: int = -1  # Default unlimited
    max_ai_requests_per_day: int = -1  # Default unlimited

# Default limits (-1 = unlimited)
DEFAULT_APP_LIMITS = {
    "max_domains": -1,  # Unlimited by default
    "max_bulk_titles": 20,
    "max_concurrent_domains": 5,
    "delay_between_posts": 3,
    "max_team_members": -1,  # Unlimited by default
    "max_posts_per_day": -1,  # Unlimited by default
    "max_ai_requests_per_day": -1  # Unlimited by default
}

# ==================== SUBSCRIPTION MODELS ====================

class SubscriptionUpdate(BaseModel):
    due_date: Optional[str] = None  # ISO date string: "2025-01-21"

class SubscriptionStatus(BaseModel):
    due_date: Optional[str] = None
    status: str = "active"  # active, warning, expired
    days_remaining: Optional[int] = None
    message: Optional[str] = None

# ==================== HELPER FUNCTIONS ====================

def detect_language_from_text(text: str) -> str:
    """
    Detect language from text using simple heuristics.
    Returns language code: 'id', 'en', etc.
    """
    import re
    
    text_lower = text.lower()
    
    # Indonesian common words and patterns
    indonesian_patterns = [
        r'\b(cara|bagaimana|apa|mengapa|kenapa|siapa|kapan|dimana)\b',
        r'\b(untuk|dengan|dari|pada|ke|di|yang|dan|atau|ini|itu)\b',
        r'\b(adalah|merupakan|sebagai|tentang|mengenai|terhadap)\b',
        r'\b(membuat|membeli|menjual|mencari|menggunakan|mendapatkan)\b',
        r'\b(terbaik|terbaru|terlengkap|termurah|mudah|cepat)\b',
        r'\b(tips|panduan|tutorial|review|ulasan|daftar)\b',
        r'\b(rumah|mobil|motor|hp|handphone|laptop|komputer)\b',
        r'\b(makanan|minuman|resep|masakan|kuliner)\b',
        r'\b(wisata|liburan|perjalanan|destinasi|tempat)\b',
        r'\b(kerja|bisnis|usaha|karir|pekerjaan|gaji)\b',
        r'\b(sekolah|kuliah|belajar|pendidikan|pelatihan)\b',
        r'\b(kesehatan|obat|penyakit|dokter|rumah sakit)\b',
    ]
    
    # English common words and patterns
    english_patterns = [
        r'\b(how|what|why|when|where|who|which)\b',
        r'\b(the|a|an|is|are|was|were|be|been|being)\b',
        r'\b(to|for|with|from|at|in|on|of|by)\b',
        r'\b(best|top|new|ultimate|complete|easy|quick|fast)\b',
        r'\b(guide|tips|tutorial|review|list|ways|steps)\b',
        r'\b(make|buy|sell|find|use|get|create|build)\b',
        r'\b(business|work|job|career|money|investment)\b',
        r'\b(health|food|travel|home|technology|education)\b',
    ]
    
    # Spanish patterns
    spanish_patterns = [
        r'\b(cómo|qué|por qué|cuándo|dónde|quién)\b',
        r'\b(para|con|de|en|el|la|los|las|un|una)\b',
        r'\b(mejor|nuevo|guía|consejos|tutorial)\b',
    ]
    
    # French patterns
    french_patterns = [
        r'\b(comment|quoi|pourquoi|quand|où|qui)\b',
        r'\b(pour|avec|de|dans|le|la|les|un|une)\b',
        r'\b(meilleur|nouveau|guide|conseils|tutoriel)\b',
    ]
    
    # German patterns
    german_patterns = [
        r'\b(wie|was|warum|wann|wo|wer)\b',
        r'\b(für|mit|von|in|der|die|das|ein|eine)\b',
        r'\b(beste|neu|tipps|anleitung|ratgeber)\b',
    ]
    
    # Count matches for each language
    scores = {
        'id': 0,
        'en': 0,
        'es': 0,
        'fr': 0,
        'de': 0,
    }
    
    for pattern in indonesian_patterns:
        if re.search(pattern, text_lower):
            scores['id'] += 1
    
    for pattern in english_patterns:
        if re.search(pattern, text_lower):
            scores['en'] += 1
    
    for pattern in spanish_patterns:
        if re.search(pattern, text_lower):
            scores['es'] += 1
    
    for pattern in french_patterns:
        if re.search(pattern, text_lower):
            scores['fr'] += 1
    
    for pattern in german_patterns:
        if re.search(pattern, text_lower):
            scores['de'] += 1
    
    # Check for non-Latin scripts
    if re.search(r'[\u4e00-\u9fff]', text):  # Chinese characters
        return 'zh'
    if re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text):  # Japanese hiragana/katakana
        return 'ja'
    if re.search(r'[\uac00-\ud7af]', text):  # Korean hangul
        return 'ko'
    if re.search(r'[\u0600-\u06ff]', text):  # Arabic
        return 'ar'
    if re.search(r'[\u0900-\u097f]', text):  # Hindi/Devanagari
        return 'hi'
    if re.search(r'[\u0e00-\u0e7f]', text):  # Thai
        return 'th'
    if re.search(r'[\u0400-\u04ff]', text):  # Cyrillic (Russian)
        return 'ru'
    
    # Return the language with highest score, default to 'en' if tie or no matches
    max_score = max(scores.values())
    if max_score == 0:
        return 'en'  # Default to English if no patterns match
    
    for lang, score in scores.items():
        if score == max_score:
            return lang
    
    return 'en'

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())

def create_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS),
        "iat": datetime.now(timezone.utc)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def encrypt_password(password: str) -> str:
    return fernet.encrypt(password.encode()).decode()

def decrypt_password(encrypted: str) -> str:
    return fernet.decrypt(encrypted.encode()).decode()

async def get_app_limits() -> dict:
    """Get app-wide limits from database or return defaults"""
    limits = await db.app_settings.find_one({"type": "limits"}, {"_id": 0})
    if limits:
        return {**DEFAULT_APP_LIMITS, **limits}
    return DEFAULT_APP_LIMITS.copy()

async def get_subscription_status() -> dict:
    """Get subscription status based on due_date"""
    settings = await db.app_settings.find_one({"type": "subscription"}, {"_id": 0})
    
    if not settings or not settings.get("due_date"):
        # No due_date set = unlimited/active
        return {
            "due_date": None,
            "status": "active",
            "days_remaining": None,
            "message": None
        }
    
    due_date_str = settings.get("due_date")
    try:
        due_date = datetime.fromisoformat(due_date_str).replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        delta = due_date - now
        days_remaining = delta.days
        
        if days_remaining < 0:
            return {
                "due_date": due_date_str,
                "status": "expired",
                "days_remaining": days_remaining,
                "message": "Langganan Anda telah berakhir. Hubungi support untuk memperpanjang."
            }
        elif days_remaining <= 7:
            return {
                "due_date": due_date_str,
                "status": "warning",
                "days_remaining": days_remaining,
                "message": f"Langganan Anda akan berakhir dalam {days_remaining} hari."
            }
        else:
            return {
                "due_date": due_date_str,
                "status": "active",
                "days_remaining": days_remaining,
                "message": None
            }
    except Exception:
        return {
            "due_date": due_date_str,
            "status": "active",
            "days_remaining": None,
            "message": None
        }

def check_subscription_active(subscription_status: dict, user_role: str):
    """Check if subscription is active. Superadmin bypasses this check."""
    if user_role == "superadmin":
        return True  # Superadmin always has access
    
    if subscription_status.get("status") == "expired":
        raise HTTPException(
            status_code=403, 
            detail="Langganan Anda telah berakhir. Hubungi support untuk memperpanjang."
        )

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Role-based permission dependencies
def require_not_staff(current_user: dict = Depends(get_current_user)):
    """Dependency to require non-staff role (admin or superadmin)"""
    if current_user.get("role") == "staff":
        raise HTTPException(status_code=403, detail="Staff cannot access this feature")
    return current_user

def require_admin_or_above(current_user: dict = Depends(get_current_user)):
    """Dependency to require admin or superadmin role"""
    if current_user.get("role") not in ["superadmin", "admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

def require_superadmin(current_user: dict = Depends(get_current_user)):
    """Dependency to require superadmin role"""
    if current_user.get("role") != "superadmin":
        raise HTTPException(status_code=403, detail="Superadmin access required")
    return current_user

async def require_active_subscription(current_user: dict = Depends(get_current_user)):
    """Dependency to check if subscription is active. Superadmin bypasses this."""
    if current_user.get("role") == "superadmin":
        return current_user  # Superadmin always has access
    
    subscription = await get_subscription_status()
    if subscription.get("status") == "expired":
        raise HTTPException(
            status_code=403, 
            detail="Langganan Anda telah berakhir. Hubungi support untuk memperpanjang."
        )
    return current_user

async def get_domain_with_credentials(domain_id: str, user_id: str = None):
    """Get domain with credentials - accessible by all team members"""
    # No user_id filter - all members can access all domains
    domain = await db.domains.find_one({"id": domain_id}, {"_id": 0})
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    return domain

def get_wp_auth_header(username: str, app_password: str) -> dict:
    credentials = f"{username}:{app_password}"
    encoded = base64.b64encode(credentials.encode()).decode()
    return {"Authorization": f"Basic {encoded}"}

async def wp_request(method: str, url: str, domain: dict, data: dict = None, params: dict = None):
    """Make authenticated request to WordPress REST API"""
    decrypted_password = decrypt_password(domain["wp_app_password_encrypted"])
    headers = get_wp_auth_header(domain["wp_username"], decrypted_password)
    headers["Content-Type"] = "application/json"
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            if method == "GET":
                response = await client.get(url, headers=headers, params=params)
            elif method == "POST":
                response = await client.post(url, headers=headers, json=data)
            elif method == "PUT":
                response = await client.put(url, headers=headers, json=data)
            elif method == "DELETE":
                response = await client.delete(url, headers=headers, params=params)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            return response
        except httpx.RequestError as e:
            raise HTTPException(status_code=502, detail=f"Failed to connect to WordPress: {str(e)}")

# ==================== AUTH ROUTES ====================

# Register endpoint removed - users managed by superadmin via Team page

@api_router.post("/auth/login", response_model=TokenResponse)
async def login(user_data: UserLogin, request: Request):
    # Login dengan username (disimpan di field 'username' di database)
    user = await db.users.find_one({"username": user_data.username}, {"_id": 0})
    if not user or not verify_password(user_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    token = create_token(user["id"])
    
    # Get subscription status for non-superadmin
    subscription = None
    if user.get("role") != "superadmin":
        subscription = await get_subscription_status()
    
    user_response = UserResponse(
        id=user["id"],
        username=user["username"],
        name=user["name"],
        role=user.get("role", "admin"),
        avatar=user.get("avatar"),
        created_at=user["created_at"],
        subscription=subscription
    )
    
    # Log activity
    client_ip = request.client.host if request.client else "unknown"
    await log_activity(user["id"], user["name"], user["username"], "LOGIN", "User logged in", client_ip, user.get("role", ""))
    
    return TokenResponse(access_token=token, user=user_response)

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    # Get subscription status for non-superadmin
    subscription = None
    if current_user.get("role") != "superadmin":
        subscription = await get_subscription_status()
    
    return UserResponse(
        id=current_user["id"],
        username=current_user["username"],
        name=current_user["name"],
        role=current_user.get("role", "admin"),
        avatar=current_user.get("avatar"),
        created_at=current_user["created_at"],
        subscription=subscription
    )

# ==================== SUBSCRIPTION ROUTES (Superadmin Only) ====================

@api_router.get("/subscription/status")
async def get_subscription(current_user: dict = Depends(get_current_user)):
    """Get current subscription status"""
    status = await get_subscription_status()
    # Only superadmin can see full details
    if current_user.get("role") == "superadmin":
        return status
    # Others just see if active/warning/expired
    return {
        "status": status["status"],
        "days_remaining": status["days_remaining"],
        "message": status["message"]
    }

@api_router.put("/subscription/due-date")
async def set_subscription_due_date(
    data: SubscriptionUpdate, 
    current_user: dict = Depends(require_superadmin)
):
    """Set subscription due date (Superadmin only)"""
    update_data = {"type": "subscription"}
    
    if data.due_date:
        # Validate date format
        try:
            datetime.fromisoformat(data.due_date)
            update_data["due_date"] = data.due_date
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use ISO format: YYYY-MM-DD")
    else:
        update_data["due_date"] = None  # Remove due date (unlimited)
    
    await db.app_settings.update_one(
        {"type": "subscription"},
        {"$set": update_data},
        upsert=True
    )
    
    # Log activity
    action_detail = f"Set due date to {data.due_date}" if data.due_date else "Removed due date (unlimited)"
    await log_activity(
        current_user["id"], 
        "WPMTools (System)", 
        current_user["username"], 
        "UPDATE_SUBSCRIPTION", 
        action_detail, 
        "", 
        "superadmin"
    )
    
    return await get_subscription_status()

# ==================== DOMAIN ROUTES ====================

@api_router.post("/domains", response_model=DomainResponse)
async def create_domain(domain_data: DomainCreate, current_user: dict = Depends(require_active_subscription)):
    # Check domain limit (-1 = unlimited)
    limits = await get_app_limits()
    if limits["max_domains"] >= 0:  # -1 means unlimited
        domains_count = await db.domains.count_documents({})
        if domains_count >= limits["max_domains"]:
            raise HTTPException(
                status_code=400,
                detail=f"Batas maksimal domain ({limits['max_domains']}) sudah tercapai. Hubungi Superadmin untuk menambah limit."
            )
    
    domain_id = str(uuid.uuid4())
    
    # Normalize URL
    url = domain_data.url.rstrip('/')
    if not url.startswith('http'):
        url = f"https://{url}"
    
    # Extract hostname and path for duplicate check
    from urllib.parse import urlparse
    import re
    parsed_url = urlparse(url)
    hostname = parsed_url.netloc.lower()  # e.g., "blog.example.com"
    path = parsed_url.path.rstrip('/') or ''  # e.g., "/blog" or ""
    
    # Build the normalized URL part (hostname + path) for comparison
    # This will match: example.com, example.com/, http://example.com, https://example.com
    normalized_pattern = f"{hostname}{path}"
    
    # Escape special regex characters in the pattern
    escaped_pattern = re.escape(normalized_pattern)
    
    # Check for duplicate URL (hostname + path match, ignore http/https difference)
    existing_domain = await db.domains.find_one({
        "url": {"$regex": f"^https?://{escaped_pattern}/?$", "$options": "i"}
    })
    
    if existing_domain:
        if path:
            raise HTTPException(
                status_code=400, 
                detail=f"URL '{hostname}{path}' sudah terdaftar."
            )
        else:
            raise HTTPException(
                status_code=400, 
                detail=f"Domain '{hostname}' sudah terdaftar. Gunakan subdomain (blog.{hostname}) atau path (/blog) jika ingin menambahkan site berbeda."
            )
    
    domain_doc = {
        "id": domain_id,
        "name": domain_data.name,
        "url": url,
        "wp_username": domain_data.wp_username,
        "wp_app_password_encrypted": encrypt_password(domain_data.wp_app_password),
        "user_id": current_user["id"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_connected": None,
        "is_connected": False
    }
    
    await db.domains.insert_one(domain_doc)
    
    # Log activity
    await log_activity(current_user["id"], current_user["name"], current_user["username"], "CREATE_DOMAIN", f"Created domain: {domain_data.name} ({url})", "", current_user.get("role", ""))
    
    return DomainResponse(
        id=domain_id,
        name=domain_data.name,
        url=url,
        wp_username=domain_data.wp_username,
        user_id=current_user["id"],
        created_at=domain_doc["created_at"],
        last_connected=None,
        is_connected=False
    )

@api_router.get("/domains", response_model=List[DomainResponse])
async def list_domains(current_user: dict = Depends(get_current_user)):
    # All team members can see all domains (shared management)
    domains = await db.domains.find(
        {},  # No user_id filter - all domains visible to all members
        {"_id": 0, "wp_app_password_encrypted": 0}
    ).to_list(1000)
    
    return [DomainResponse(**d) for d in domains]

@api_router.get("/domains/{domain_id}", response_model=DomainResponse)
async def get_domain(domain_id: str, current_user: dict = Depends(get_current_user)):
    # All team members can access any domain
    domain = await db.domains.find_one(
        {"id": domain_id},  # No user_id filter
        {"_id": 0, "wp_app_password_encrypted": 0}
    )
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    return DomainResponse(**domain)

@api_router.put("/domains/{domain_id}", response_model=DomainResponse)
async def update_domain(domain_id: str, domain_data: DomainUpdate, current_user: dict = Depends(get_current_user)):
    # All team members can update any domain
    domain = await db.domains.find_one({"id": domain_id})
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    
    update_data = {}
    if domain_data.name is not None:
        update_data["name"] = domain_data.name
    if domain_data.url is not None:
        url = domain_data.url.rstrip('/')
        if not url.startswith('http'):
            url = f"https://{url}"
        update_data["url"] = url
    if domain_data.wp_username is not None:
        update_data["wp_username"] = domain_data.wp_username
    if domain_data.wp_app_password is not None:
        update_data["wp_app_password_encrypted"] = encrypt_password(domain_data.wp_app_password)
    
    if update_data:
        await db.domains.update_one({"id": domain_id}, {"$set": update_data})
    
    updated = await db.domains.find_one(
        {"id": domain_id},
        {"_id": 0, "wp_app_password_encrypted": 0}
    )
    return DomainResponse(**updated)

@api_router.delete("/domains/{domain_id}")
async def delete_domain(domain_id: str, current_user: dict = Depends(get_current_user)):
    # Get domain name before deleting for logging - All members can delete
    domain = await db.domains.find_one({"id": domain_id})
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    
    result = await db.domains.delete_one({"id": domain_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Domain not found")
    
    # Log activity
    await log_activity(current_user["id"], current_user["name"], current_user["username"], "DELETE_DOMAIN", f"Deleted domain: {domain.get('name')} ({domain.get('url')})", "", current_user.get("role", ""))
    
    return {"message": "Domain deleted successfully"}

# ==================== CONNECTION TEST ====================

@api_router.post("/domains/{domain_id}/test")
async def test_connection(domain_id: str, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    try:
        response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/users/me", domain)
        
        if response.status_code == 200:
            await db.domains.update_one(
                {"id": domain_id},
                {"$set": {
                    "is_connected": True,
                    "last_connected": datetime.now(timezone.utc).isoformat()
                }}
            )
            return {"success": True, "message": "Connection successful", "user": response.json()}
        else:
            await db.domains.update_one({"id": domain_id}, {"$set": {"is_connected": False}})
            return {"success": False, "message": f"WordPress returned status {response.status_code}", "details": response.text}
    except Exception as e:
        await db.domains.update_one({"id": domain_id}, {"$set": {"is_connected": False}})
        return {"success": False, "message": str(e)}

# ==================== STATS ====================

@api_router.get("/domains/{domain_id}/stats", response_model=WPStatsResponse)
async def get_stats(domain_id: str, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # Check cache first
    cache_key = f"stats_{domain_id}"
    cached = get_cache(cache_key)
    if cached:
        logger.info(f"Returning cached stats for {domain_id}")
        return cached
    
    stats = WPStatsResponse()
    
    try:
        # OPTIMIZED: Fetch all stats in PARALLEL using asyncio.gather
        async def fetch_count(endpoint: str) -> int:
            try:
                response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/{endpoint}", domain, params={"per_page": 1})
                if response.status_code == 200:
                    return int(response.headers.get("X-WP-Total", 0))
            except:
                pass
            return 0
        
        # Run all requests in parallel - 5x faster!
        posts, pages, users, tags, categories = await asyncio.gather(
            fetch_count("posts"),
            fetch_count("pages"),
            fetch_count("users"),
            fetch_count("tags"),
            fetch_count("categories")
        )
        
        stats.posts_count = posts
        stats.pages_count = pages
        stats.users_count = users
        stats.tags_count = tags
        stats.categories_count = categories
        
        # Cache the result
        set_cache(cache_key, stats)
        
    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
    
    return stats

# ==================== POSTS CRUD ====================

@api_router.get("/domains/{domain_id}/posts")
async def list_posts(domain_id: str, page: int = 1, per_page: int = 10, no_cache: bool = False, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # Check cache first (unless no_cache is True)
    cache_key = f"posts_{domain_id}_p{page}_n{per_page}"
    if not no_cache:
        cached = get_cache(cache_key)
        if cached:
            logger.info(f"Returning cached posts for {domain_id} page {page}")
            return cached
    
    # Try with status=any first (requires valid auth)
    response = await wp_request(
        "GET", 
        f"{domain['url']}/wp-json/wp/v2/posts", 
        domain, 
        params={"page": page, "per_page": per_page, "status": "any"}
    )
    
    # If auth fails (400/401), fallback to published posts only
    if response.status_code in [400, 401, 403]:
        logger.warning(f"Auth failed for {domain['url']}, falling back to published posts only")
        response = await wp_request(
            "GET", 
            f"{domain['url']}/wp-json/wp/v2/posts", 
            domain, 
            params={"page": page, "per_page": per_page}
        )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    result = {
        "items": response.json(),
        "total": int(response.headers.get("X-WP-Total", 0)),
        "total_pages": int(response.headers.get("X-WP-TotalPages", 0))
    }
    
    # Cache the result
    set_cache(cache_key, result)
    
    return result

@api_router.get("/domains/{domain_id}/posts/{post_id}")
async def get_post(domain_id: str, post_id: int, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/posts/{post_id}", domain)
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/posts")
async def create_post(domain_id: str, post_data: WPPostCreate, current_user: dict = Depends(require_active_subscription)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # Process link injection if provided
    content = post_data.content
    if post_data.link_injection and post_data.link_injection.get("enabled"):
        link_config = LinkInjectionConfig(**post_data.link_injection)
        content = inject_links_into_content(content, link_config)
    
    # Prepare data for WordPress
    wp_data = {
        "title": post_data.title,
        "content": content,
        "status": post_data.status,
    }
    if post_data.categories:
        wp_data["categories"] = post_data.categories
    if post_data.tags:
        wp_data["tags"] = post_data.tags
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/posts",
        domain,
        data=wp_data
    )
    
    if response.status_code not in [200, 201]:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.put("/domains/{domain_id}/posts/{post_id}")
async def update_post(domain_id: str, post_id: int, post_data: WPPostUpdate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    update_data = {k: v for k, v in post_data.model_dump().items() if v is not None}
    
    # Process link injection if provided
    if post_data.link_injection and post_data.link_injection.get("enabled") and post_data.content:
        link_config = LinkInjectionConfig(**post_data.link_injection)
        update_data["content"] = inject_links_into_content(post_data.content, link_config)
    
    # Remove link_injection from data sent to WordPress
    update_data.pop("link_injection", None)
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/posts/{post_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/posts/{post_id}")
async def delete_post(domain_id: str, post_id: int, force: bool = False, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/posts/{post_id}",
        domain,
        params={"force": str(force).lower()}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

class BulkDeleteRequest(BaseModel):
    ids: List[int]
    force: bool = True

@api_router.post("/domains/{domain_id}/posts/bulk-delete")
async def bulk_delete_posts(domain_id: str, request: BulkDeleteRequest, current_user: dict = Depends(get_current_user)):
    """Bulk delete multiple posts"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    deleted = []
    failed = []
    
    for post_id in request.ids:
        try:
            response = await wp_request(
                "DELETE",
                f"{domain['url']}/wp-json/wp/v2/posts/{post_id}",
                domain,
                params={"force": str(request.force).lower()}
            )
            if response.status_code == 200:
                deleted.append(post_id)
            else:
                failed.append({"id": post_id, "error": response.text})
        except Exception as e:
            failed.append({"id": post_id, "error": str(e)})
    
    return {"deleted": deleted, "failed": failed, "total_deleted": len(deleted)}

@api_router.post("/domains/{domain_id}/pages/bulk-delete")
async def bulk_delete_pages(domain_id: str, request: BulkDeleteRequest, current_user: dict = Depends(get_current_user)):
    """Bulk delete multiple pages"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    deleted = []
    failed = []
    
    for page_id in request.ids:
        try:
            response = await wp_request(
                "DELETE",
                f"{domain['url']}/wp-json/wp/v2/pages/{page_id}",
                domain,
                params={"force": str(request.force).lower()}
            )
            if response.status_code == 200:
                deleted.append(page_id)
            else:
                failed.append({"id": page_id, "error": response.text})
        except Exception as e:
            failed.append({"id": page_id, "error": str(e)})
    
    return {"deleted": deleted, "failed": failed, "total_deleted": len(deleted)}

@api_router.post("/domains/{domain_id}/tags/bulk-delete")
async def bulk_delete_tags(domain_id: str, request: BulkDeleteRequest, current_user: dict = Depends(get_current_user)):
    """Bulk delete multiple tags"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    deleted = []
    failed = []
    
    for tag_id in request.ids:
        try:
            response = await wp_request(
                "DELETE",
                f"{domain['url']}/wp-json/wp/v2/tags/{tag_id}",
                domain,
                params={"force": "true"}
            )
            if response.status_code == 200:
                deleted.append(tag_id)
            else:
                failed.append({"id": tag_id, "error": response.text})
        except Exception as e:
            failed.append({"id": tag_id, "error": str(e)})
    
    return {"deleted": deleted, "failed": failed, "total_deleted": len(deleted)}

# ==================== PAGES CRUD ====================

@api_router.get("/domains/{domain_id}/pages")
async def list_pages(domain_id: str, page: int = 1, per_page: int = 10, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # Try with status=any first (requires valid auth)
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/pages",
        domain,
        params={"page": page, "per_page": per_page, "status": "any"}
    )
    
    # If auth fails (400/401), fallback to published pages only
    if response.status_code in [400, 401, 403]:
        logger.warning(f"Auth failed for {domain['url']} pages, falling back to published pages only")
        response = await wp_request(
            "GET",
            f"{domain['url']}/wp-json/wp/v2/pages",
            domain,
            params={"page": page, "per_page": per_page}
        )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return {
        "items": response.json(),
        "total": int(response.headers.get("X-WP-Total", 0)),
        "total_pages": int(response.headers.get("X-WP-TotalPages", 0))
    }

@api_router.get("/domains/{domain_id}/pages/{page_id}")
async def get_page(domain_id: str, page_id: int, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/pages/{page_id}", domain)
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/pages")
async def create_page(domain_id: str, page_data: WPPageCreate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/pages",
        domain,
        data=page_data.model_dump()
    )
    
    if response.status_code not in [200, 201]:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.put("/domains/{domain_id}/pages/{page_id}")
async def update_page(domain_id: str, page_id: int, page_data: WPPageUpdate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    update_data = {k: v for k, v in page_data.model_dump().items() if v is not None}
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/pages/{page_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/pages/{page_id}")
async def delete_page(domain_id: str, page_id: int, force: bool = False, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/pages/{page_id}",
        domain,
        params={"force": str(force).lower()}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

# ==================== TAGS CRUD ====================

@api_router.get("/domains/{domain_id}/tags")
async def list_tags(domain_id: str, page: int = 1, per_page: int = 100, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/tags",
        domain,
        params={"page": page, "per_page": per_page}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return {
        "items": response.json(),
        "total": int(response.headers.get("X-WP-Total", 0)),
        "total_pages": int(response.headers.get("X-WP-TotalPages", 0))
    }

@api_router.get("/domains/{domain_id}/tags/{tag_id}")
async def get_tag(domain_id: str, tag_id: int, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/tags/{tag_id}", domain)
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/tags")
async def create_tag(domain_id: str, tag_data: WPTagCreate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    data = tag_data.model_dump(exclude_none=True)
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/tags",
        domain,
        data=data
    )
    
    if response.status_code not in [200, 201]:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.put("/domains/{domain_id}/tags/{tag_id}")
async def update_tag(domain_id: str, tag_id: int, tag_data: WPTagUpdate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    update_data = {k: v for k, v in tag_data.model_dump().items() if v is not None}
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/tags/{tag_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/tags/{tag_id}")
async def delete_tag(domain_id: str, tag_id: int, force: bool = True, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/tags/{tag_id}",
        domain,
        params={"force": str(force).lower()}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

# ==================== USERS CRUD ====================

@api_router.get("/domains/{domain_id}/users")
async def list_users(domain_id: str, page: int = 1, per_page: int = 10, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/users",
        domain,
        params={"page": page, "per_page": per_page}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return {
        "items": response.json(),
        "total": int(response.headers.get("X-WP-Total", 0)),
        "total_pages": int(response.headers.get("X-WP-TotalPages", 0))
    }

@api_router.get("/domains/{domain_id}/users/{user_id}")
async def get_user(domain_id: str, user_id: int, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/users/{user_id}", domain)
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/users")
async def create_user(domain_id: str, user_data: WPUserCreate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/users",
        domain,
        data=user_data.model_dump()
    )
    
    if response.status_code not in [200, 201]:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.put("/domains/{domain_id}/users/{user_id}")
async def update_user(domain_id: str, user_id: int, user_data: WPUserUpdate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    update_data = {k: v for k, v in user_data.model_dump().items() if v is not None}
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/users/{user_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/users/{user_id}")
async def delete_user(domain_id: str, user_id: int, reassign: int = None, force: bool = True, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    params = {"force": str(force).lower()}
    if reassign:
        params["reassign"] = reassign
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/users/{user_id}",
        domain,
        params=params
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

# ==================== CATEGORIES CRUD ====================

@api_router.get("/domains/{domain_id}/categories")
async def list_categories(domain_id: str, page: int = 1, per_page: int = 100, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/categories",
        domain,
        params={"page": page, "per_page": per_page}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return {
        "items": response.json(),
        "total": int(response.headers.get("X-WP-Total", 0)),
        "total_pages": int(response.headers.get("X-WP-TotalPages", 0))
    }

@api_router.get("/domains/{domain_id}/categories/{category_id}")
async def get_category(domain_id: str, category_id: int, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request("GET", f"{domain['url']}/wp-json/wp/v2/categories/{category_id}", domain)
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/categories")
async def create_category(domain_id: str, category_data: WPCategoryCreate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    data = category_data.model_dump(exclude_none=True)
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/categories",
        domain,
        data=data
    )
    
    if response.status_code not in [200, 201]:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.put("/domains/{domain_id}/categories/{category_id}")
async def update_category(domain_id: str, category_id: int, category_data: WPCategoryUpdate, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    update_data = {k: v for k, v in category_data.model_dump().items() if v is not None}
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/categories/{category_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/categories/{category_id}")
async def delete_category(domain_id: str, category_id: int, force: bool = True, current_user: dict = Depends(get_current_user)):
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/categories/{category_id}",
        domain,
        params={"force": str(force).lower()}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

# ==================== CACHE PURGE (LiteSpeed) ====================

@api_router.post("/domains/{domain_id}/purge-cache")
async def purge_cache(domain_id: str, current_user: dict = Depends(get_current_user)):
    """Purge cache notification - cache is auto-purged on publish by WordPress/LiteSpeed"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # Update last purge timestamp
    await db.domains.update_one(
        {"id": domain_id},
        {"$set": {"last_cache_purge": datetime.now(timezone.utc).isoformat()}}
    )
    
    # Note: Cache is automatically purged by WordPress/LiteSpeed on content changes
    # This endpoint provides user feedback that cache refresh was triggered
    return {"success": True, "message": "Cache refreshed successfully!"}

# ==================== WIDGETS CRUD ====================

@api_router.get("/domains/{domain_id}/sidebars")
async def list_sidebars(domain_id: str, current_user: dict = Depends(get_current_user)):
    """List all widget areas (sidebars)"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/sidebars",
        domain
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.get("/domains/{domain_id}/sidebars/{sidebar_id}")
async def get_sidebar(domain_id: str, sidebar_id: str, current_user: dict = Depends(get_current_user)):
    """Get a specific sidebar with its widgets"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/sidebars/{sidebar_id}",
        domain
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.get("/domains/{domain_id}/widgets")
async def list_widgets(domain_id: str, sidebar: str = None, current_user: dict = Depends(get_current_user)):
    """List all widgets, optionally filtered by sidebar"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    params = {}
    if sidebar:
        params["sidebar"] = sidebar
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/widgets",
        domain,
        params=params
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.get("/domains/{domain_id}/widget-types")
async def list_widget_types(domain_id: str, current_user: dict = Depends(get_current_user)):
    """List available widget types"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/widget-types",
        domain
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.get("/domains/{domain_id}/widgets/{widget_id}")
async def get_widget(domain_id: str, widget_id: str, current_user: dict = Depends(get_current_user)):
    """Get a specific widget"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/widgets/{widget_id}",
        domain
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.post("/domains/{domain_id}/widgets")
async def create_widget(domain_id: str, widget_data: WPWidgetCreate, current_user: dict = Depends(get_current_user)):
    """Create a new widget"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    instance = widget_data.instance or {}
    id_base = widget_data.id_base
    content = instance.get("content") or instance.get("text") or ""
    title = instance.get("title", "")
    
    # Handle different widget types based on WordPress REST API requirements
    if id_base == "block":
        # Block widgets need "raw" object with "content" field
        if content:
            # Check if content already has Gutenberg block markers
            if '<!-- wp:' in content:
                block_content = content
            elif '<ul' in content.lower() or '<ol' in content.lower():
                block_content = f'<!-- wp:list -->\n{content}\n<!-- /wp:list -->'
            else:
                # Wrap plain text/HTML in html block
                block_content = f'<!-- wp:html -->\n{content}\n<!-- /wp:html -->'
            
            if title:
                block_content = f'<!-- wp:heading -->\n<h2 class="wp-block-heading">{title}</h2>\n<!-- /wp:heading -->\n{block_content}'
        else:
            block_content = "<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->"
        
        # WordPress REST API requires instance.raw to be an object with content property
        instance = {"raw": {"content": block_content}}
    elif id_base == "custom_html":
        # Custom HTML widget format
        instance = {
            "title": title,
            "content": content
        }
    elif id_base == "text":
        # Classic Text widget format
        instance = {
            "title": title,
            "text": content,
            "filter": True,
            "visual": True
        }
    else:
        # For other widgets, keep instance as-is but ensure title/content
        if title and "title" not in instance:
            instance["title"] = title
    
    data = {
        "id_base": id_base,
        "sidebar": widget_data.sidebar,
        "instance": instance
    }
    
    logger.info(f"Creating widget with id_base={id_base}, sidebar={widget_data.sidebar}")
    logger.info(f"Widget data being sent: {json.dumps(data)}")
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/widgets",
        domain,
        data=data
    )
    
    logger.info(f"WordPress response status: {response.status_code}")
    logger.info(f"WordPress response body: {response.text}")
    
    if response.status_code not in [200, 201]:
        logger.error(f"Widget creation failed: {response.status_code} - {response.text}")
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    result = response.json()
    logger.info(f"Created widget sidebar: {result.get('sidebar')}, widget_id: {result.get('id')}")
    
    # If block widget was created but not in the correct sidebar, update it
    created_sidebar = result.get('sidebar', '')
    if id_base == "block" and created_sidebar != widget_data.sidebar:
        logger.info(f"Block widget created in {created_sidebar}, moving to {widget_data.sidebar}")
        widget_id = result.get('id')
        if widget_id:
            update_response = await wp_request(
                "POST",
                f"{domain['url']}/wp-json/wp/v2/widgets/{widget_id}",
                domain,
                data={"sidebar": widget_data.sidebar}
            )
            if update_response.status_code == 200:
                result = update_response.json()
                logger.info(f"Widget moved to sidebar: {result.get('sidebar')}")
    
    return result

@api_router.put("/domains/{domain_id}/widgets/{widget_id}")
async def update_widget(domain_id: str, widget_id: str, widget_data: WPWidgetUpdate, current_user: dict = Depends(get_current_user)):
    """Update a widget"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    # First get the widget to determine its type
    get_response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/widgets/{widget_id}",
        domain
    )
    
    widget_type = ""
    original_instance = {}
    if get_response.status_code == 200:
        widget_info = get_response.json()
        widget_type = widget_info.get("id_base", "")
        original_instance = widget_info.get("instance", {})
    
    update_data = {}
    if widget_data.sidebar is not None:
        update_data["sidebar"] = widget_data.sidebar
    if widget_data.instance is not None:
        instance = widget_data.instance
        content = instance.get("content") or instance.get("text") or ""
        title = instance.get("title", "")
        
        # Handle different widget types
        if widget_type == "block" or widget_id.startswith("block-"):
            # For block widgets, we need to detect if content is already in Gutenberg format
            if content:
                # Check if content already has Gutenberg block markers
                if '<!-- wp:' in content:
                    block_content = content
                elif '<ul' in content.lower() or '<ol' in content.lower():
                    block_content = f'<!-- wp:list -->\n{content}\n<!-- /wp:list -->'
                else:
                    block_content = f'<!-- wp:html -->\n{content}\n<!-- /wp:html -->'
            else:
                block_content = "<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->"
            
            # WordPress REST API requires instance.raw to be an object with content property
            instance = {"raw": {"content": block_content}}
        elif widget_type == "custom_html":
            instance = {
                "title": title,
                "content": content
            }
        elif widget_type == "text":
            instance = {
                "title": title,
                "text": content,
                "filter": True,
                "visual": True
            }
        
        update_data["instance"] = instance
    
    logger.info(f"Updating widget {widget_id}: {update_data}")
    
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/widgets/{widget_id}",
        domain,
        data=update_data
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

@api_router.delete("/domains/{domain_id}/widgets/{widget_id}")
async def delete_widget(domain_id: str, widget_id: str, force: bool = True, current_user: dict = Depends(get_current_user)):
    """Delete a widget"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    response = await wp_request(
        "DELETE",
        f"{domain['url']}/wp-json/wp/v2/widgets/{widget_id}",
        domain,
        params={"force": str(force).lower()}
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

class WidgetReorderRequest(BaseModel):
    sidebar: str
    widget_ids: List[str]

@api_router.post("/domains/{domain_id}/widgets/reorder")
async def reorder_widgets(domain_id: str, request: WidgetReorderRequest, current_user: dict = Depends(get_current_user)):
    """Reorder widgets in a sidebar"""
    domain = await get_domain_with_credentials(domain_id, current_user["id"])
    
    logger.info(f"Reordering widgets in {request.sidebar}: {request.widget_ids}")
    
    # Update sidebar with new widget order
    response = await wp_request(
        "POST",
        f"{domain['url']}/wp-json/wp/v2/sidebars/{request.sidebar}",
        domain,
        data={"widgets": request.widget_ids}
    )
    
    logger.info(f"Reorder response: {response.status_code}")
    
    if response.status_code != 200:
        logger.error(f"Reorder failed: {response.text}")
        raise HTTPException(status_code=response.status_code, detail=response.text)
    
    return response.json()

# ==================== AI GENERATION ====================

async def call_ai_provider(provider: str, model: str, api_key: str, system_message: str, prompt: str) -> str:
    """
    Universal AI provider caller - supports OpenAI, Gemini, and Claude
    Returns the text response from the AI
    """
    if provider == "openai":
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=api_key)
        response = await client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    
    elif provider == "gemini":
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        gen_model = genai.GenerativeModel(model)
        full_prompt = f"{system_message}\n\n{prompt}"
        response = await gen_model.generate_content_async(full_prompt)
        return response.text.strip()
    
    elif provider == "claude":
        import anthropic
        client = anthropic.AsyncAnthropic(api_key=api_key)
        response = await client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_message,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        return response.content[0].text.strip()
    
    else:
        raise ValueError(f"Unknown AI provider: {provider}")

def get_ai_config(user_settings: dict) -> tuple:
    """
    Get AI provider configuration from user settings
    Returns: (provider, model, api_key_field)
    """
    provider = user_settings.get("article_ai_provider", "openai") if user_settings else "openai"
    model = user_settings.get("article_ai_model", "gpt-4o-mini") if user_settings else "gpt-4o-mini"
    
    # Map provider to API key field
    api_key_fields = {
        "openai": "openai_api_key",
        "gemini": "gemini_api_key", 
        "claude": "claude_api_key"
    }
    
    return provider, model, api_key_fields.get(provider, "openai_api_key")

@api_router.post("/ai/generate-post")
async def generate_post_content(request: AIGenerateRequest, current_user: dict = Depends(get_current_user)):
    """Generate post content, categories and tags using AI based on title"""
    
    domain = await get_domain_with_credentials(request.domain_id, current_user["id"])
    
    # Get existing categories and tags from WordPress
    categories_response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/categories",
        domain,
        params={"per_page": 100}
    )
    existing_categories = categories_response.json() if categories_response.status_code == 200 else []
    
    tags_response = await wp_request(
        "GET",
        f"{domain['url']}/wp-json/wp/v2/tags",
        domain,
        params={"per_page": 100}
    )
    existing_tags = tags_response.json() if tags_response.status_code == 200 else []
    
    category_names = [c["name"] for c in existing_categories]
    tag_names = [t["name"] for t in existing_tags]
    
    # Get user settings and AI config
    user_settings = await db.user_settings.find_one({"user_id": current_user["id"]}, {"_id": 0})
    provider, model, api_key_field = get_ai_config(user_settings)
    
    # Get encrypted API key for the selected provider
    encrypted_api_key = user_settings.get(api_key_field) if user_settings else None
    
    if not encrypted_api_key:
        raise HTTPException(status_code=400, detail=f"{provider.capitalize()} API key not configured. Please add your API key in Settings.")
    
    # Decrypt the API key
    api_key = decrypt_password(encrypted_api_key)
    
    # Determine content language
    content_language = request.content_language or "auto"
    
    if content_language == "auto":
        detected_language = detect_language_from_text(request.title)
        language = detected_language
    else:
        language = content_language
    
    # Map language codes to full language names
    language_map = {
        "id": "Bahasa Indonesia",
        "en": "English",
        "es": "Spanish (Español)",
        "fr": "French (Français)",
        "de": "German (Deutsch)",
        "pt": "Portuguese (Português)",
        "it": "Italian (Italiano)",
        "nl": "Dutch (Nederlands)",
        "ru": "Russian (Русский)",
        "ja": "Japanese (日本語)",
        "ko": "Korean (한국어)",
        "zh": "Chinese (中文)",
        "ar": "Arabic (العربية)",
        "hi": "Hindi (हिन्दी)",
        "th": "Thai (ไทย)",
        "vi": "Vietnamese (Tiếng Việt)",
        "ms": "Malay (Bahasa Melayu)",
        "tl": "Tagalog (Filipino)",
    }
    language_instruction = language_map.get(language, "English")
    
    system_message = f"""You are a professional blog content writer. You write engaging, informative, and SEO-friendly blog posts.
Your content should be well-structured with headings, paragraphs, and proper HTML formatting.
Always write in a professional yet engaging tone.
IMPORTANT: Write ALL content in {language_instruction}."""
    
    prompt = f"""Write a comprehensive blog post about: "{request.title}"

Requirements:
1. Write a detailed article with MINIMUM 800 words
2. Use proper HTML formatting: <h2>, <h3>, <p>, <ul>, <li>, <strong>, <em> tags
3. Include an engaging introduction
4. Include 3-5 main sections with subheadings
5. Include a conclusion
6. Make it informative and engaging
7. WRITE EVERYTHING IN {language_instruction.upper()}

Also suggest:
- 1-2 categories from existing: {category_names if category_names else 'create new ones'}
- 3-5 relevant tags from existing: {tag_names if tag_names else 'create new ones'}

Respond in this exact JSON format:
{{
    "content": "<your HTML formatted article here in {language_instruction}>",
    "suggested_categories": ["category1", "category2"],
    "suggested_tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}}

Only respond with the JSON, no other text."""

    try:
        # Use the universal AI provider caller
        response_text = await call_ai_provider(provider, model, api_key, system_message, prompt)
        
        # Parse JSON response
        # Clean response if it has markdown code blocks
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]
        response_text = response_text.strip()
        
        result = json.loads(response_text)
        
        # Map suggested categories to IDs
        category_ids = []
        for cat_name in result.get("suggested_categories", []):
            for cat in existing_categories:
                if cat["name"].lower() == cat_name.lower():
                    category_ids.append(cat["id"])
                    break
        
        # Map suggested tags to IDs
        tag_ids = []
        for tag_name in result.get("suggested_tags", []):
            for tag in existing_tags:
                if tag["name"].lower() == tag_name.lower():
                    tag_ids.append(tag["id"])
                    break
        
        return {
            "content": result.get("content", ""),
            "suggested_categories": result.get("suggested_categories", []),
            "suggested_tags": result.get("suggested_tags", []),
            "category_ids": category_ids,
            "tag_ids": tag_ids,
            "existing_categories": existing_categories,
            "existing_tags": existing_tags
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse AI response: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse AI response")
    except Exception as e:
        logger.error(f"AI generation error: {e}")
        raise HTTPException(status_code=500, detail=f"AI generation failed: {str(e)}")

class LinkInjectionConfig(BaseModel):
    """Configuration for injecting links into post content"""
    enabled: bool = False
    url: str = ""
    anchor_text: str = ""
    rel: str = "dofollow"  # dofollow or nofollow
    position: str = "middle"  # start, middle, end
    repetition: int = 1  # 1-5 times

class AutoPostRequest(BaseModel):
    domain_id: str
    title: str
    scheduled_date: Optional[str] = None  # ISO format datetime for scheduling
    link_injection: Optional[LinkInjectionConfig] = None
    content_language: Optional[str] = "auto"  # "auto", "id", "en", "es", "fr", etc.
    generate_featured_image: Optional[bool] = False  # Whether to generate featured image

def inject_links_into_content(content: str, link_config: LinkInjectionConfig) -> str:
    """Inject links into HTML content at specified positions"""
    import re
    import random
    
    if not link_config or not link_config.enabled or not link_config.url or not link_config.anchor_text:
        return content
    
    # Build the link HTML
    rel_attr = "" if link_config.rel == "dofollow" else ' rel="nofollow"'
    link_html = f'<a href="{link_config.url}"{rel_attr}>{link_config.anchor_text}</a>'
    
    # Find all paragraphs
    paragraphs = re.findall(r'<p>.*?</p>', content, re.DOTALL)
    
    if not paragraphs:
        # No paragraphs found, just append/prepend
        if link_config.position == "start":
            return f"<p>{link_html}</p>\n" + content
        else:
            return content + f"\n<p>{link_html}</p>"
    
    # Determine insertion positions based on config
    positions_to_insert = []
    num_paragraphs = len(paragraphs)
    
    for _ in range(min(link_config.repetition, 5)):  # Max 5 repetitions
        if link_config.position == "start":
            # Insert after first paragraph
            positions_to_insert.append(0)
        elif link_config.position == "end":
            # Insert before last paragraph
            positions_to_insert.append(max(0, num_paragraphs - 1))
        else:  # middle - random
            if num_paragraphs > 2:
                # Random position between first and last (exclusive)
                pos = random.randint(1, num_paragraphs - 2)
                positions_to_insert.append(pos)
            else:
                positions_to_insert.append(0)
    
    # Remove duplicates and sort in reverse order for insertion
    positions_to_insert = sorted(set(positions_to_insert), reverse=True)
    
    # Insert links at positions
    result = content
    for pos in positions_to_insert:
        if pos < len(paragraphs):
            target_paragraph = paragraphs[pos]
            # Insert link at the end of the paragraph (before </p>)
            modified_paragraph = target_paragraph[:-4] + f" {link_html}</p>"
            result = result.replace(target_paragraph, modified_paragraph, 1)
            # Update paragraphs list for next iteration
            paragraphs[pos] = modified_paragraph
    
    return result

async def generate_featured_image(title: str, provider: str, api_key: str, model: str = None) -> bytes:
    """Generate a featured image using AI based on post title - supports OpenAI and Gemini"""
    import base64
    
    # Create a prompt for featured image
    image_prompt = f"A professional, high-quality featured image for a blog post titled: '{title}'. Modern, clean design with visual elements related to the topic. No text overlay."
    
    try:
        if provider == "openai":
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=api_key)
            
            # Use model from settings or default to dall-e-3
            image_model = model if model and model.startswith("dall-e") else "dall-e-3"
            
            response = await client.images.generate(
                model=image_model,
                prompt=image_prompt,
                size="1792x1024",
                quality="standard",
                n=1,
                response_format="b64_json"
            )
            
            if response.data and len(response.data) > 0:
                image_data = base64.b64decode(response.data[0].b64_json)
                return image_data
            return None
            
        elif provider == "gemini":
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            
            # Use Imagen model for image generation
            imagen_model = genai.ImageGenerationModel("imagen-3.0-generate-002")
            
            response = await imagen_model.generate_images_async(
                prompt=image_prompt,
                number_of_images=1,
                aspect_ratio="16:9"
            )
            
            if response.images and len(response.images) > 0:
                # Gemini Imagen returns images directly
                return response.images[0]._pil_image.tobytes()
            return None
            
        else:
            # Claude doesn't have image generation, fallback to error
            logger.warning(f"Image provider {provider} not supported for image generation")
            return None
            
    except Exception as e:
        logger.error(f"Featured image generation failed ({provider}): {e}")
        return None

async def upload_media_to_wp(domain: dict, image_bytes: bytes, filename: str) -> dict:
    """Upload media to WordPress and return media object"""
    decrypted_password = decrypt_password(domain["wp_app_password_encrypted"])
    credentials = f"{domain['wp_username']}:{decrypted_password}"
    encoded = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "image/png",
        "Content-Disposition": f'attachment; filename="{filename}"'
    }
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            response = await client.post(
                f"{domain['url']}/wp-json/wp/v2/media",
                headers=headers,
                content=image_bytes
            )
            
            if response.status_code in [200, 201]:
                return response.json()
            else:
                logger.error(f"Media upload failed: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Media upload error: {e}")
            return None

@api_router.post("/ai/auto-post")
async def auto_post(request: AutoPostRequest, current_user: dict = Depends(require_active_subscription)):
    """Auto-generate and publish a post based on title only"""
    import json
    
    domain = await get_domain_with_credentials(request.domain_id, current_user["id"])
    
    # Get user settings for AI preferences
    user_settings = await db.user_settings.find_one({"user_id": current_user["id"]}, {"_id": 0})
    word_count = user_settings.get("ai_word_count", 800) if user_settings else 800
    auto_tags = user_settings.get("auto_generate_tags", True) if user_settings else True
    auto_categories = user_settings.get("auto_generate_categories", True) if user_settings else True
    image_ai_enabled = user_settings.get("image_ai_enabled", False) if user_settings else False
    auto_generate_seo = user_settings.get("auto_generate_seo", True) if user_settings else True
    
    # Determine content language: auto-detect from title or use specified language
    content_language = request.content_language or "auto"
    
    if content_language == "auto":
        # Auto-detect language from title using simple heuristics
        detected_language = detect_language_from_text(request.title)
        language = detected_language
    else:
        language = content_language
    
    # Map language codes to full language names
    language_map = {
        "id": "Bahasa Indonesia",
        "en": "English",
        "es": "Spanish (Español)",
        "fr": "French (Français)",
        "de": "German (Deutsch)",
        "pt": "Portuguese (Português)",
        "it": "Italian (Italiano)",
        "nl": "Dutch (Nederlands)",
        "ru": "Russian (Русский)",
        "ja": "Japanese (日本語)",
        "ko": "Korean (한국어)",
        "zh": "Chinese (中文)",
        "ar": "Arabic (العربية)",
        "hi": "Hindi (हिन्दी)",
        "th": "Thai (ไทย)",
        "vi": "Vietnamese (Tiếng Việt)",
        "ms": "Malay (Bahasa Melayu)",
        "tl": "Tagalog (Filipino)",
    }
    language_instruction = language_map.get(language, "English")
    
    # Get existing categories and tags from WordPress
    categories_response = await wp_request(
        "GET", f"{domain['url']}/wp-json/wp/v2/categories", domain, params={"per_page": 100}
    )
    existing_categories = categories_response.json() if categories_response.status_code == 200 else []
    
    tags_response = await wp_request(
        "GET", f"{domain['url']}/wp-json/wp/v2/tags", domain, params={"per_page": 100}
    )
    existing_tags = tags_response.json() if tags_response.status_code == 200 else []
    
    category_names = [c["name"] for c in existing_categories]
    tag_names = [t["name"] for t in existing_tags]
    
    # Get AI config using the universal helper
    provider, model, api_key_field = get_ai_config(user_settings)
    
    # Get encrypted API key for the selected provider
    encrypted_api_key = user_settings.get(api_key_field) if user_settings else None
    if not encrypted_api_key:
        raise HTTPException(status_code=400, detail=f"{provider.capitalize()} API key not configured. Please add your API key in Settings.")
    
    # Decrypt the API key
    api_key = decrypt_password(encrypted_api_key)
    
    system_message = f"""You are a professional blog content writer. You write engaging, informative, and SEO-friendly blog posts in {language_instruction}.
Your content should be well-structured with headings, paragraphs, and proper HTML formatting.
Always write in a professional yet engaging tone."""
    
    seo_instruction = ""
    if auto_generate_seo:
        seo_instruction = """
Also generate SEO metadata:
- meta_description: A compelling 150-160 character meta description for search engines
- focus_keyword: The primary keyword/keyphrase this article targets
- secondary_keywords: 3-5 related keywords"""

    prompt = f"""Write a comprehensive blog post about: "{request.title}"

IMPORTANT: Write in {language_instruction}

Requirements:
1. Write a detailed article with MINIMUM {word_count} words
2. Use proper HTML formatting: <h2>, <h3>, <p>, <ul>, <li>, <strong>, <em> tags
3. Include an engaging introduction
4. Include 3-5 main sections with subheadings
5. Include a conclusion
6. Make it informative and engaging

Also suggest:
- 1-2 categories (prefer from existing: {category_names[:20] if category_names else 'create new relevant ones'})
- 3-5 relevant tags (prefer from existing: {tag_names[:30] if tag_names else 'create new relevant ones'})
{seo_instruction}

Respond in this exact JSON format:
{{
    "content": "<your HTML formatted article here>",
    "suggested_categories": ["category1"],
    "suggested_tags": ["tag1", "tag2", "tag3"],
    "seo": {{
        "meta_description": "Your SEO meta description here",
        "focus_keyword": "main keyword",
        "secondary_keywords": ["keyword1", "keyword2", "keyword3"],
        "seo_score": 85
    }}
}}

For seo_score, rate 0-100 based on: keyword usage in title/headings, content length, readability, keyword density.

Only respond with the JSON, no other text."""

    try:
        # Use the universal AI provider caller
        response_text = await call_ai_provider(provider, model, api_key, system_message, prompt)
        
        # Parse JSON response
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]
        response_text = response_text.strip()
        
        result = json.loads(response_text)
        content = result.get("content", "")
        suggested_categories = result.get("suggested_categories", [])
        suggested_tags = result.get("suggested_tags", [])
        seo_data = result.get("seo", {}) if auto_generate_seo else {}
        
        # Inject links if configured
        if request.link_injection and request.link_injection.enabled:
            content = inject_links_into_content(content, request.link_injection)
        
        # Process categories - get existing IDs or create new ones
        category_ids = []
        if auto_categories and suggested_categories:
            for cat_name in suggested_categories[:2]:
                # Check if exists
                found = False
                for cat in existing_categories:
                    if cat["name"].lower() == cat_name.lower():
                        category_ids.append(cat["id"])
                        found = True
                        break
                
                # Create if not found
                if not found:
                    try:
                        create_response = await wp_request(
                            "POST", f"{domain['url']}/wp-json/wp/v2/categories", domain,
                            json={"name": cat_name}
                        )
                        if create_response.status_code in [200, 201]:
                            new_cat = create_response.json()
                            category_ids.append(new_cat["id"])
                    except Exception as e:
                        logger.warning(f"Failed to create category {cat_name}: {e}")
        
        # Process tags - get existing IDs or create new ones
        tag_ids = []
        if auto_tags and suggested_tags:
            for tag_name in suggested_tags[:5]:
                # Check if exists
                found = False
                for tag in existing_tags:
                    if tag["name"].lower() == tag_name.lower():
                        tag_ids.append(tag["id"])
                        found = True
                        break
                
                # Create if not found
                if not found:
                    try:
                        create_response = await wp_request(
                            "POST", f"{domain['url']}/wp-json/wp/v2/tags", domain,
                            json={"name": tag_name}
                        )
                        if create_response.status_code in [200, 201]:
                            new_tag = create_response.json()
                            tag_ids.append(new_tag["id"])
                    except Exception as e:
                        logger.warning(f"Failed to create tag {tag_name}: {e}")
        
        # Generate featured image if enabled (both in settings AND per-request)
        featured_media_id = None
        featured_image_url = None
        # Use request.generate_featured_image if provided, otherwise fall back to user settings
        should_generate_image = request.generate_featured_image if request.generate_featured_image else image_ai_enabled
        
        if should_generate_image:
            try:
                logger.info(f"Generating featured image for: {request.title}")
                # Get image AI provider settings
                image_provider = user_settings.get("image_ai_provider", "openai") if user_settings else "openai"
                image_model = user_settings.get("image_ai_model", "dall-e-3") if user_settings else "dall-e-3"
                
                # Get the correct API key for image provider
                image_api_key_field = {
                    "openai": "openai_api_key",
                    "gemini": "gemini_api_key"
                }.get(image_provider, "openai_api_key")
                
                image_encrypted_key = user_settings.get(image_api_key_field) if user_settings else None
                if image_encrypted_key:
                    image_api_key = decrypt_password(image_encrypted_key)
                    image_bytes = await generate_featured_image(request.title, image_provider, image_api_key, image_model)
                    if image_bytes:
                        # Create a slug from the title for filename
                        import re
                        slug = re.sub(r'[^a-zA-Z0-9]+', '-', request.title.lower())[:50]
                        filename = f"featured-{slug}-{uuid.uuid4().hex[:8]}.png"
                        
                        # Upload to WordPress
                        media_result = await upload_media_to_wp(domain, image_bytes, filename)
                        if media_result:
                            featured_media_id = media_result.get("id")
                            featured_image_url = media_result.get("source_url")
                            logger.info(f"Featured image uploaded: {featured_media_id}")
                else:
                    logger.warning(f"Image AI enabled but {image_provider} API key not configured")
            except Exception as e:
                logger.warning(f"Featured image generation failed, continuing without image: {e}")
        
        # Create and publish/schedule the post
        post_data = {
            "title": request.title,
            "content": content,
            "status": "publish" if not request.scheduled_date else "future"
        }
        if request.scheduled_date:
            post_data["date"] = request.scheduled_date
        if category_ids:
            post_data["categories"] = category_ids
        if tag_ids:
            post_data["tags"] = tag_ids
        if featured_media_id:
            post_data["featured_media"] = featured_media_id
        
        post_response = await wp_request(
            "POST", f"{domain['url']}/wp-json/wp/v2/posts", domain,
            data=post_data
        )
        
        if post_response.status_code not in [200, 201]:
            raise HTTPException(status_code=post_response.status_code, detail=f"Failed to create post: {post_response.text}")
        
        published_post = post_response.json()
        
        # Log activity
        await log_activity(current_user["id"], current_user["name"], current_user["username"], "AUTO_POST", f"Created auto-post: {request.title} on {domain.get('name')}", "", current_user.get("role", ""))
        
        return {
            "success": True,
            "post": {
                "id": published_post["id"],
                "title": published_post["title"]["rendered"],
                "link": published_post["link"],
                "status": published_post["status"],
                "scheduled_date": request.scheduled_date,
                "featured_image": featured_image_url
            },
            "generated": {
                "word_count": len(content.split()),
                "categories": suggested_categories,
                "tags": suggested_tags,
                "category_ids": category_ids,
                "tag_ids": tag_ids,
                "has_featured_image": featured_media_id is not None
            },
            "seo": seo_data if auto_generate_seo else None
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse AI response: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse AI response")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Auto post error: {e}")
        raise HTTPException(status_code=500, detail=f"Auto post failed: {str(e)}")

# ==================== SEO ASSISTANT ====================

class SEOAnalyzeRequest(BaseModel):
    title: str
    content: str
    focus_keyword: Optional[str] = None

@api_router.post("/ai/seo-analyze")
async def analyze_seo(request: SEOAnalyzeRequest, current_user: dict = Depends(get_current_user)):
    """Analyze content for SEO and provide suggestions"""
    
    # Get user settings and AI config
    user_settings = await db.user_settings.find_one({"user_id": current_user["id"]}, {"_id": 0})
    provider, model, api_key_field = get_ai_config(user_settings)
    
    # Get encrypted API key for the selected provider
    encrypted_api_key = user_settings.get(api_key_field) if user_settings else None
    
    if not encrypted_api_key:
        raise HTTPException(status_code=400, detail=f"{provider.capitalize()} API key not configured. Please add your API key in Settings.")
    
    # Decrypt the API key
    api_key = decrypt_password(encrypted_api_key)
    
    language = user_settings.get("language", "id") if user_settings else "id"
    language_instruction = "Bahasa Indonesia" if language == "id" else "English"
    
    # Calculate basic metrics
    word_count = len(request.content.split())
    char_count = len(request.content)
    
    system_message = "You are an expert SEO analyst. Analyze content and provide actionable SEO recommendations."
    
    focus_kw_text = f'Focus keyword: "{request.focus_keyword}"' if request.focus_keyword else "No focus keyword specified"
    
    prompt = f"""Analyze the following blog post for SEO optimization:

Title: "{request.title}"
{focus_kw_text}
Word Count: {word_count}

Content (first 2000 chars):
{request.content[:2000]}

Provide SEO analysis in {language_instruction}. Respond in this exact JSON format:
{{
    "seo_score": 75,
    "meta_description": "Optimized 150-160 char meta description",
    "focus_keyword": "suggested or provided focus keyword",
    "secondary_keywords": ["keyword1", "keyword2", "keyword3"],
    "title_analysis": {{
        "score": 80,
        "has_keyword": true,
        "length_ok": true,
        "suggestions": ["suggestion 1"]
    }},
    "content_analysis": {{
        "score": 70,
        "keyword_density": 1.5,
        "headings_ok": true,
        "readability": "good",
        "suggestions": ["suggestion 1", "suggestion 2"]
    }},
    "improvements": [
        "High priority improvement 1",
        "Medium priority improvement 2",
        "Low priority improvement 3"
    ]
}}

Only respond with JSON, no other text."""

    try:
        # Use the universal AI provider caller
        response_text = await call_ai_provider(provider, model, api_key, system_message, prompt)
        
        # Parse JSON response
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]
        response_text = response_text.strip()
        
        result = json.loads(response_text)
        
        # Add word count info
        result["word_count"] = word_count
        result["char_count"] = char_count
        
        return result
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse SEO response: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse AI response")
    except Exception as e:
        logger.error(f"SEO analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"SEO analysis failed: {str(e)}")

# ==================== CACHE MANAGEMENT ====================

@api_router.post("/cache/clear")
async def clear_cache(domain_id: Optional[str] = None, current_user: dict = Depends(get_current_user)):
    """Clear WordPress data cache - all users can clear cache for their accessible domains"""
    if domain_id:
        # Verify user has access to this domain (for admin/staff, check domain ownership)
        if current_user["role"] != "superadmin":
            domain = await db.domains.find_one({"id": domain_id, "user_id": current_user["id"]}, {"_id": 0})
            if not domain:
                raise HTTPException(status_code=403, detail="You don't have access to this domain")
        
        # Clear cache for specific domain
        count = clear_domain_cache(domain_id)
        return {"success": True, "message": f"Cleared {count} cached items for domain", "cleared": count}
    else:
        # For non-superadmin, only clear cache for their domains
        if current_user["role"] != "superadmin":
            # Get user's domains and clear cache for each
            user_domains = await db.domains.find({"user_id": current_user["id"]}, {"_id": 0, "id": 1}).to_list(1000)
            total_cleared = 0
            for domain in user_domains:
                total_cleared += clear_domain_cache(domain["id"])
            return {"success": True, "message": f"Cleared {total_cleared} cached items for your domains", "cleared": total_cleared}
        else:
            # Superadmin can clear all cache
            count = clear_all_cache()
            return {"success": True, "message": f"Cleared all {count} cached items", "cleared": count}

@api_router.get("/cache/stats")
async def get_cache_stats(current_user: dict = Depends(get_current_user)):
    """Get cache statistics"""
    cache_items = []
    for key, value in _wp_cache.items():
        cache_type = key.split('_')[0]
        ttl = CACHE_TTL.get(cache_type, 60)
        age = time.time() - value['timestamp']
        cache_items.append({
            "key": key,
            "type": cache_type,
            "age_seconds": round(age),
            "ttl_seconds": ttl,
            "expires_in": max(0, round(ttl - age))
        })
    
    return {
        "total_items": len(_wp_cache),
        "items": cache_items,
        "ttl_config": CACHE_TTL
    }

# ==================== USER SETTINGS ====================

@api_router.get("/settings", response_model=UserSettingsResponse)
async def get_settings(current_user: dict = Depends(get_current_user)):
    """Get current user settings"""
    settings = await db.user_settings.find_one({"user_id": current_user["id"]}, {"_id": 0})
    
    if not settings:
        return UserSettingsResponse()
    
    return UserSettingsResponse(
        article_ai_provider=settings.get("article_ai_provider", "openai"),
        article_ai_model=settings.get("article_ai_model", "gpt-4o-mini"),
        openai_api_key_set=bool(settings.get("openai_api_key")),
        gemini_api_key_set=bool(settings.get("gemini_api_key")),
        claude_api_key_set=bool(settings.get("claude_api_key")),
        image_ai_provider=settings.get("image_ai_provider", "openai"),
        image_ai_enabled=settings.get("image_ai_enabled", False),
        default_post_status=settings.get("default_post_status", "draft"),
        auto_generate_tags=settings.get("auto_generate_tags", True),
        auto_generate_categories=settings.get("auto_generate_categories", True),
        auto_generate_seo=settings.get("auto_generate_seo", True),
        ai_word_count=settings.get("ai_word_count", 800),
        language=settings.get("language", "id"),
        custom_prompt_enabled=settings.get("custom_prompt_enabled", False),
        custom_prompt=settings.get("custom_prompt", "")
    )

@api_router.put("/settings", response_model=UserSettingsResponse)
async def update_settings(settings_data: UserSettingsUpdate, current_user: dict = Depends(require_not_staff)):
    """Update user settings - Staff cannot access"""
    user_id = current_user["id"]
    existing = await db.user_settings.find_one({"user_id": user_id})
    
    update_data = {"user_id": user_id, "updated_at": datetime.now(timezone.utc).isoformat()}
    
    # Handle API keys - encrypt if provided
    for key_name in ["openai_api_key", "gemini_api_key", "claude_api_key"]:
        key_value = getattr(settings_data, key_name, None)
        if key_value is not None:
            if key_value.strip():
                update_data[key_name] = encrypt_password(key_value)
            else:
                update_data[key_name] = None
        elif existing:
            update_data[key_name] = existing.get(key_name)
    
    # Update AI provider settings
    if settings_data.article_ai_provider is not None:
        update_data["article_ai_provider"] = settings_data.article_ai_provider
    if settings_data.article_ai_model is not None:
        update_data["article_ai_model"] = settings_data.article_ai_model
    if settings_data.image_ai_provider is not None:
        update_data["image_ai_provider"] = settings_data.image_ai_provider
    if settings_data.image_ai_enabled is not None:
        update_data["image_ai_enabled"] = settings_data.image_ai_enabled
    
    # Update content settings
    if settings_data.default_post_status is not None:
        update_data["default_post_status"] = settings_data.default_post_status
    if settings_data.auto_generate_tags is not None:
        update_data["auto_generate_tags"] = settings_data.auto_generate_tags
    if settings_data.auto_generate_categories is not None:
        update_data["auto_generate_categories"] = settings_data.auto_generate_categories
    if settings_data.auto_generate_seo is not None:
        update_data["auto_generate_seo"] = settings_data.auto_generate_seo
    if settings_data.ai_word_count is not None:
        update_data["ai_word_count"] = settings_data.ai_word_count
    if settings_data.language is not None:
        update_data["language"] = settings_data.language
    if settings_data.custom_prompt_enabled is not None:
        update_data["custom_prompt_enabled"] = settings_data.custom_prompt_enabled
    if settings_data.custom_prompt is not None:
        update_data["custom_prompt"] = settings_data.custom_prompt
    
    await db.user_settings.update_one({"user_id": user_id}, {"$set": update_data}, upsert=True)
    
    return UserSettingsResponse(
        article_ai_provider=update_data.get("article_ai_provider", "openai"),
        article_ai_model=update_data.get("article_ai_model", "gpt-4o-mini"),
        openai_api_key_set=bool(update_data.get("openai_api_key")),
        gemini_api_key_set=bool(update_data.get("gemini_api_key")),
        claude_api_key_set=bool(update_data.get("claude_api_key")),
        image_ai_provider=update_data.get("image_ai_provider", "openai"),
        image_ai_enabled=update_data.get("image_ai_enabled", False),
        default_post_status=update_data.get("default_post_status", "draft"),
        auto_generate_tags=update_data.get("auto_generate_tags", True),
        auto_generate_categories=update_data.get("auto_generate_categories", True),
        auto_generate_seo=update_data.get("auto_generate_seo", True),
        ai_word_count=update_data.get("ai_word_count", 800),
        language=update_data.get("language", "id"),
        custom_prompt_enabled=update_data.get("custom_prompt_enabled", False),
        custom_prompt=update_data.get("custom_prompt", "")
    )

@api_router.delete("/settings/api-key")
async def delete_api_key(current_user: dict = Depends(require_not_staff)):
    """Delete stored OpenAI API key - Staff cannot access"""
    await db.user_settings.update_one(
        {"user_id": current_user["id"]},
        {"$set": {"openai_api_key": None}}
    )
    return {"success": True, "message": "API key deleted"}

@api_router.delete("/settings/api-key/{provider}")
async def delete_specific_api_key(provider: str, current_user: dict = Depends(require_not_staff)):
    """Delete a specific API key by provider - Staff cannot access"""
    valid_providers = ["openai", "gemini", "claude"]
    if provider not in valid_providers:
        raise HTTPException(status_code=400, detail=f"Invalid provider. Must be one of: {valid_providers}")
    
    key_field = f"{provider}_api_key"
    await db.user_settings.update_one(
        {"user_id": current_user["id"]},
        {"$set": {key_field: None}}
    )
    return {"success": True, "message": f"{provider.capitalize()} API key deleted"}

# ==================== TEAM MANAGEMENT ====================

@api_router.get("/team/members")
async def list_team_members(current_user: dict = Depends(get_current_user)):
    """List team members based on role hierarchy:
    - Superadmin: sees all (superadmin, admin, staff)
    - Admin: sees admin and staff only (not superadmin)
    - Staff: sees only staff (not admin or superadmin)
    """
    user_role = current_user.get("role")
    
    if user_role == "superadmin":
        # Superadmin sees everyone
        members = await db.users.find({}, {"_id": 0, "password_hash": 0}).to_list(100)
    elif user_role == "admin":
        # Admin sees admin and staff only (not superadmin)
        members = await db.users.find(
            {"role": {"$in": ["admin", "staff"]}},
            {"_id": 0, "password_hash": 0}
        ).to_list(100)
    else:
        # Staff sees only staff
        members = await db.users.find(
            {"role": "staff"},
            {"_id": 0, "password_hash": 0}
        ).to_list(100)
    
    return {"members": members}

@api_router.post("/team/members")
async def create_team_member(member_data: TeamMemberCreate, current_user: dict = Depends(require_admin_or_above)):
    """Create a new team member:
    - Superadmin can create admin
    - Admin can create staff
    """
    # Check team member limit (-1 = unlimited)
    limits = await get_app_limits()
    if limits["max_team_members"] >= 0:  # -1 means unlimited
        members_count = await db.users.count_documents({"role": {"$ne": "superadmin"}})
        if members_count >= limits["max_team_members"]:
            raise HTTPException(
                status_code=400,
                detail=f"Batas maksimal team member ({limits['max_team_members']}) sudah tercapai. Hubungi Superadmin untuk menambah limit."
            )
    
    user_role = current_user.get("role")
    
    # Determine what role the new member will have
    if user_role == "superadmin":
        new_member_role = "admin"  # Superadmin creates admin
    elif user_role == "admin":
        new_member_role = "staff"  # Admin creates staff
    else:
        raise HTTPException(status_code=403, detail="Cannot create team members")
    
    # Check if username already exists
    existing = await db.users.find_one({"username": member_data.username})
    if existing:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    user_id = str(uuid.uuid4())
    user_doc = {
        "id": user_id,
        "username": member_data.username,
        "name": member_data.name,
        "password_hash": hash_password(member_data.password),
        "role": new_member_role,
        "avatar": None,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "invited_by": current_user["id"]
    }
    
    await db.users.insert_one(user_doc)
    
    return {
        "id": user_id,
        "username": member_data.username,
        "name": member_data.name,
        "role": new_member_role,
        "avatar": None,
        "created_at": user_doc["created_at"]
    }

@api_router.put("/team/members/{member_id}")
async def update_team_member(member_id: str, member_data: TeamMemberUpdate, current_user: dict = Depends(require_admin_or_above)):
    """Update a team member based on role hierarchy:
    - Superadmin can update admin
    - Admin can update staff
    """
    member = await db.users.find_one({"id": member_id})
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    
    user_role = current_user.get("role")
    member_role = member.get("role")
    
    # Check permission based on hierarchy
    if user_role == "superadmin":
        # Superadmin can update anyone except other superadmin
        if member_role == "superadmin" and member_id != current_user["id"]:
            raise HTTPException(status_code=400, detail="Cannot modify other superadmin")
    elif user_role == "admin":
        # Admin can only update staff
        if member_role != "staff":
            raise HTTPException(status_code=403, detail="Admin can only update staff members")
    else:
        raise HTTPException(status_code=403, detail="Cannot update team members")
    
    # Prevent changing roles (role is fixed based on who created them)
    update_data = {k: v for k, v in member_data.model_dump().items() if v is not None}
    update_data.pop("role", None)  # Remove role from update
    
    if update_data:
        await db.users.update_one({"id": member_id}, {"$set": update_data})
    
    updated = await db.users.find_one({"id": member_id}, {"_id": 0, "password_hash": 0})
    return updated

class ResetPasswordRequest(BaseModel):
    new_password: str

@api_router.post("/team/members/{member_id}/reset-password")
async def reset_member_password(member_id: str, password_data: ResetPasswordRequest, current_user: dict = Depends(require_admin_or_above)):
    """Reset a team member's password based on role hierarchy:
    - Superadmin can reset admin and staff passwords
    - Admin can reset staff passwords only
    """
    member = await db.users.find_one({"id": member_id})
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    
    user_role = current_user.get("role")
    member_role = member.get("role")
    
    # Cannot reset own password here (use profile endpoint)
    if member_id == current_user["id"]:
        raise HTTPException(status_code=400, detail="Use profile settings to change your own password")
    
    # Check permission based on hierarchy
    if user_role == "superadmin":
        # Superadmin can reset admin and staff, but not other superadmin
        if member_role == "superadmin":
            raise HTTPException(status_code=400, detail="Cannot reset superadmin password")
    elif user_role == "admin":
        # Admin can only reset staff passwords
        if member_role != "staff":
            raise HTTPException(status_code=403, detail="Admin can only reset staff passwords")
    else:
        raise HTTPException(status_code=403, detail="Cannot reset passwords")
    
    # Validate password length
    if len(password_data.new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
    
    # Update password
    await db.users.update_one(
        {"id": member_id},
        {"$set": {"password_hash": hash_password(password_data.new_password)}}
    )
    
    return {"success": True, "message": f"Password for {member.get('name') or member.get('username')} has been reset"}

@api_router.delete("/team/members/{member_id}")
async def delete_team_member(member_id: str, current_user: dict = Depends(require_admin_or_above)):
    """Delete a team member based on role hierarchy:
    - Superadmin can delete admin and staff
    - Admin can delete staff only
    """
    member = await db.users.find_one({"id": member_id})
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    
    user_role = current_user.get("role")
    member_role = member.get("role")
    
    # Prevent self-deletion
    if member_id == current_user["id"]:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")
    
    # Check permission based on hierarchy
    if user_role == "superadmin":
        # Superadmin can delete admin and staff, but not other superadmin
        if member_role == "superadmin":
            raise HTTPException(status_code=400, detail="Cannot delete superadmin")
    elif user_role == "admin":
        # Admin can only delete staff
        if member_role != "staff":
            raise HTTPException(status_code=403, detail="Admin can only delete staff members")
    else:
        raise HTTPException(status_code=403, detail="Cannot delete team members")
    
    await db.users.delete_one({"id": member_id})
    return {"success": True, "message": "Member deleted"}

@api_router.put("/auth/profile")
async def update_profile(profile_data: TeamMemberUpdate, current_user: dict = Depends(get_current_user)):
    """Update own profile"""
    update_data = {}
    if profile_data.name:
        update_data["name"] = profile_data.name
    if profile_data.username:
        # Check if username is already taken
        existing = await db.users.find_one({"username": profile_data.username, "id": {"$ne": current_user["id"]}})
        if existing:
            raise HTTPException(status_code=400, detail="Username already in use")
        update_data["username"] = profile_data.username
    if profile_data.avatar is not None:
        update_data["avatar"] = profile_data.avatar
    
    if update_data:
        await db.users.update_one({"id": current_user["id"]}, {"$set": update_data})
    
    updated = await db.users.find_one({"id": current_user["id"]}, {"_id": 0, "password_hash": 0})
    return updated

@api_router.put("/auth/password")
async def change_password(password_data: PasswordChange, current_user: dict = Depends(get_current_user)):
    """Change own password"""
    user = await db.users.find_one({"id": current_user["id"]})
    
    if not verify_password(password_data.current_password, user["password_hash"]):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    
    new_hash = hash_password(password_data.new_password)
    await db.users.update_one({"id": current_user["id"]}, {"$set": {"password_hash": new_hash}})
    
    return {"success": True, "message": "Password changed successfully"}

# ==================== IP WHITELIST MANAGEMENT (Superadmin Only) ====================

class IPWhitelistAdd(BaseModel):
    ip_address: str
    description: Optional[str] = None

@api_router.get("/settings/ip-whitelist")
async def get_ip_whitelist(current_user: dict = Depends(require_superadmin)):
    """Get all whitelisted IPs (superadmin only)"""
    whitelist = await db.ip_whitelist.find({}, {"_id": 0}).to_list(100)
    return {"whitelist": whitelist}

@api_router.post("/settings/ip-whitelist")
async def add_ip_whitelist(data: IPWhitelistAdd, current_user: dict = Depends(require_superadmin)):
    """Add IP to whitelist (superadmin only)"""
    import re
    
    # Validate IP format (IPv4 or IPv6 or CIDR notation)
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}(/\d{1,2})?$|^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
    if not re.match(ip_pattern, data.ip_address):
        raise HTTPException(status_code=400, detail="Invalid IP address format")
    
    # Check if IP already exists
    existing = await db.ip_whitelist.find_one({"ip_address": data.ip_address})
    if existing:
        raise HTTPException(status_code=400, detail="IP address already whitelisted")
    
    ip_entry = {
        "id": str(uuid.uuid4()),
        "ip_address": data.ip_address,
        "description": data.description or "",
        "added_by": current_user["id"],
        "added_by_name": current_user.get("name", "Unknown"),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.ip_whitelist.insert_one(ip_entry)
    if "_id" in ip_entry:
        del ip_entry["_id"]
    
    return {"success": True, "message": "IP added to whitelist", "entry": ip_entry}

@api_router.delete("/settings/ip-whitelist/{ip_id}")
async def delete_ip_whitelist(ip_id: str, current_user: dict = Depends(require_superadmin)):
    """Remove IP from whitelist (superadmin only)"""
    result = await db.ip_whitelist.delete_one({"id": ip_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="IP not found in whitelist")
    
    return {"success": True, "message": "IP removed from whitelist"}

# ==================== ACTIVITY LOGS (Superadmin Only) ====================

async def log_activity(user_id: str, user_name: str, username: str, action: str, details: str = "", ip_address: str = "", role: str = ""):
    """Helper function to log user activity - Superadmin logged as 'System'"""
    # If user is superadmin, log as System/WPMTools
    display_name = user_name
    display_username = username
    if role == "superadmin":
        display_name = "System"
        display_username = "WPMTools"
    
    log_entry = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "user_name": display_name,
        "username": display_username,
        "action": action,
        "details": details,
        "ip_address": ip_address,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.activity_logs.insert_one(log_entry)

@api_router.get("/settings/activity-logs")
async def get_activity_logs(
    current_user: dict = Depends(require_superadmin),
    limit: int = 100,
    skip: int = 0
):
    """Get all activity logs (superadmin only)"""
    logs = await db.activity_logs.find({}, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    total = await db.activity_logs.count_documents({})
    return {"logs": logs, "total": total}

@api_router.delete("/settings/activity-logs")
async def clear_activity_logs(current_user: dict = Depends(require_superadmin)):
    """Clear all activity logs (superadmin only)"""
    result = await db.activity_logs.delete_many({})
    return {"success": True, "message": f"Cleared {result.deleted_count} logs"}

# ==================== APP LIMITS (Superadmin only) ====================

@api_router.get("/settings/limits", response_model=AppLimitsResponse)
async def get_limits(current_user: dict = Depends(require_superadmin)):
    """Get app-wide limits (superadmin only)"""
    limits = await get_app_limits()
    return AppLimitsResponse(**limits)

@api_router.put("/settings/limits", response_model=AppLimitsResponse)
async def update_limits(limits_data: AppLimitsUpdate, current_user: dict = Depends(require_superadmin)):
    """Update app-wide limits (superadmin only)"""
    current_limits = await get_app_limits()
    
    # Update only provided fields
    update_data = {k: v for k, v in limits_data.model_dump().items() if v is not None}
    if update_data:
        current_limits.update(update_data)
        current_limits["type"] = "limits"
        current_limits["updated_at"] = datetime.now(timezone.utc).isoformat()
        current_limits["updated_by"] = current_user["id"]
        
        await db.app_settings.update_one(
            {"type": "limits"},
            {"$set": current_limits},
            upsert=True
        )
    
    return AppLimitsResponse(**current_limits)

@api_router.get("/settings/limits/usage")
async def get_limits_usage(current_user: dict = Depends(get_current_user)):
    """Get current usage against limits. -1 in limits means unlimited."""
    limits = await get_app_limits()
    
    # Count current usage
    domains_count = await db.domains.count_documents({})
    members_count = await db.users.count_documents({"role": {"$ne": "superadmin"}})
    
    # Count today's posts
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    posts_today = await db.activity_logs.count_documents({
        "action": "AUTO_POST",
        "created_at": {"$gte": today_start.isoformat()}
    })
    
    # Count today's AI requests (rough estimate from auto-posts)
    ai_requests_today = posts_today  # Each auto-post = 1 AI request minimum
    
    # Calculate remaining (-1 means unlimited, show -1 for remaining too)
    def calc_remaining(limit, used):
        if limit < 0:  # Unlimited
            return -1
        return max(0, limit - used)
    
    return {
        "limits": limits,
        "usage": {
            "domains": domains_count,
            "team_members": members_count,
            "posts_today": posts_today,
            "ai_requests_today": ai_requests_today
        },
        "remaining": {
            "domains": calc_remaining(limits["max_domains"], domains_count),
            "team_members": calc_remaining(limits["max_team_members"], members_count),
            "posts_today": calc_remaining(limits["max_posts_per_day"], posts_today),
            "ai_requests_today": calc_remaining(limits["max_ai_requests_per_day"], ai_requests_today)
        }
    }

# ==================== INSTALLATION WIZARD ====================

class SetupStatusResponse(BaseModel):
    is_setup_complete: bool
    has_users: bool
    has_app_config: bool

class SetupCompleteRequest(BaseModel):
    # Superadmin account
    username: str
    password: str
    name: str
    # App config
    app_name: str = "WPMTools"
    default_language: str = "id"
    timezone: str = "Asia/Jakarta"
    # Optional AI keys (can skip)
    openai_api_key: Optional[str] = None
    gemini_api_key: Optional[str] = None
    claude_api_key: Optional[str] = None

@api_router.get("/setup/status")
async def get_setup_status():
    """Check if initial setup has been completed"""
    # Check if any users exist
    users_count = await db.users.count_documents({})
    has_users = users_count > 0
    
    # Check if app config exists
    app_config = await db.app_settings.find_one({"type": "app_config"})
    has_app_config = app_config is not None
    
    # Setup is complete if there are users (either from wizard or seed.py)
    # App config is optional for backwards compatibility
    return SetupStatusResponse(
        is_setup_complete=has_users,  # Changed: only check users
        has_users=has_users,
        has_app_config=has_app_config
    )

@api_router.get("/setup/check-db")
async def check_database_connection():
    """Check MongoDB connection for setup wizard"""
    try:
        await db.command("ping")
        # Get database name
        return {
            "connected": True,
            "database": os.environ.get('DB_NAME', 'unknown'),
            "message": "Database connection successful"
        }
    except Exception as e:
        return {
            "connected": False,
            "database": None,
            "message": f"Connection failed: {str(e)}"
        }

@api_router.post("/setup/complete")
async def complete_setup(setup_data: SetupCompleteRequest):
    """Complete the initial setup - creates superadmin and app config"""
    # Check if setup already completed
    users_count = await db.users.count_documents({})
    if users_count > 0:
        raise HTTPException(
            status_code=400,
            detail="Setup already completed. Cannot run setup wizard again."
        )
    
    # Validate username
    if len(setup_data.username) < 3:
        raise HTTPException(status_code=400, detail="Username must be at least 3 characters")
    
    # Validate password
    if len(setup_data.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    
    # Create superadmin user
    user_id = str(uuid.uuid4())
    superadmin_doc = {
        "id": user_id,
        "username": setup_data.username,
        "name": setup_data.name,
        "password_hash": hash_password(setup_data.password),
        "role": "superadmin",
        "avatar": None,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.users.insert_one(superadmin_doc)
    
    # Create app config
    app_config = {
        "type": "app_config",
        "app_name": setup_data.app_name,
        "default_language": setup_data.default_language,
        "timezone": setup_data.timezone,
        "setup_completed_at": datetime.now(timezone.utc).isoformat(),
        "setup_by": user_id
    }
    await db.app_settings.update_one(
        {"type": "app_config"},
        {"$set": app_config},
        upsert=True
    )
    
    # Create user settings with AI keys if provided
    user_settings = {
        "user_id": user_id,
        "language": setup_data.default_language,
        "article_ai_provider": "openai",
        "article_ai_model": "gpt-4o-mini",
        "default_post_status": "draft",
        "auto_generate_tags": True,
        "auto_generate_categories": True,
        "auto_generate_seo": True,
        "ai_word_count": 800
    }
    
    # Encrypt and store API keys if provided
    if setup_data.openai_api_key:
        user_settings["openai_api_key"] = fernet.encrypt(setup_data.openai_api_key.encode()).decode()
    if setup_data.gemini_api_key:
        user_settings["gemini_api_key"] = fernet.encrypt(setup_data.gemini_api_key.encode()).decode()
    if setup_data.claude_api_key:
        user_settings["claude_api_key"] = fernet.encrypt(setup_data.claude_api_key.encode()).decode()
    
    await db.user_settings.insert_one(user_settings)
    
    # Generate JWT token for auto-login
    token = jwt.encode(
        {
            "user_id": user_id,
            "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS)
        },
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )
    
    # Return token and user for auto-login
    return {
        "success": True,
        "message": "Setup completed successfully!",
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "username": setup_data.username,
            "name": setup_data.name,
            "role": "superadmin",
            "created_at": superadmin_doc["created_at"]
        }
    }

@api_router.get("/setup/config")
async def get_app_config():
    """Get app configuration (public endpoint for app name, etc)"""
    app_config = await db.app_settings.find_one({"type": "app_config"}, {"_id": 0})
    if not app_config:
        return {
            "app_name": "WPMTools",
            "default_language": "id",
            "timezone": "Asia/Jakarta"
        }
    return {
        "app_name": app_config.get("app_name", "WPMTools"),
        "default_language": app_config.get("default_language", "id"),
        "timezone": app_config.get("timezone", "Asia/Jakarta")
    }

# ==================== ROOT ROUTE ====================

@api_router.get("/")
async def root():
    return {"message": "WPMTools API", "version": "1.0.0"}

@api_router.get("/health")
async def health_check():
    """Health check endpoint for monitoring"""
    try:
        # Check MongoDB connection
        await db.command("ping")
        db_status = "healthy"
    except Exception as e:
        db_status = f"unhealthy: {str(e)}"
    
    return {
        "status": "ok" if db_status == "healthy" else "degraded",
        "version": "1.0.0",
        "database": db_status,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
