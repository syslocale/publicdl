import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from '../components/LanguageSwitcher';
import Logo from '../components/Logo';
import {
  ArrowLeft, Book, Globe, Plus, Settings, Sparkles, Users,
  FileText, Tag, Calendar, Image, Shield, Zap,
  ChevronDown, ChevronRight, CheckCircle2, AlertTriangle,
  Layers, FolderOpen, Search, Trash2, Edit,
  Crown, Rocket, Database, Clock, Key
} from 'lucide-react';

const Section = ({ id, title, icon: Icon, iconColor, children, expanded, onToggle }) => (
  <div className="border border-zinc-800 rounded-lg overflow-hidden">
    <button
      onClick={() => onToggle(id)}
      className="w-full flex items-center justify-between p-4 bg-zinc-900/50 hover:bg-zinc-800/50 transition-colors"
    >
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 ${iconColor} rounded-lg flex items-center justify-center`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <span className="font-medium text-white">{title}</span>
      </div>
      {expanded ? (
        <ChevronDown className="w-5 h-5 text-zinc-400" />
      ) : (
        <ChevronRight className="w-5 h-5 text-zinc-400" />
      )}
    </button>
    {expanded && (
      <div className="p-6 bg-zinc-900/30 border-t border-zinc-800">
        {children}
      </div>
    )}
  </div>
);

export default function DocsPage() {
  const [expandedSection, setExpandedSection] = useState('getting-started');
  const { t } = useLanguage();

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/terms">{t('legalTermsTitle')}</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/fair-use">{t('legalFairUseTitle')}</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
            <Book className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">{t('docsTitle')}</h1>
            <p className="text-zinc-400">{t('docsSubtitle')}</p>
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          <button onClick={() => toggleSection('installation')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Rocket className="w-5 h-5 text-rose-400 mb-2" />
            <p className="text-sm text-white font-medium">Install</p>
          </button>
          <button onClick={() => toggleSection('getting-started')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Zap className="w-5 h-5 text-amber-400 mb-2" />
            <p className="text-sm text-white font-medium">{t('quickLinkStart')}</p>
          </button>
          <button onClick={() => toggleSection('domain-management')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Globe className="w-5 h-5 text-blue-400 mb-2" />
            <p className="text-sm text-white font-medium">{t('quickLinkDomain')}</p>
          </button>
          <button onClick={() => toggleSection('ai-features')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Sparkles className="w-5 h-5 text-violet-400 mb-2" />
            <p className="text-sm text-white font-medium">{t('quickLinkAI')}</p>
          </button>
          <button onClick={() => toggleSection('team')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Users className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-white font-medium">{t('quickLinkTeam')}</p>
          </button>
        </div>

        {/* Documentation Sections */}
        <div className="space-y-4">
          
          {/* Installation Wizard */}
          <Section id="installation" expanded={expandedSection === "installation"} onToggle={toggleSection} title={t('docsInstallTitle')} icon={Rocket} iconColor="bg-rose-500">
            <div className="space-y-6">
              <div>
                <p className="text-sm text-zinc-400">{t('docsInstallIntro')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsInstallWhenTitle')}</h3>
                <p className="text-sm text-zinc-400">{t('docsInstallWhenContent')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsInstallStepsTitle')}</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-rose-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Rocket className="w-4 h-4 text-rose-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep1Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep1Desc')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Database className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep2Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep2Desc')}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-amber-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Crown className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep3Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep3Desc')}</p>
                      <p className="text-xs text-zinc-500 mt-1">{t('docsInstallStep3Items')}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Settings className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep4Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep4Desc')}</p>
                      <ul className="text-xs text-zinc-500 mt-1 space-y-1">
                        <li>• {t('docsInstallStep4Item1')}</li>
                        <li>• {t('docsInstallStep4Item2')}</li>
                        <li className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {t('docsInstallStep4Item3')}
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-violet-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Key className="w-4 h-4 text-violet-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep5Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep5Desc')}</p>
                      <p className="text-xs text-zinc-500 mt-1">{t('docsInstallStep5Items')}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-teal-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-4 h-4 text-teal-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsInstallStep6Title')}</p>
                      <p className="text-sm text-zinc-400">{t('docsInstallStep6Desc')}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsInstallAfterTitle')}</h3>
                <p className="text-sm text-zinc-400">{t('docsInstallAfterContent')}</p>
              </div>

              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <p className="text-amber-400 text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  <strong>{t('docsInstallSecurityTitle')}:</strong>
                </p>
                <p className="text-amber-400/80 text-sm mt-1">{t('docsInstallSecurityContent')}</p>
              </div>
            </div>
          </Section>

          {/* Getting Started */}
          <Section id="getting-started" expanded={expandedSection === "getting-started"} onToggle={toggleSection} title={t('docsGettingStartedTitle')} icon={Zap} iconColor="bg-amber-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsStep1Title')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsStep1Content1')}</p>
                  <p>{t('docsStep1Content2')}</p>
                  <p>{t('docsStep1Content3')}</p>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 flex items-center gap-2">
                      <Crown className="w-4 h-4" />
                      <strong>Note:</strong> {t('docsStep1Note')}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsStep2Title')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsStep2Intro')}</p>
                  <ol className="list-decimal list-inside space-y-1 ml-2">
                    <li>{t('docsStep2Content1')}</li>
                    <li><a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{t('docsStep2Content2')}</a></li>
                    <li>{t('docsStep2Content3')}</li>
                    <li>{t('docsStep2Content4')}</li>
                    <li>{t('docsStep2Content5')}</li>
                  </ol>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      <strong>{t('docsStep2Note')}</strong>
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsStep3Title')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsStep3Content')}</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Domain Management */}
          <Section id="domain-management" expanded={expandedSection === "domain-management"} onToggle={toggleSection} title={t('docsDomainTitle')} icon={Globe} iconColor="bg-blue-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsDomainAddTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsDomainAddIntro')}</p>
                  <ul className="space-y-3 mt-3">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">{t('docsDomainAddItem1Title')}</strong>
                        <p>{t('docsDomainAddItem1Desc')}</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">{t('docsDomainAddItem2Title')}</strong>
                        <p>{t('docsDomainAddItem2Desc')}</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">{t('docsDomainAddItem3Title')}</strong>
                        <p>{t('docsDomainAddItem3Desc')}</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsDomainAppPassTitle')}</h3>
                <div className="p-4 bg-zinc-800/50 rounded-lg">
                  <ol className="list-decimal list-inside space-y-2 text-sm text-zinc-400">
                    <li>{t('docsDomainAppPassStep1')}</li>
                    <li>{t('docsDomainAppPassStep2')}</li>
                    <li>{t('docsDomainAppPassStep3')}</li>
                    <li>{t('docsDomainAppPassStep4')}</li>
                    <li>{t('docsDomainAppPassStep5')}</li>
                    <li>{t('docsDomainAppPassStep6')}</li>
                    <li>{t('docsDomainAppPassStep7')}</li>
                  </ol>
                </div>
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg mt-3">
                  <p className="text-red-400 text-sm">{t('docsDomainAppPassNote')}</p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsDomainTestTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsDomainTestIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsDomainTestStep1')}</li>
                    <li>{t('docsDomainTestStep2')}</li>
                    <li>{t('docsDomainTestStep3')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsDomainFilterTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsDomainFilterIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsDomainFilterItem1')}</li>
                    <li>{t('docsDomainFilterItem2')}</li>
                    <li>{t('docsDomainFilterItem3')}</li>
                  </ul>
                </div>
              </div>
            </div>
          </Section>

          {/* Content Management */}
          <Section id="content-management" expanded={expandedSection === "content-management"} onToggle={toggleSection} title={t('docsContentTitle')} icon={FileText} iconColor="bg-indigo-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsContentPostsTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsContentPostsIntro')}</p>
                  <ul className="space-y-2 mt-2">
                    <li className="flex items-center gap-2">
                      <Plus className="w-4 h-4 text-blue-400" />
                      <span>{t('docsContentPostsCreate')}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Edit className="w-4 h-4 text-amber-400" />
                      <span>{t('docsContentPostsEdit')}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Trash2 className="w-4 h-4 text-red-400" />
                      <span>{t('docsContentPostsDelete')}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Search className="w-4 h-4 text-zinc-400" />
                      <span>{t('docsContentPostsSearch')}</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsContentPagesTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsContentPagesIntro')}</p>
                  <div className="grid grid-cols-3 gap-3 mt-2">
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <Layers className="w-5 h-5 text-violet-400 mx-auto mb-1" />
                      <p className="text-white text-xs">{t('pages')}</p>
                    </div>
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <Tag className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                      <p className="text-white text-xs">{t('tags')}</p>
                    </div>
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <FolderOpen className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                      <p className="text-white text-xs">{t('categories')}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsContentCategoryTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsContentCategoryIntro')}</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>{t('docsContentCategoryStep1')}</li>
                    <li>{t('docsContentCategoryStep2')}</li>
                    <li>{t('docsContentCategoryStep3')}</li>
                    <li>{t('docsContentCategoryStep4')}</li>
                  </ol>
                </div>
              </div>
            </div>
          </Section>

          {/* AI Features */}
          <Section id="ai-features" expanded={expandedSection === "ai-features"} onToggle={toggleSection} title={t('docsAITitle')} icon={Sparkles} iconColor="bg-violet-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsAIAutoPostTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsAIAutoPostIntro')}</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>{t('docsAIAutoPostStep1')}</li>
                    <li>{t('docsAIAutoPostStep2')}</li>
                    <li>{t('docsAIAutoPostStep3')}</li>
                    <li>{t('docsAIAutoPostStep4')}</li>
                  </ol>
                  <p className="mt-2">{t('docsAIAutoPostGenerate')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsAIAutoPostGen1')}</li>
                    <li>{t('docsAIAutoPostGen2')}</li>
                    <li>{t('docsAIAutoPostGen3')}</li>
                    <li>{t('docsAIAutoPostGen4')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsAIScheduleTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsAIScheduleIntro')}</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>{t('docsAIScheduleStep1')}</li>
                    <li>{t('docsAIScheduleStep2')}</li>
                    <li>{t('docsAIScheduleStep3')}</li>
                    <li>{t('docsAIScheduleStep4')}</li>
                  </ol>
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg mt-2">
                    <p className="text-blue-400 text-sm">{t('docsAIScheduleNote')}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsAIImageTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsAIImageIntro')}</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>{t('docsAIImageStep1')}</li>
                    <li>{t('docsAIImageStep2')}</li>
                    <li>{t('docsAIImageStep3')}</li>
                    <li>{t('docsAIImageStep4')}</li>
                  </ol>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 text-sm">{t('docsAIImageNote')}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsAISEOTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsAISEOIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsAISEOItem1')}</li>
                    <li>{t('docsAISEOItem2')}</li>
                    <li>{t('docsAISEOItem3')}</li>
                    <li>{t('docsAISEOItem4')}</li>
                  </ul>
                  <p className="mt-2">{t('docsAISEONote')}</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Settings */}
          <Section id="settings" expanded={expandedSection === "settings"} onToggle={toggleSection} title={t('docsSettingsTitle')} icon={Settings} iconColor="bg-zinc-600">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsSettingsArticleTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li>{t('docsSettingsArticleProvider')}</li>
                    <li>{t('docsSettingsArticleModel')}</li>
                    <li>{t('docsSettingsArticleKey')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsSettingsImageTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li>{t('docsSettingsImageEnable')}</li>
                    <li>{t('docsSettingsImageProvider')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsSettingsContentTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li>{t('docsSettingsContentWord')}</li>
                    <li>{t('docsSettingsContentLang')}</li>
                    <li>{t('docsSettingsContentTags')}</li>
                    <li>{t('docsSettingsContentCats')}</li>
                    <li>{t('docsSettingsContentSEO')}</li>
                    <li>{t('docsSettingsContentPrompt')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsSettingsCacheTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsSettingsCacheIntro')}</p>
                  <ul className="space-y-1 mt-2">
                    <li>• {t('docsSettingsCacheStats')}</li>
                    <li>• {t('docsSettingsCachePosts')}</li>
                    <li>• {t('docsSettingsCacheTags')}</li>
                  </ul>
                  <p className="mt-2">{t('docsSettingsCacheNote')}</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Team Management */}
          <Section id="team" expanded={expandedSection === "team"} onToggle={toggleSection} title={t('docsTeamTitle')} icon={Users} iconColor="bg-emerald-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTeamRolesTitle')}</h3>
                <div className="space-y-3 text-sm text-zinc-400">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-amber-500/20 rounded-lg">
                      <Crown className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsTeamSuperadminTitle')}</p>
                      <p>{t('docsTeamSuperadminDesc')}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-indigo-500/20 rounded-lg">
                      <Users className="w-4 h-4 text-indigo-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{t('docsTeamAdminTitle')}</p>
                      <p>{t('docsTeamAdminDesc')}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTeamAddTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsTeamAddIntro')}</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>{t('docsTeamAddStep1')}</li>
                    <li>{t('docsTeamAddStep2')}</li>
                    <li>{t('docsTeamAddStep3')}</li>
                    <li>{t('docsTeamAddStep4')}</li>
                    <li>{t('docsTeamAddStep5')}</li>
                  </ol>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTeamProfileTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsTeamProfileIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsTeamProfileItem1')}</li>
                    <li>{t('docsTeamProfileItem2')}</li>
                  </ul>
                  <p className="text-amber-400 text-xs mt-2">{t('docsTeamProfileNote')}</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Troubleshooting */}
          <Section id="troubleshooting" expanded={expandedSection === "troubleshooting"} onToggle={toggleSection} title={t('docsTroubleshootTitle')} icon={AlertTriangle} iconColor="bg-red-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTroubleshootConnTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsTroubleshootConnIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsTroubleshootConnItem1')}</li>
                    <li>{t('docsTroubleshootConnItem2')}</li>
                    <li>{t('docsTroubleshootConnItem3')}</li>
                    <li>{t('docsTroubleshootConnItem4')}</li>
                    <li>{t('docsTroubleshootConnItem5')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTroubleshootAITitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsTroubleshootAIItem1')}</li>
                    <li>{t('docsTroubleshootAIItem2')}</li>
                    <li>{t('docsTroubleshootAIItem3')}</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">{t('docsTroubleshootSlowTitle')}</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>{t('docsTroubleshootSlowIntro')}</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>{t('docsTroubleshootSlowItem1')}</li>
                    <li>{t('docsTroubleshootSlowItem2')}</li>
                    <li>{t('docsTroubleshootSlowItem3')}</li>
                  </ul>
                  <p className="mt-2">{t('docsTroubleshootSlowTip')}</p>
                </div>
              </div>
            </div>
          </Section>

          {/* FAQ */}
          <Section id="faq" expanded={expandedSection === "faq"} onToggle={toggleSection} title={t('docsFAQTitle')} icon={Shield} iconColor="bg-teal-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-2">{t('docsFAQ1Q')}</h3>
                <p className="text-sm text-zinc-400">{t('docsFAQ1A')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">{t('docsFAQ2Q')}</h3>
                <p className="text-sm text-zinc-400">{t('docsFAQ2A')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">{t('docsFAQ3Q')}</h3>
                <p className="text-sm text-zinc-400">{t('docsFAQ3A')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">{t('docsFAQ4Q')}</h3>
                <p className="text-sm text-zinc-400">{t('docsFAQ4A')}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">{t('docsFAQ5Q')}</h3>
                <p className="text-sm text-zinc-400">{t('docsFAQ5A')}</p>
              </div>
            </div>
          </Section>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">{t('legalDocsTitle')}</Link>
            <Link to="/terms" className="hover:text-white">{t('legalTermsTitle')}</Link>
            <Link to="/fair-use" className="hover:text-white">{t('legalFairUseTitle')}</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
