import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { domainsApi, aiApi, settingsApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Textarea } from '../components/ui/textarea';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { Switch } from '../components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import {
  ArrowLeft, Sparkles, Send, Loader2, Check,
  ExternalLink, LogOut, FileText, RefreshCw, X, AlertCircle, Clock, Calendar, Globe, Link2, Image as ImageIcon
} from 'lucide-react';
import Logo from '../components/Logo';
import { LanguageSwitcher } from '../components/LanguageSwitcher';

export default function AutoPostPage() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const [domains, setDomains] = useState([]);
  const [loadingDomains, setLoadingDomains] = useState(true);
  const [selectedDomains, setSelectedDomains] = useState([]);
  const [titles, setTitles] = useState('');
  const [posting, setPosting] = useState(false);
  const [results, setResults] = useState([]);
  const [currentProgress, setCurrentProgress] = useState({ current: 0, total: 0, title: '' });
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('09:00');
  
  // Content Language State
  const [contentLanguage, setContentLanguage] = useState('auto'); // auto, id, en, etc.
  
  // AI Featured Image State
  const [generateFeaturedImage, setGenerateFeaturedImage] = useState(false);
  
  // Link Injection State
  const [linkEnabled, setLinkEnabled] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [linkAnchors, setLinkAnchors] = useState(''); // Multi-line for bulk
  const [linkRel, setLinkRel] = useState('dofollow');
  const [linkPosition, setLinkPosition] = useState('middle');
  const [linkRepetition, setLinkRepetition] = useState(1);
  
  // User Settings State (for AI Image info)
  const [userSettings, setUserSettings] = useState(null);

  useEffect(() => {
    fetchDomains();
    fetchUserSettings();
  }, []);

  const fetchUserSettings = async () => {
    try {
      const response = await settingsApi.get();
      setUserSettings(response.data);
    } catch (error) {
      console.error('Failed to load settings');
    }
  };

  const fetchDomains = async () => {
    setLoadingDomains(true);
    try {
      const response = await domainsApi.list();
      setDomains(response.data);
    } catch (error) {
      toast.error(t('failedToLoad') + ' ' + t('domains').toLowerCase());
    } finally {
      setLoadingDomains(false);
    }
  };

  const titleList = titles.split('\n').map(t => t.trim()).filter(t => t.length > 0);
  const anchorList = linkAnchors.split('\n').map(a => a.trim()).filter(a => a.length > 0);

  const toggleDomain = (domainId) => {
    setSelectedDomains(prev => 
      prev.includes(domainId) 
        ? prev.filter(id => id !== domainId)
        : [...prev, domainId]
    );
  };

  const selectAllDomains = () => {
    if (selectedDomains.length === domains.length) {
      setSelectedDomains([]);
    } else {
      setSelectedDomains(domains.map(d => d.id));
    }
  };

  const handleAutoPost = async () => {
    if (titleList.length === 0) {
      toast.error(t('enterAtLeastOneTitle'));
      return;
    }
    if (selectedDomains.length === 0) {
      toast.error(t('selectAtLeastOneDomain'));
      return;
    }
    if (scheduleEnabled && !scheduleDate) {
      toast.error(t('selectDateForScheduling'));
      return;
    }

    setPosting(true);
    setResults([]);
    
    // Build scheduled datetime in ISO format if scheduling is enabled
    let scheduledDatetime = null;
    if (scheduleEnabled && scheduleDate) {
      scheduledDatetime = `${scheduleDate}T${scheduleTime}:00`;
    }
    
    const totalPosts = titleList.length * selectedDomains.length;
    let completedPosts = 0;
    const newResults = [];

    for (let titleIndex = 0; titleIndex < titleList.length; titleIndex++) {
      const title = titleList[titleIndex];
      
      // Build link injection config for this title
      let linkInjection = null;
      if (linkEnabled && linkUrl) {
        // Use corresponding anchor or first anchor if not enough anchors
        const anchor = anchorList[titleIndex] || anchorList[0] || '';
        if (anchor) {
          linkInjection = {
            enabled: true,
            url: linkUrl,
            anchor_text: anchor,
            rel: linkRel,
            position: linkPosition,
            repetition: linkRepetition
          };
        }
      }
      
      for (const domainId of selectedDomains) {
        const domain = domains.find(d => d.id === domainId);
        setCurrentProgress({ 
          current: completedPosts + 1, 
          total: totalPosts, 
          title: title,
          domain: domain?.name 
        });

        try {
          const response = await aiApi.autoPost(domainId, title, scheduledDatetime, linkInjection, contentLanguage, generateFeaturedImage);
          newResults.push({
            success: true,
            title: title,
            domain: domain,
            post: response.data.post,
            generated: response.data.generated,
            seo: response.data.seo,
            scheduled: scheduleEnabled,
            hasLink: !!linkInjection
          });
        } catch (error) {
          newResults.push({
            success: false,
            title: title,
            domain: domain,
            error: error.response?.data?.detail || t('failedToPost')
          });
        }
        
        completedPosts++;
        setResults([...newResults]);
      }
    }

    setPosting(false);
    setCurrentProgress({ current: 0, total: 0, title: '' });
    
    const successCount = newResults.filter(r => r.success).length;
    const failCount = newResults.filter(r => !r.success).length;
    
    if (successCount > 0 && failCount === 0) {
      const action = scheduleEnabled ? t('scheduled') : t('published');
      toast.success(t('allPostsSuccess').replace('{count}', successCount).replace('{action}', action));
    } else if (successCount > 0) {
      const action = scheduleEnabled ? t('scheduled') : t('published');
      toast.warning(`${successCount} ${t('posts').toLowerCase()} ${action}, ${failCount} ${t('failed').toLowerCase()}`);
    } else {
      toast.error(t('allPostsFailed'));
    }
  };

  const handleReset = () => {
    setTitles('');
    setResults([]);
    setSelectedDomains([]);
    setContentLanguage('auto');
    setGenerateFeaturedImage(false);
    setLinkEnabled(false);
    setLinkUrl('');
    setLinkAnchors('');
    setLinkRel('dofollow');
    setLinkPosition('middle');
    setLinkRepetition(1);
  };

  const successResults = results.filter(r => r.success);
  const failedResults = results.filter(r => !r.success);

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400">{user?.name}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {t('logout')}
              </Button>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-[Chivo]">{t('bulkAutoPost')}</h1>
            <p className="text-zinc-400 text-sm">{t('autoPostDesc')}</p>
          </div>
        </div>

        {results.length === 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: Titles Input */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">
                    {t('postTitles')}
                  </Label>
                  {titleList.length > 0 && (
                    <span className="text-xs text-indigo-400 font-mono bg-indigo-500/10 px-2 py-1 rounded">
                      {titleList.length} {t('title')}{titleList.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
                <Textarea
                  value={titles}
                  onChange={(e) => setTitles(e.target.value)}
                  placeholder={t('titlesPlaceholder')}
                  className="bg-zinc-900 border-white/10 text-white min-h-[200px] font-mono text-sm leading-relaxed"
                  disabled={posting}
                />
                <p className="text-xs text-zinc-600">
                  {t('titlesHelp')}
                </p>
              </CardContent>
            </Card>

            {/* Right: Domain Selection */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">
                    {t('selectDomains')}
                  </Label>
                  {selectedDomains.length > 0 && (
                    <span className="text-xs text-emerald-400 font-mono bg-emerald-500/10 px-2 py-1 rounded">
                      {selectedDomains.length} {t('selected')}
                    </span>
                  )}
                </div>

                {loadingDomains ? (
                  <div className="flex items-center gap-2 text-zinc-500 py-8 justify-center">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">{t('loadingDomains')}</span>
                  </div>
                ) : domains.length === 0 ? (
                  <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                    <p className="text-sm text-amber-400">{t('noDomainsAddFirst')}</p>
                    <Button asChild size="sm" className="mt-2 bg-amber-600 hover:bg-amber-500">
                      <Link to="/dashboard">{t('goToDashboard')}</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Select All */}
                    <div 
                      className="flex items-center gap-3 p-3 bg-zinc-800/50 border border-white/10 rounded-lg cursor-pointer hover:bg-zinc-800 transition-colors"
                      onClick={selectAllDomains}
                    >
                      <Checkbox 
                        checked={selectedDomains.length === domains.length && domains.length > 0}
                        onCheckedChange={selectAllDomains}
                        className="border-zinc-600"
                      />
                      <span className="text-sm text-zinc-300 font-medium">{t('selectAllDomains')}</span>
                      <span className="text-xs text-zinc-500 ml-auto font-mono">({domains.length})</span>
                    </div>

                    {/* Domain List */}
                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-2">
                      {domains.map((domain) => (
                        <div 
                          key={domain.id}
                          className={`flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-all ${
                            selectedDomains.includes(domain.id) 
                              ? 'bg-indigo-500/10 border-indigo-500/30' 
                              : 'bg-zinc-900/50 border-white/5 hover:border-white/10'
                          }`}
                          onClick={() => toggleDomain(domain.id)}
                        >
                          <Checkbox 
                            checked={selectedDomains.includes(domain.id)}
                            onCheckedChange={() => toggleDomain(domain.id)}
                            className="border-zinc-600"
                          />
                          <Globe className={`w-4 h-4 ${selectedDomains.includes(domain.id) ? 'text-indigo-400' : 'text-zinc-500'}`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-white font-medium truncate">{domain.name}</p>
                            <p className="text-xs text-zinc-500 truncate">{domain.url}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Bottom: Schedule & Summary & Action */}
            <div className="lg:col-span-2 space-y-4">
              {/* Schedule Option */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-amber-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('schedulePost')}</Label>
                        <p className="text-xs text-zinc-500">{t('scheduleDesc')}</p>
                      </div>
                    </div>
                    <Switch
                      checked={scheduleEnabled}
                      onCheckedChange={setScheduleEnabled}
                      disabled={posting}
                    />
                  </div>
                  
                  {scheduleEnabled && (
                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                      <div className="space-y-2">
                        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('date')}</Label>
                        <Input
                          type="date"
                          value={scheduleDate}
                          onChange={(e) => setScheduleDate(e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                          className="bg-zinc-900 border-white/10 text-white"
                          disabled={posting}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('time')}</Label>
                        <Input
                          type="time"
                          value={scheduleTime}
                          onChange={(e) => setScheduleTime(e.target.value)}
                          className="bg-zinc-900 border-white/10 text-white"
                          disabled={posting}
                        />
                      </div>
                      <div className="col-span-2">
                        <p className="text-xs text-amber-400/80 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {t('scheduledFor')} {scheduleDate || '[select date]'} at {scheduleTime}
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Content Language Option */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Globe className="w-5 h-5 text-emerald-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('contentLanguage')}</Label>
                        <p className="text-xs text-zinc-500">{t('contentLanguageDesc')}</p>
                      </div>
                    </div>
                    <Select value={contentLanguage} onValueChange={setContentLanguage} disabled={posting}>
                      <SelectTrigger className="w-48 bg-zinc-900 border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-700">
                        <SelectItem value="auto">🔮 {t('autoDetect')}</SelectItem>
                        <SelectItem value="id">🇮🇩 Bahasa Indonesia</SelectItem>
                        <SelectItem value="en">🇺🇸 English</SelectItem>
                        <SelectItem value="es">🇪🇸 Español</SelectItem>
                        <SelectItem value="fr">🇫🇷 Français</SelectItem>
                        <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                        <SelectItem value="pt">🇵🇹 Português</SelectItem>
                        <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                        <SelectItem value="nl">🇳🇱 Nederlands</SelectItem>
                        <SelectItem value="ru">🇷🇺 Русский</SelectItem>
                        <SelectItem value="ja">🇯🇵 日本語</SelectItem>
                        <SelectItem value="ko">🇰🇷 한국어</SelectItem>
                        <SelectItem value="zh">🇨🇳 中文</SelectItem>
                        <SelectItem value="ar">🇸🇦 العربية</SelectItem>
                        <SelectItem value="hi">🇮🇳 हिन्दी</SelectItem>
                        <SelectItem value="th">🇹🇭 ไทย</SelectItem>
                        <SelectItem value="vi">🇻🇳 Tiếng Việt</SelectItem>
                        <SelectItem value="ms">🇲🇾 Bahasa Melayu</SelectItem>
                        <SelectItem value="tl">🇵🇭 Filipino</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {contentLanguage === 'auto' && (
                    <p className="text-xs text-emerald-400/80 flex items-center gap-1 pt-2 border-t border-white/5">
                      <Sparkles className="w-3 h-3" />
                      {t('autoDetectDesc')}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* AI Featured Image Option */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ImageIcon className="w-5 h-5 text-purple-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('aiFeaturedImage')}</Label>
                        <p className="text-xs text-zinc-500">{t('aiFeaturedImageDesc')}</p>
                      </div>
                    </div>
                    <Switch
                      checked={generateFeaturedImage}
                      onCheckedChange={setGenerateFeaturedImage}
                      disabled={posting || !userSettings?.image_ai_enabled}
                    />
                  </div>
                  
                  {generateFeaturedImage && userSettings?.image_ai_enabled && (
                    <p className="text-xs text-purple-400/80 flex items-center gap-1 pt-2 border-t border-white/5">
                      <Sparkles className="w-3 h-3" />
                      {t('usingProvider')}: {userSettings?.image_ai_provider?.toUpperCase() || 'OpenAI'}
                    </p>
                  )}
                  
                  {!userSettings?.image_ai_enabled && (
                    <p className="text-xs text-amber-400/80 flex items-center gap-1 pt-2 border-t border-white/5">
                      <AlertCircle className="w-3 h-3" />
                      {t('enableInSettings')}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Link Injection Option */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Link2 className="w-5 h-5 text-cyan-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('linkInjectionTitle')}</Label>
                        <p className="text-xs text-zinc-500">{t('linkInjectionDesc')}</p>
                      </div>
                    </div>
                    <Switch
                      checked={linkEnabled}
                      onCheckedChange={setLinkEnabled}
                      disabled={posting}
                    />
                  </div>
                  
                  {linkEnabled && (
                    <div className="space-y-4 pt-2 border-t border-white/5">
                      {/* URL Target */}
                      <div className="space-y-2">
                        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('targetUrl')}</Label>
                        <Input
                          type="url"
                          value={linkUrl}
                          onChange={(e) => setLinkUrl(e.target.value)}
                          placeholder={t('targetUrlPlaceholder')}
                          className="bg-zinc-900 border-white/10 text-white"
                          disabled={posting}
                        />
                      </div>
                      
                      {/* Anchor Texts */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('anchorText')}</Label>
                          {anchorList.length > 0 && (
                            <span className="text-xs text-cyan-400 font-mono bg-cyan-500/10 px-2 py-1 rounded">
                              {anchorList.length} anchor{anchorList.length > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <Textarea
                          value={linkAnchors}
                          onChange={(e) => setLinkAnchors(e.target.value)}
                          placeholder={t('anchorTextsPlaceholder')}
                          className="bg-zinc-900 border-white/10 text-white min-h-[80px] font-mono text-sm"
                          disabled={posting}
                        />
                        <p className="text-xs text-zinc-600">
                          {t('anchorTextsHelp')}
                        </p>
                      </div>
                      
                      {/* Settings Row */}
                      <div className="grid grid-cols-3 gap-4">
                        {/* Rel Attribute */}
                        <div className="space-y-2">
                          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('relAttribute')}</Label>
                          <Select value={linkRel} onValueChange={setLinkRel} disabled={posting}>
                            <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-zinc-900 border-zinc-700">
                              <SelectItem value="dofollow">{t('dofollow')}</SelectItem>
                              <SelectItem value="nofollow">{t('nofollow')}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {/* Position */}
                        <div className="space-y-2">
                          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('linkPosition')}</Label>
                          <Select value={linkPosition} onValueChange={setLinkPosition} disabled={posting}>
                            <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-zinc-900 border-zinc-700">
                              <SelectItem value="start">{t('beginning')}</SelectItem>
                              <SelectItem value="middle">{t('middle')} (Random)</SelectItem>
                              <SelectItem value="end">{t('end')}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {/* Repetition */}
                        <div className="space-y-2">
                          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">{t('repetitions')}</Label>
                          <Select value={String(linkRepetition)} onValueChange={(v) => setLinkRepetition(Number(v))} disabled={posting}>
                            <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-zinc-900 border-zinc-700">
                              <SelectItem value="1">1x</SelectItem>
                              <SelectItem value="2">2x</SelectItem>
                              <SelectItem value="3">3x</SelectItem>
                              <SelectItem value="4">4x</SelectItem>
                              <SelectItem value="5">5x</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      {/* Preview */}
                      {linkUrl && anchorList.length > 0 && (
                        <div className="p-3 bg-zinc-800/50 rounded-lg">
                          <p className="text-xs text-zinc-500 mb-1">Preview:</p>
                          <code className="text-xs text-cyan-400 break-all">
                            &lt;a href=&quot;{linkUrl}&quot;{linkRel === 'nofollow' ? ' rel="nofollow"' : ''}&gt;{anchorList[0]}&lt;/a&gt;
                          </code>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Summary */}
              {titleList.length > 0 && selectedDomains.length > 0 && (
                <div className="p-4 bg-gradient-to-r from-violet-500/10 to-indigo-500/10 border border-violet-500/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-5 h-5 text-violet-400" />
                    <div className="flex-1">
                      <p className="text-sm text-violet-300">
                        <span className="font-bold">{titleList.length}</span> title{titleList.length > 1 ? 's' : ''} × <span className="font-bold">{selectedDomains.length}</span> domain{selectedDomains.length > 1 ? 's' : ''} = <span className="font-bold text-white">{titleList.length * selectedDomains.length}</span> posts will be {scheduleEnabled ? 'scheduled' : 'created'}
                        {linkEnabled && linkUrl && anchorList.length > 0 && (
                          <span className="ml-2 text-cyan-400">• with links</span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Progress */}
              {posting && (
                <div className="p-4 bg-zinc-900 border border-white/10 rounded-lg">
                  <div className="flex items-center gap-3 mb-3">
                    <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                    <div className="flex-1">
                      <p className="text-sm text-white">
                        Publishing {currentProgress.current} of {currentProgress.total}...
                      </p>
                      <p className="text-xs text-zinc-500 truncate">
                        &quot;{currentProgress.title}&quot; → {currentProgress.domain}
                      </p>
                    </div>
                    <span className="text-sm font-mono text-indigo-400">
                      {Math.round((currentProgress.current / currentProgress.total) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-800 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-violet-500 to-indigo-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(currentProgress.current / currentProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Generate Button */}
              <Button
                onClick={handleAutoPost}
                disabled={posting || titleList.length === 0 || selectedDomains.length === 0 || (scheduleEnabled && !scheduleDate)}
                className={`w-full text-white font-medium h-12 text-base transition-all duration-200 hover:-translate-y-0.5 disabled:opacity-50 disabled:hover:translate-y-0 ${
                  scheduleEnabled 
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500'
                }`}
              >
                {posting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    {scheduleEnabled ? 'Scheduling Posts...' : 'Publishing Posts...'}
                  </>
                ) : scheduleEnabled ? (
                  <>
                    <Calendar className="w-5 h-5 mr-2" />
                    Generate & Schedule {titleList.length * selectedDomains.length || ''} Post{(titleList.length * selectedDomains.length) > 1 ? 's' : ''}
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Generate & Publish {titleList.length * selectedDomains.length || ''} Post{(titleList.length * selectedDomains.length) > 1 ? 's' : ''}
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          /* Results View */
          <div className="space-y-6">
            {/* Summary Header */}
            <div className="flex items-center justify-between p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  failedResults.length === 0 ? 'bg-emerald-500' : failedResults.length === results.length ? 'bg-red-500' : 'bg-amber-500'
                }`}>
                  {failedResults.length === 0 ? (
                    <Check className="w-6 h-6 text-white" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    {failedResults.length === 0 ? 'All Posts Published!' : 
                     failedResults.length === results.length ? 'All Posts Failed' : 
                     'Partially Completed'}
                  </h2>
                  <p className="text-sm text-zinc-400">
                    {successResults.length} success, {failedResults.length} failed
                  </p>
                </div>
              </div>
              <Button onClick={handleReset} variant="outline" className="border-white/10 text-white hover:bg-zinc-800">
                <RefreshCw className="w-4 h-4 mr-2" />
                Create More
              </Button>
            </div>

            {/* Success Results */}
            {successResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm text-emerald-400 font-mono uppercase tracking-widest flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  {successResults[0]?.scheduled ? 'Successfully Scheduled' : 'Successfully Published'} ({successResults.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {successResults.map((result, i) => (
                    <div key={i} className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-white font-medium truncate">{result.title}</p>
                          <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1">
                            <Globe className="w-3 h-3" />
                            {result.domain?.name}
                          </p>
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <span className="text-xs text-zinc-600 font-mono">ID: {result.post?.id}</span>
                            <span className="text-xs text-zinc-600 font-mono">•</span>
                            <span className="text-xs text-zinc-600 font-mono">{result.generated?.word_count} words</span>
                            {result.generated?.has_featured_image && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className="text-xs text-indigo-400 font-mono">📷 Image</span>
                              </>
                            )}
                            {result.hasLink && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className="text-xs text-cyan-400 font-mono">🔗 Link</span>
                              </>
                            )}
                            {result.seo?.seo_score && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className={`text-xs font-mono ${
                                  result.seo.seo_score >= 80 ? 'text-emerald-400' :
                                  result.seo.seo_score >= 60 ? 'text-amber-400' : 'text-red-400'
                                }`}>
                                  SEO: {result.seo.seo_score}%
                                </span>
                              </>
                            )}
                            {result.post?.status === 'future' && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className="text-xs text-amber-400 font-mono flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Scheduled
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        <Button asChild size="sm" variant="ghost" className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10">
                          <a href={result.post?.link} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Failed Results */}
            {failedResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm text-red-400 font-mono uppercase tracking-widest flex items-center gap-2">
                  <X className="w-4 h-4" />
                  Failed ({failedResults.length})
                </h3>
                <div className="space-y-2">
                  {failedResults.map((result, i) => (
                    <div key={i} className="p-3 bg-red-500/5 border border-red-500/20 rounded-lg flex items-center gap-3">
                      <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white truncate">{result.title}</p>
                        <p className="text-xs text-zinc-500">{result.domain?.name} - {result.error}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
