import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from '../components/LanguageSwitcher';
import Logo from '../components/Logo';
import { ArrowLeft, Shield, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';

export default function FairUsePage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/docs">{t('legalDocsTitle')}</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/terms">{t('legalTermsTitle')}</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <Shield className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">{t('fairUseTitle')}</h1>
            <p className="text-zinc-400">{t('fairUseSubtitle')}</p>
          </div>
        </div>

        <div className="space-y-8 text-zinc-300">
          {/* Introduction */}
          <section>
            <p className="text-sm leading-relaxed">
              {t('fairUseIntro')}
            </p>
          </section>

          {/* Allowed Usage */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              {t('fairUseAllowedTitle')}
            </h2>
            <Card className="bg-emerald-500/5 border-emerald-500/20">
              <CardContent className="p-6">
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseAllowed1')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseAllowed2')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseAllowed3')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseAllowed4')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseAllowed5')}</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Prohibited Usage */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-400" />
              {t('fairUseProhibitedTitle')}
            </h2>
            <Card className="bg-red-500/5 border-red-500/20">
              <CardContent className="p-6">
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited1')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited2')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited3')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited4')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited5')}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>{t('fairUseProhibited6')}</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* AI Content Guidelines */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              {t('fairUseAITitle')}
            </h2>
            <Card className="bg-amber-500/5 border-amber-500/20">
              <CardContent className="p-6 space-y-4">
                <p className="text-sm">
                  {t('fairUseAIIntro')}
                </p>
                <ul className="space-y-2 text-sm text-zinc-400">
                  <li>• <strong className="text-white">{t('fairUseAI1Title')}</strong> - {t('fairUseAI1Desc')}</li>
                  <li>• <strong className="text-white">{t('fairUseAI2Title')}</strong> - {t('fairUseAI2Desc')}</li>
                  <li>• <strong className="text-white">{t('fairUseAI3Title')}</strong> - {t('fairUseAI3Desc')}</li>
                  <li>• <strong className="text-white">{t('fairUseAI4Title')}</strong> - {t('fairUseAI4Desc')}</li>
                  <li>• <strong className="text-white">{t('fairUseAI5Title')}</strong> - {t('fairUseAI5Desc')}</li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Rate Limits */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4">{t('fairUseLimitsTitle')}</h2>
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6">
                <p className="text-sm mb-4">
                  {t('fairUseLimitsIntro')}
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">{t('fairUseLimitsAutoPost')}</p>
                    <p className="text-white font-medium">{t('fairUseLimitsAutoPostVal')}</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">{t('fairUseLimitsBulk')}</p>
                    <p className="text-white font-medium">{t('fairUseLimitsBulkVal')}</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">{t('fairUseLimitsDomains')}</p>
                    <p className="text-white font-medium">{t('fairUseLimitsDomainsVal')}</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">{t('fairUseLimitsTeam')}</p>
                    <p className="text-white font-medium">{t('fairUseLimitsTeamVal')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Enforcement */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4">{t('fairUseEnforceTitle')}</h2>
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 text-sm space-y-3">
                <p>
                  {t('fairUseEnforceIntro')}
                </p>
                <ul className="list-disc list-inside text-zinc-400 space-y-1">
                  <li>{t('fairUseEnforce1')}</li>
                  <li>{t('fairUseEnforce2')}</li>
                  <li>{t('fairUseEnforce3')}</li>
                  <li>{t('fairUseEnforce4')}</li>
                </ul>
                <p className="text-zinc-400">
                  {t('fairUseEnforceNote')}
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">{t('legalDocsTitle')}</Link>
            <Link to="/terms" className="hover:text-white">{t('legalTermsTitle')}</Link>
            <Link to="/fair-use" className="hover:text-white">{t('legalFairUseTitle')}</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
