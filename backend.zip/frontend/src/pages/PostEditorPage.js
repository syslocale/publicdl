import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { domainsApi, postsApi, categoriesApi, tagsApi, aiApi, settingsApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Checkbox } from '../components/ui/checkbox';
import { Switch } from '../components/ui/switch';
import { toast } from 'sonner';
import { RichTextEditor } from '../components/RichTextEditor';
import {
  ArrowLeft, Save, Loader2, Sparkles, LogOut,
  FileText, Tag, FolderOpen, Plus, Link2, Globe, Image as ImageIcon, AlertCircle
} from 'lucide-react';
import Logo from '../components/Logo';
import { LanguageSwitcher } from '../components/LanguageSwitcher';

export default function PostEditorPage() {
  const { domainId, postId } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const isEdit = !!postId;

  const [domain, setDomain] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);

  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  
  // New category/tag inputs
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newTagName, setNewTagName] = useState('');
  const [addingCategory, setAddingCategory] = useState(false);
  const [addingTag, setAddingTag] = useState(false);

  // Content Language State
  const [contentLanguage, setContentLanguage] = useState('auto');

  // AI Featured Image State
  const [generateFeaturedImage, setGenerateFeaturedImage] = useState(false);
  const [userSettings, setUserSettings] = useState(null);

  // Link Injection State
  const [linkEnabled, setLinkEnabled] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [linkAnchor, setLinkAnchor] = useState('');
  const [linkRel, setLinkRel] = useState('dofollow');
  const [linkPosition, setLinkPosition] = useState('middle');
  const [linkRepetition, setLinkRepetition] = useState(1);

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    status: 'draft',
    categories: [],
    tags: []
  });

  useEffect(() => {
    fetchData();
  }, [domainId, postId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const domainRes = await domainsApi.get(domainId);
      setDomain(domainRes.data);

      // Fetch user settings for AI Image
      try {
        const settingsRes = await settingsApi.get();
        setUserSettings(settingsRes.data);
      } catch (settingsError) {
        // Silent fail
      }

      // Fetch categories and tags - don't fail if these fail
      try {
        const [catRes, tagRes] = await Promise.all([
          categoriesApi.list(domainId),
          tagsApi.list(domainId)
        ]);
        setCategories(catRes.data.items || []);
        setTags(tagRes.data.items || []);
      } catch (catTagError) {
        // Silent fail - categories/tags will show empty
        // Continue without categories/tags
      }

      // If editing, fetch post data
      if (isEdit) {
        try {
          const postRes = await postsApi.get(domainId, postId);
          const post = postRes.data;
          setFormData({
            title: post.title?.rendered || '',
            content: post.content?.rendered || '',
            status: post.status || 'draft',
            categories: post.categories || [],
            tags: post.tags || []
          });
        } catch (postError) {
          toast.error('Failed to load post');
          navigate(`/domains/${domainId}`);
          return;
        }
      }
    } catch (error) {
      toast.error('Failed to load domain');
      navigate(`/domains/${domainId}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      toast.error(t('titleRequired'));
      return;
    }

    setSaving(true);
    try {
      const data = {
        title: formData.title,
        content: formData.content,
        status: formData.status,
        categories: formData.categories,
        tags: formData.tags
      };

      // Add link injection if enabled
      if (linkEnabled && linkUrl && linkAnchor) {
        data.link_injection = {
          enabled: true,
          url: linkUrl,
          anchor_text: linkAnchor,
          rel: linkRel,
          position: linkPosition,
          repetition: linkRepetition
        };
      }

      if (isEdit) {
        await postsApi.update(domainId, postId, data);
        toast.success(t('postUpdated'));
      } else {
        await postsApi.create(domainId, data);
        toast.success(t('postCreated'));
      }
      navigate(`/domains/${domainId}`);
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedToSavePost'));
    } finally {
      setSaving(false);
    }
  };

  const handleGenerate = async () => {
    if (!formData.title.trim()) {
      toast.error(t('pleaseEnterTitle'));
      return;
    }

    setGenerating(true);
    try {
      const response = await aiApi.generatePost(domainId, formData.title, contentLanguage, generateFeaturedImage);
      const result = response.data;

      setFormData(prev => ({
        ...prev,
        content: result.content,
        categories: result.category_ids || [],
        tags: result.tag_ids || []
      }));

      // Update categories/tags lists if new ones came from AI
      if (result.existing_categories) {
        setCategories(result.existing_categories);
      }
      if (result.existing_tags) {
        setTags(result.existing_tags);
      }

      toast.success(t('contentGenerated'));
      
      // Show suggested categories/tags that need to be created
      const newCategories = result.suggested_categories?.filter(
        name => !categories.some(c => c.name.toLowerCase() === name.toLowerCase())
      );
      const newTags = result.suggested_tags?.filter(
        name => !tags.some(t => t.name.toLowerCase() === name.toLowerCase())
      );

      if (newCategories?.length > 0 || newTags?.length > 0) {
        const items = [...(newCategories || []), ...(newTags || [])].join(', ');
        toast.info(t('suggestedNew').replace('{items}', items));
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedToSavePost'));
    } finally {
      setGenerating(false);
    }
  };

  const toggleCategory = (categoryId) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.includes(categoryId)
        ? prev.categories.filter(id => id !== categoryId)
        : [...prev.categories, categoryId]
    }));
  };

  const toggleTag = (tagId) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.includes(tagId)
        ? prev.tags.filter(id => id !== tagId)
        : [...prev.tags, tagId]
    }));
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) return;
    setAddingCategory(true);
    try {
      const response = await categoriesApi.create(domainId, { name: newCategoryName.trim() });
      const newCategory = response.data;
      setCategories(prev => [...prev, newCategory]);
      setFormData(prev => ({ ...prev, categories: [...prev.categories, newCategory.id] }));
      setNewCategoryName('');
      toast.success(t('categoryCreated').replace('{name}', newCategory.name));
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedCreateCategory'));
    } finally {
      setAddingCategory(false);
    }
  };

  const handleAddTag = async () => {
    if (!newTagName.trim()) return;
    setAddingTag(true);
    try {
      const response = await tagsApi.create(domainId, { name: newTagName.trim() });
      const newTag = response.data;
      setTags(prev => [...prev, newTag]);
      setFormData(prev => ({ ...prev, tags: [...prev.tags, newTag.id] }));
      setNewTagName('');
      toast.success(t('tagCreated').replace('{name}', newTag.name));
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedCreateTag'));
    } finally {
      setAddingTag(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-500 spinner" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to={`/domains/${domainId}`} className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400">{user?.name}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                data-testid="logout-btn"
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {t('logout')}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-white" data-testid="page-title">
            {isEdit ? t('editPost') : t('createNewPost')}
          </h1>
          <p className="text-zinc-400 mt-1">{domain?.name}</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content Area */}
            <div className="lg:col-span-2 space-y-6">
              {/* Title */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <Label className="text-zinc-300">{t('title')}</Label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder={t('postTitlePlaceholder')}
                        required
                        data-testid="post-title-input"
                        className="bg-zinc-800/50 border-zinc-700 text-white text-lg"
                      />
                      <Button
                        type="button"
                        onClick={handleGenerate}
                        disabled={generating || !formData.title.trim()}
                        data-testid="generate-ai-btn"
                        className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white whitespace-nowrap"
                      >
                        {generating ? (
                          <Loader2 className="w-4 h-4 spinner" />
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            {t('generateWithAIBtn')}
                          </>
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-zinc-500">
                      {t('enterTitleToGenerate')}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Content Language */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Globe className="w-5 h-5 text-emerald-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('contentLanguage')}</Label>
                        <p className="text-xs text-zinc-500">{t('contentLanguageDesc')}</p>
                      </div>
                    </div>
                    <Select value={contentLanguage} onValueChange={setContentLanguage} disabled={generating}>
                      <SelectTrigger className="w-48 bg-zinc-800/50 border-zinc-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-700">
                        <SelectItem value="auto">🔮 {t('autoDetect')}</SelectItem>
                        <SelectItem value="id">🇮🇩 Bahasa Indonesia</SelectItem>
                        <SelectItem value="en">🇺🇸 English</SelectItem>
                        <SelectItem value="es">🇪🇸 Español</SelectItem>
                        <SelectItem value="fr">🇫🇷 Français</SelectItem>
                        <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                        <SelectItem value="pt">🇵🇹 Português</SelectItem>
                        <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                        <SelectItem value="nl">🇳🇱 Nederlands</SelectItem>
                        <SelectItem value="ru">🇷🇺 Русский</SelectItem>
                        <SelectItem value="ja">🇯🇵 日本語</SelectItem>
                        <SelectItem value="ko">🇰🇷 한국어</SelectItem>
                        <SelectItem value="zh">🇨🇳 中文</SelectItem>
                        <SelectItem value="ar">🇸🇦 العربية</SelectItem>
                        <SelectItem value="hi">🇮🇳 हिन्दी</SelectItem>
                        <SelectItem value="th">🇹🇭 ไทย</SelectItem>
                        <SelectItem value="vi">🇻🇳 Tiếng Việt</SelectItem>
                        <SelectItem value="ms">🇲🇾 Bahasa Melayu</SelectItem>
                        <SelectItem value="tl">🇵🇭 Filipino</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {contentLanguage === 'auto' && (
                    <p className="text-xs text-emerald-400/80 flex items-center gap-1 mt-3 pt-3 border-t border-zinc-700/50">
                      <Sparkles className="w-3 h-3" />
                      {t('autoDetectDesc')}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* AI Featured Image */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ImageIcon className="w-5 h-5 text-purple-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">{t('aiFeaturedImage')}</Label>
                        <p className="text-xs text-zinc-500">{t('aiFeaturedImageDesc')}</p>
                      </div>
                    </div>
                    <Switch
                      checked={generateFeaturedImage}
                      onCheckedChange={setGenerateFeaturedImage}
                      disabled={generating || !userSettings?.image_ai_enabled}
                    />
                  </div>
                  
                  {generateFeaturedImage && userSettings?.image_ai_enabled && (
                    <p className="text-xs text-purple-400/80 flex items-center gap-1 mt-3 pt-3 border-t border-zinc-700/50">
                      <Sparkles className="w-3 h-3" />
                      {t('usingProvider')}: {userSettings?.image_ai_provider?.toUpperCase() || 'OpenAI'}
                    </p>
                  )}
                  
                  {!userSettings?.image_ai_enabled && (
                    <p className="text-xs text-amber-400/80 flex items-center gap-1 mt-3 pt-3 border-t border-zinc-700/50">
                      <AlertCircle className="w-3 h-3" />
                      {t('enableInSettings')}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Content Editor */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-400" />
                    {t('content')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RichTextEditor
                    value={formData.content}
                    onChange={(content) => setFormData({ ...formData, content })}
                    placeholder="Write your post content here..."
                  />
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Publish Settings */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white">{t('publish')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-300">{t('status')}</Label>
                    <Select 
                      value={formData.status} 
                      onValueChange={(v) => setFormData({ ...formData, status: v })}
                    >
                      <SelectTrigger data-testid="post-status-select" className="bg-zinc-800/50 border-zinc-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        <SelectItem value="draft">{t('draft')}</SelectItem>
                        <SelectItem value="publish">{t('published')}</SelectItem>
                        <SelectItem value="pending">{t('pendingReview')}</SelectItem>
                        <SelectItem value="private">{t('private')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={saving}
                      data-testid="save-post-btn"
                      className="flex-1 bg-indigo-500 hover:bg-indigo-600 text-white"
                    >
                      {saving ? (
                        <Loader2 className="w-4 h-4 spinner" />
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          {isEdit ? t('update') : t('publish')}
                        </>
                      )}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => navigate(`/domains/${domainId}`)}
                      className="bg-zinc-800 border-zinc-700 text-white hover:bg-zinc-700"
                    >
                      {t('cancel')}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Categories */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <FolderOpen className="w-5 h-5 text-indigo-400" />
                    {t('categories')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Add new category */}
                  <div className="flex gap-2">
                    <Input
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                      placeholder={t('newCategoryPlaceholder')}
                      className="bg-zinc-800/50 border-zinc-700 text-white text-sm h-8"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddCategory())}
                    />
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleAddCategory}
                      disabled={addingCategory || !newCategoryName.trim()}
                      className="bg-indigo-600 hover:bg-indigo-500 h-8 px-3"
                    >
                      {addingCategory ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
                    </Button>
                  </div>
                  
                  <div className="max-h-48 overflow-y-auto space-y-2" data-testid="categories-list">
                    {categories.length === 0 ? (
                      <p className="text-sm text-zinc-500">{t('noCategories')}</p>
                    ) : (
                      categories.map((category) => (
                        <div key={category.id} className="flex items-center gap-2">
                          <Checkbox
                            id={`cat-${category.id}`}
                            checked={formData.categories.includes(category.id)}
                            onCheckedChange={() => toggleCategory(category.id)}
                            data-testid={`category-checkbox-${category.id}`}
                            className="border-zinc-600 data-[state=checked]:bg-indigo-500"
                          />
                          <label 
                            htmlFor={`cat-${category.id}`}
                            className="text-sm text-zinc-300 cursor-pointer"
                          >
                            {category.name}
                          </label>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Tags */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Tag className="w-5 h-5 text-indigo-400" />
                    {t('tags')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Add new tag */}
                  <div className="flex gap-2">
                    <Input
                      value={newTagName}
                      onChange={(e) => setNewTagName(e.target.value)}
                      placeholder={t('newTagPlaceholder')}
                      className="bg-zinc-800/50 border-zinc-700 text-white text-sm h-8"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                    />
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleAddTag}
                      disabled={addingTag || !newTagName.trim()}
                      className="bg-indigo-600 hover:bg-indigo-500 h-8 px-3"
                    >
                      {addingTag ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
                    </Button>
                  </div>
                  
                  <div className="max-h-48 overflow-y-auto space-y-2" data-testid="tags-list">
                    {tags.length === 0 ? (
                      <p className="text-sm text-zinc-500">{t('noTags')}</p>
                    ) : (
                      tags.map((tag) => (
                        <div key={tag.id} className="flex items-center gap-2">
                          <Checkbox
                            id={`tag-${tag.id}`}
                            checked={formData.tags.includes(tag.id)}
                            onCheckedChange={() => toggleTag(tag.id)}
                            data-testid={`tag-checkbox-${tag.id}`}
                            className="border-zinc-600 data-[state=checked]:bg-indigo-500"
                          />
                          <label 
                            htmlFor={`tag-${tag.id}`}
                            className="text-sm text-zinc-300 cursor-pointer"
                          >
                            {tag.name}
                          </label>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Link Injection */}
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg text-white flex items-center gap-2">
                      <Link2 className="w-5 h-5 text-cyan-400" />
                      {t('linkInjectionEditor')}
                    </CardTitle>
                    <Switch
                      checked={linkEnabled}
                      onCheckedChange={setLinkEnabled}
                    />
                  </div>
                </CardHeader>
                {linkEnabled && (
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <Label className="text-zinc-400 text-xs">{t('targetUrlLabel')}</Label>
                      <Input
                        type="url"
                        value={linkUrl}
                        onChange={(e) => setLinkUrl(e.target.value)}
                        placeholder="https://example.com"
                        className="bg-zinc-800/50 border-zinc-700 text-white text-sm"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-zinc-400 text-xs">{t('anchorTextLabel')}</Label>
                      <Input
                        value={linkAnchor}
                        onChange={(e) => setLinkAnchor(e.target.value)}
                        placeholder={t('anchorText')}
                        className="bg-zinc-800/50 border-zinc-700 text-white text-sm"
                      />
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2">
                      <div className="space-y-1">
                        <Label className="text-zinc-400 text-xs">{t('relLabel')}</Label>
                        <Select value={linkRel} onValueChange={setLinkRel}>
                          <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-900 border-zinc-800">
                            <SelectItem value="dofollow">{t('dofollow')}</SelectItem>
                            <SelectItem value="nofollow">{t('nofollow')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-1">
                        <Label className="text-zinc-400 text-xs">{t('positionLabel')}</Label>
                        <Select value={linkPosition} onValueChange={setLinkPosition}>
                          <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-900 border-zinc-800">
                            <SelectItem value="start">{t('beginning')}</SelectItem>
                            <SelectItem value="middle">{t('middle')}</SelectItem>
                            <SelectItem value="end">{t('end')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-1">
                        <Label className="text-zinc-400 text-xs">{t('repeatLabel')}</Label>
                        <Select value={String(linkRepetition)} onValueChange={(v) => setLinkRepetition(Number(v))}>
                          <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white text-xs h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-900 border-zinc-800">
                            <SelectItem value="1">1x</SelectItem>
                            <SelectItem value="2">2x</SelectItem>
                            <SelectItem value="3">3x</SelectItem>
                            <SelectItem value="4">4x</SelectItem>
                            <SelectItem value="5">5x</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    {linkUrl && linkAnchor && (
                      <div className="p-2 bg-zinc-800/50 rounded text-xs">
                        <span className="text-zinc-500">{t('linkPreview')}: </span>
                        <code className="text-cyan-400">
                          &lt;a href=&quot;{linkUrl}&quot;{linkRel === 'nofollow' ? ' rel="nofollow"' : ''}&gt;{linkAnchor}&lt;/a&gt;
                        </code>
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
