import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Bell, AlertTriangle } from 'lucide-react';
import { Button } from '../components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';

// Subscription Warning Banner (shown in navbar)
export function SubscriptionBadge() {
  const { subscription, user } = useAuth();
  const { t } = useLanguage();
  
  // Don't show for superadmin
  if (user?.role === 'superadmin') return null;
  
  // Don't show if no warning/expired
  if (!subscription || subscription.status === 'active') return null;
  
  const isExpired = subscription.status === 'expired';
  const isWarning = subscription.status === 'warning';
  
  if (!isExpired && !isWarning) return null;
  
  return (
    <div className="relative">
      <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${
        isExpired 
          ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
      }`}>
        <Bell className="w-3 h-3" />
        <span className="hidden sm:inline">
          {isExpired ? t('expired') : `${subscription.days_remaining}d`}
        </span>
        {/* Red dot indicator */}
        <span className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${
          isExpired ? 'bg-red-500' : 'bg-amber-500'
        } animate-pulse`} />
      </div>
    </div>
  );
}

// Subscription Warning Popup (shown once per day)
export function SubscriptionPopup() {
  const { subscription, user } = useAuth();
  const { t } = useLanguage();
  
  // Calculate if popup should be shown on initial render
  const shouldShowPopup = () => {
    // Don't show for superadmin
    if (user?.role === 'superadmin') return false;
    
    // Don't show if no warning/expired
    if (!subscription || subscription.status === 'active') return false;
    
    // Check localStorage for last shown date
    const lastShownKey = 'wpmtools_subscription_popup_shown';
    const lastShown = localStorage.getItem(lastShownKey);
    const today = new Date().toDateString();
    
    if (lastShown !== today) {
      localStorage.setItem(lastShownKey, today);
      return true;
    }
    return false;
  };
  
  const [showPopup, setShowPopup] = useState(shouldShowPopup);
  
  // Don't render if no subscription issue
  if (!subscription || subscription.status === 'active') return null;
  
  const isExpired = subscription.status === 'expired';
  
  return (
    <Dialog open={showPopup} onOpenChange={setShowPopup}>
      <DialogContent className="bg-zinc-950 border border-zinc-800 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <AlertTriangle className={`w-5 h-5 ${isExpired ? 'text-red-500' : 'text-amber-500'}`} />
            {isExpired ? t('subscriptionExpired') : t('subscriptionWarning')}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className={`p-4 rounded-lg ${
            isExpired 
              ? 'bg-red-500/10 border border-red-500/20' 
              : 'bg-amber-500/10 border border-amber-500/20'
          }`}>
            <p className={`text-sm ${isExpired ? 'text-red-300' : 'text-amber-300'}`}>
              {subscription.message}
            </p>
          </div>
          
          {!isExpired && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-zinc-400">{t('daysRemaining')}:</span>
              <span className="font-mono text-amber-400 font-bold">
                {subscription.days_remaining}
              </span>
            </div>
          )}
          
          <p className="text-xs text-zinc-500">
            {t('contactSupport')}
          </p>
        </div>
        
        <div className="flex justify-end">
          <Button 
            onClick={() => setShowPopup(false)}
            className={isExpired ? 'bg-red-600 hover:bg-red-500' : 'bg-amber-600 hover:bg-amber-500'}
          >
            {t('understand')}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Full-width expired banner (shown at top of page when expired)
export function SubscriptionExpiredBanner() {
  const { subscription, user } = useAuth();
  const { t } = useLanguage();
  
  // Don't show for superadmin
  if (user?.role === 'superadmin') return null;
  
  // Only show if expired
  if (!subscription || subscription.status !== 'expired') return null;
  
  return (
    <div className="w-full bg-red-600 text-white py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-sm">
        <AlertTriangle className="w-4 h-4" />
        <span className="font-medium">
          {t('subscriptionExpiredMsg')}
        </span>
      </div>
    </div>
  );
}
