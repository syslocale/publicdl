import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { Toaster } from "./components/ui/sonner";
import { SubscriptionPopup, SubscriptionExpiredBanner } from "./components/SubscriptionBanner";
import LoginPage from "./pages/LoginPage";
import SetupWizardPage from "./pages/SetupWizardPage";
// RegisterPage removed - users managed by superadmin only
import DashboardPage from "./pages/DashboardPage";
import DomainDetailPage from "./pages/DomainDetailPage";
import PostEditorPage from "./pages/PostEditorPage";
import SettingsPage from "./pages/SettingsPage";
import AutoPostPage from "./pages/AutoPostPage";
import TeamPage from "./pages/TeamPage";
import DocsPage from "./pages/DocsPage";
import TermsPage from "./pages/TermsPage";
import FairUsePage from "./pages/FairUsePage";
import api from "./lib/api";
import "./App.css";

// Setup Check Context
const SetupContext = ({ children }) => {
  const [setupStatus, setSetupStatus] = useState({ loading: true, isComplete: null });

  useEffect(() => {
    const checkSetup = async () => {
      try {
        const response = await api.get('/setup/status');
        const isComplete = response.data.is_setup_complete;
        setSetupStatus({ loading: false, isComplete });
        
        // Redirect to setup if not complete and not already on setup page
        if (!isComplete && !window.location.pathname.startsWith('/setup')) {
          window.location.href = '/setup';
        }
      } catch (error) {
        // If error, assume setup is complete (API might not exist in older versions)
        setSetupStatus({ loading: false, isComplete: true });
      }
    };
    checkSetup();
  }, []);

  if (setupStatus.loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return children;
};

// Protected Route component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

// Public Route - redirect to dashboard if authenticated
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

function AppRoutes() {
  return (
    <Routes>
      {/* Setup Wizard Route - accessible without auth */}
      <Route path="/setup" element={<SetupWizardPage />} />
      <Route
        path="/login"
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        }
      />
      {/* Register route removed - users managed by superadmin only */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/domains/:domainId/posts/new"
        element={
          <ProtectedRoute>
            <PostEditorPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/domains/:domainId/posts/:postId/edit"
        element={
          <ProtectedRoute>
            <PostEditorPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/domains/:id"
        element={
          <ProtectedRoute>
            <DomainDetailPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedRoute>
            <SettingsPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/auto-post"
        element={
          <ProtectedRoute>
            <AutoPostPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/team"
        element={
          <ProtectedRoute>
            <TeamPage />
          </ProtectedRoute>
        }
      />
      {/* Public pages - no auth required */}
      <Route path="/docs" element={<DocsPage />} />
      <Route path="/terms" element={<TermsPage />} />
      <Route path="/fair-use" element={<FairUsePage />} />
      
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <LanguageProvider>
        <SetupContext>
          <AuthProvider>
            <SubscriptionPopup />
            <AppRoutes />
            <Toaster 
              position="top-right" 
              toastOptions={{
                style: {
                  background: '#18181b',
                  border: '1px solid #27272a',
                  color: '#fafafa',
                },
              }}
            />
          </AuthProvider>
        </SetupContext>
      </LanguageProvider>
    </BrowserRouter>
  );
}

export default App;
