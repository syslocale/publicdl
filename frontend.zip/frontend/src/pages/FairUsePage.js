import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import Logo from '../components/Logo';
import { ArrowLeft, Shield, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';

export default function FairUsePage() {
  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/docs">Docs</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/terms">Terms</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <Shield className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Fair Use Policy</h1>
            <p className="text-zinc-400">Panduan penggunaan yang bertanggung jawab</p>
          </div>
        </div>

        <div className="space-y-8 text-zinc-300">
          {/* Introduction */}
          <section>
            <p className="text-sm leading-relaxed">
              WPMTools berkomitmen untuk menyediakan layanan yang adil dan berkelanjutan bagi semua pengguna. 
              Kebijakan Fair Use ini bertujuan untuk memastikan pengalaman terbaik bagi seluruh komunitas pengguna.
            </p>
          </section>

          {/* Allowed Usage */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              Penggunaan yang Diperbolehkan
            </h2>
            <Card className="bg-emerald-500/5 border-emerald-500/20">
              <CardContent className="p-6">
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Mengelola WordPress sites yang Anda miliki atau memiliki izin untuk dikelola</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Menggunakan AI untuk membantu membuat konten original dan berkualitas</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Menjadwalkan dan mengorganisir publikasi konten secara wajar</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Berkolaborasi dengan tim dalam mengelola konten</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Menggunakan fitur bulk operations untuk efisiensi kerja yang wajar</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Prohibited Usage */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-400" />
              Penggunaan yang Dilarang
            </h2>
            <Card className="bg-red-500/5 border-red-500/20">
              <CardContent className="p-6">
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Mass spam atau auto-posting konten berlebihan yang mengganggu</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Menggunakan AI untuk menghasilkan konten menyesatkan, palsu, atau berbahaya</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Menyalin konten berhak cipta atau plagiarisme</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Mengakses WordPress sites tanpa izin</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Membuat konten ilegal, SARA, pornografi, atau melanggar hukum</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span>Menyalahgunakan sistem untuk keuntungan tidak wajar</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* AI Content Guidelines */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              Panduan Konten AI
            </h2>
            <Card className="bg-amber-500/5 border-amber-500/20">
              <CardContent className="p-6 space-y-4">
                <p className="text-sm">
                  Konten yang dihasilkan AI adalah alat bantu, bukan pengganti kreativitas manusia:
                </p>
                <ul className="space-y-2 text-sm text-zinc-400">
                  <li>• <strong className="text-white">Review sebelum publish</strong> - Selalu periksa dan edit konten AI sebelum dipublikasikan</li>
                  <li>• <strong className="text-white">Tambahkan nilai unik</strong> - Kombinasikan dengan insight dan pengalaman Anda sendiri</li>
                  <li>• <strong className="text-white">Verifikasi fakta</strong> - AI bisa menghasilkan informasi yang tidak akurat</li>
                  <li>• <strong className="text-white">Hormati hak cipta</strong> - Pastikan konten tidak melanggar hak kekayaan intelektual</li>
                  <li>• <strong className="text-white">Transparansi</strong> - Pertimbangkan untuk mengungkapkan penggunaan AI jika diperlukan</li>
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Rate Limits */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4">Batasan Penggunaan</h2>
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6">
                <p className="text-sm mb-4">
                  Untuk menjaga kualitas layanan, kami menerapkan batasan wajar:
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">Auto Post per hari</p>
                    <p className="text-white font-medium">Sesuai limit API key Anda</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">Bulk delete per request</p>
                    <p className="text-white font-medium">100 items</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">Connected domains</p>
                    <p className="text-white font-medium">Unlimited</p>
                  </div>
                  <div className="p-3 bg-zinc-800/50 rounded-lg">
                    <p className="text-zinc-400">Team members</p>
                    <p className="text-white font-medium">Unlimited</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Enforcement */}
          <section>
            <h2 className="text-xl font-bold text-white mb-4">Penegakan Kebijakan</h2>
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 text-sm space-y-3">
                <p>
                  Pelanggaran terhadap Fair Use Policy dapat mengakibatkan:
                </p>
                <ul className="list-disc list-inside text-zinc-400 space-y-1">
                  <li>Peringatan tertulis</li>
                  <li>Pembatasan fitur sementara</li>
                  <li>Penangguhan akun</li>
                  <li>Penghentian permanen akun</li>
                </ul>
                <p className="text-zinc-400">
                  Kami berhak mengambil tindakan yang diperlukan untuk melindungi layanan dan pengguna lain.
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">Dokumentasi</Link>
            <Link to="/terms" className="hover:text-white">Terms of Service</Link>
            <Link to="/fair-use" className="hover:text-white">Fair Use</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
