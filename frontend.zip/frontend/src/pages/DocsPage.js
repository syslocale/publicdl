import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import Logo from '../components/Logo';
import {
  ArrowLeft, Book, Globe, Plus, Settings, Sparkles, Users,
  FileText, Tag, Calendar, Image, Shield, Zap,
  ChevronDown, ChevronRight, CheckCircle2, AlertTriangle,
  Layers, FolderOpen, Search, Trash2, Edit,
  Crown
} from 'lucide-react';

const Section = ({ id, title, icon: Icon, iconColor, children, expanded, onToggle }) => (
  <div className="border border-zinc-800 rounded-lg overflow-hidden">
    <button
      onClick={() => onToggle(id)}
      className="w-full flex items-center justify-between p-4 bg-zinc-900/50 hover:bg-zinc-800/50 transition-colors"
    >
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 ${iconColor} rounded-lg flex items-center justify-center`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <span className="font-medium text-white">{title}</span>
      </div>
      {expanded ? (
        <ChevronDown className="w-5 h-5 text-zinc-400" />
      ) : (
        <ChevronRight className="w-5 h-5 text-zinc-400" />
      )}
    </button>
    {expanded && (
      <div className="p-6 bg-zinc-900/30 border-t border-zinc-800">
        {children}
      </div>
    )}
  </div>
);

export default function DocsPage() {
  const [expandedSection, setExpandedSection] = useState('getting-started');

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/terms">Terms</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/fair-use">Fair Use</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
            <Book className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Dokumentasi Lengkap</h1>
            <p className="text-zinc-400">Panduan komprehensif menggunakan WPMTools</p>
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          <button onClick={() => toggleSection('getting-started')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Zap className="w-5 h-5 text-amber-400 mb-2" />
            <p className="text-sm text-white font-medium">Memulai</p>
          </button>
          <button onClick={() => toggleSection('domain-management')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Globe className="w-5 h-5 text-blue-400 mb-2" />
            <p className="text-sm text-white font-medium">Domain</p>
          </button>
          <button onClick={() => toggleSection('ai-features')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Sparkles className="w-5 h-5 text-violet-400 mb-2" />
            <p className="text-sm text-white font-medium">Fitur AI</p>
          </button>
          <button onClick={() => toggleSection('team')} className="p-3 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-blue-500/50 transition-colors text-left">
            <Users className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-white font-medium">Team</p>
          </button>
        </div>

        {/* Documentation Sections */}
        <div className="space-y-4">
          
          {/* Getting Started */}
          <Section id="getting-started" expanded={expandedSection === "getting-started"} onToggle={toggleSection} title="Memulai dengan WPMTools" icon={Zap} iconColor="bg-amber-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Langkah 1: Login dengan Akun</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>1. Buka halaman Login</p>
                  <p>2. Masukkan <strong className="text-white">username</strong> dan <strong className="text-white">password</strong></p>
                  <p>3. Klik &quot;Sign in&quot;</p>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 flex items-center gap-2">
                      <Crown className="w-4 h-4" />
                      <strong>Note:</strong> Akun dibuat oleh Superadmin melalui menu Team. Tidak ada registrasi publik.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Langkah 2: Setup API Key OpenAI</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Untuk menggunakan fitur AI (Auto Post, SEO, dll), Anda perlu API key OpenAI:</p>
                  <ol className="list-decimal list-inside space-y-1 ml-2">
                    <li>Pergi ke <strong className="text-white">Settings</strong> → <strong className="text-white">Article AI</strong></li>
                    <li>Kunjungi <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">platform.openai.com/api-keys</a></li>
                    <li>Buat API key baru (mulai dengan &quot;sk-...&quot;)</li>
                    <li>Paste ke field &quot;OpenAI API Key&quot;</li>
                    <li>Klik &quot;Save Settings&quot;</li>
                  </ol>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      <strong>Penting:</strong> Jaga kerahasiaan API key. Biaya penggunaan akan ditagihkan ke akun OpenAI Anda.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Langkah 3: Tambahkan WordPress Site</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Lihat section &quot;Manajemen Domain&quot; untuk panduan lengkap.</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Domain Management */}
          <Section id="domain-management" expanded={expandedSection === "domain-management"} onToggle={toggleSection} title="Manajemen Domain WordPress" icon={Globe} iconColor="bg-blue-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Menambahkan Domain Baru</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Untuk menghubungkan WordPress site, Anda memerlukan:</p>
                  <ul className="space-y-3 mt-3">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">URL WordPress</strong>
                        <p>Alamat lengkap site Anda, contoh: https://yourblog.com</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">Username</strong>
                        <p>Username WordPress admin (bukan email)</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <strong className="text-white">Application Password</strong>
                        <p>Password khusus untuk API (BUKAN password login biasa!)</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Cara Membuat Application Password</h3>
                <div className="p-4 bg-zinc-800/50 rounded-lg">
                  <ol className="list-decimal list-inside space-y-2 text-sm text-zinc-400">
                    <li>Login ke WordPress Admin Anda</li>
                    <li>Pergi ke <strong className="text-white">Users</strong> → <strong className="text-white">Profile</strong></li>
                    <li>Scroll ke bawah ke section <strong className="text-white">&quot;Application Passwords&quot;</strong></li>
                    <li>Masukkan nama aplikasi (misal: &quot;WPMTools&quot;)</li>
                    <li>Klik <strong className="text-white">&quot;Add New Application Password&quot;</strong></li>
                    <li>Copy password yang muncul (hanya ditampilkan sekali!)</li>
                    <li>Paste ke form Add Domain di WPMTools</li>
                  </ol>
                </div>
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg mt-3">
                  <p className="text-red-400 text-sm">
                    <strong>Jika Application Passwords tidak muncul:</strong> Pastikan site Anda menggunakan HTTPS. 
                    Application Passwords memerlukan koneksi yang aman.
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Test Koneksi</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Setelah menambahkan domain:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>Klik tombol &quot;Test Connection&quot; untuk memverifikasi</li>
                    <li>Status &quot;Connected&quot; (hijau) = berhasil</li>
                    <li>Status &quot;Disconnected&quot; (merah) = cek kembali kredensial</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Filter & Sort Domain</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Di Dashboard, Anda bisa:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li><strong className="text-white">Search:</strong> Cari domain berdasarkan nama atau URL</li>
                    <li><strong className="text-white">Filter:</strong> All, Connected, atau Disconnected</li>
                    <li><strong className="text-white">Sort:</strong> Newest, Oldest, A-Z, atau Z-A</li>
                  </ul>
                </div>
              </div>
            </div>
          </Section>

          {/* Content Management */}
          <Section id="content-management" expanded={expandedSection === "content-management"} onToggle={toggleSection} title="Manajemen Konten" icon={FileText} iconColor="bg-indigo-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Posts</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Fitur manajemen posts:</p>
                  <ul className="space-y-2 mt-2">
                    <li className="flex items-center gap-2">
                      <Plus className="w-4 h-4 text-blue-400" />
                      <span><strong className="text-white">Create:</strong> Buat post baru dengan editor WYSIWYG</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Edit className="w-4 h-4 text-amber-400" />
                      <span><strong className="text-white">Edit:</strong> Edit post yang sudah ada</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Trash2 className="w-4 h-4 text-red-400" />
                      <span><strong className="text-white">Delete:</strong> Hapus satu atau multiple posts (bulk delete)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Search className="w-4 h-4 text-zinc-400" />
                      <span><strong className="text-white">Search & Filter:</strong> Cari dan filter berdasarkan status</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Pages, Tags & Categories</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Fitur serupa tersedia untuk:</p>
                  <div className="grid grid-cols-3 gap-3 mt-2">
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <Layers className="w-5 h-5 text-violet-400 mx-auto mb-1" />
                      <p className="text-white text-xs">Pages</p>
                    </div>
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <Tag className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                      <p className="text-white text-xs">Tags</p>
                    </div>
                    <div className="p-3 bg-zinc-800/50 rounded-lg text-center">
                      <FolderOpen className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                      <p className="text-white text-xs">Categories</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Menambah Category/Tag Baru</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Di Post Editor, Anda bisa membuat category/tag baru langsung:</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>Di sidebar kanan, lihat section Categories atau Tags</li>
                    <li>Ketik nama baru di input field</li>
                    <li>Klik tombol &quot;+&quot; atau tekan Enter</li>
                    <li>Category/tag baru akan otomatis terpilih</li>
                  </ol>
                </div>
              </div>
            </div>
          </Section>

          {/* AI Features */}
          <Section id="ai-features" expanded={expandedSection === "ai-features"} onToggle={toggleSection} title="Fitur AI" icon={Sparkles} iconColor="bg-violet-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Auto Post</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Generate artikel lengkap dari judul saja:</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>Pergi ke menu <strong className="text-white">Auto Post</strong></li>
                    <li>Masukkan satu atau beberapa judul (satu per baris)</li>
                    <li>Pilih domain target (bisa multiple)</li>
                    <li>Klik &quot;Generate & Publish&quot;</li>
                  </ol>
                  <p className="mt-2">AI akan generate:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>Konten artikel (sesuai jumlah kata di Settings)</li>
                    <li>Categories yang relevan</li>
                    <li>Tags yang relevan</li>
                    <li>SEO metadata (jika diaktifkan)</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Schedule Post</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Jadwalkan post untuk publish di waktu tertentu:</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>Di Auto Post page, aktifkan toggle &quot;Schedule Post&quot;</li>
                    <li>Pilih tanggal dan waktu</li>
                    <li>Klik &quot;Generate & Schedule&quot;</li>
                    <li>Post akan dipublish otomatis oleh WordPress di waktu yang ditentukan</li>
                  </ol>
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg mt-2">
                    <p className="text-blue-400 text-sm">
                      <strong>Note:</strong> Waktu menggunakan timezone WordPress site Anda.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">AI Featured Image</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Generate featured image otomatis:</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>Pergi ke <strong className="text-white">Settings</strong> → <strong className="text-white">Image AI</strong></li>
                    <li>Aktifkan toggle &quot;Enable AI Image Generation&quot;</li>
                    <li>Save Settings</li>
                    <li>Sekarang setiap Auto Post akan include featured image</li>
                  </ol>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mt-2">
                    <p className="text-amber-400 text-sm">
                      <strong>Note:</strong> Image generation menggunakan API yang sama (OpenAI) dan akan dikenakan biaya terpisah.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">SEO Assistant</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>AI akan otomatis generate:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>Meta description (150-160 karakter)</li>
                    <li>Focus keyword</li>
                    <li>Secondary keywords</li>
                    <li>SEO score (0-100)</li>
                  </ul>
                  <p className="mt-2">Aktifkan di Settings → Content → &quot;Auto Generate SEO&quot;</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Settings */}
          <Section id="settings" expanded={expandedSection === "settings"} onToggle={toggleSection} title="Pengaturan" icon={Settings} iconColor="bg-zinc-600">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Article AI</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li><strong className="text-white">Provider:</strong> Pilih OpenAI, Gemini, atau Claude</li>
                    <li><strong className="text-white">Model:</strong> Pilih model AI (default: GPT-4o-mini)</li>
                    <li><strong className="text-white">API Key:</strong> Masukkan API key provider yang dipilih</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Image AI</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li><strong className="text-white">Enable:</strong> On/Off featured image generation</li>
                    <li><strong className="text-white">Provider:</strong> Pilih provider image generation</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Content</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="space-y-2">
                    <li><strong className="text-white">Word Count:</strong> Target jumlah kata artikel (default: 800)</li>
                    <li><strong className="text-white">Language:</strong> Bahasa output (Indonesia/English)</li>
                    <li><strong className="text-white">Auto Generate Tags:</strong> Generate tags otomatis</li>
                    <li><strong className="text-white">Auto Generate Categories:</strong> Generate categories otomatis</li>
                    <li><strong className="text-white">Auto Generate SEO:</strong> Generate metadata SEO</li>
                    <li><strong className="text-white">Custom Prompt:</strong> Template prompt kustom untuk AI</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Cache</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Cache mempercepat loading data dengan menyimpan response WordPress sementara:</p>
                  <ul className="space-y-1 mt-2">
                    <li>• Stats: 1 menit</li>
                    <li>• Posts/Pages: 5 menit</li>
                    <li>• Tags/Categories/Users: 10 menit</li>
                  </ul>
                  <p className="mt-2">Klik &quot;Clear Cache&quot; untuk force refresh data dari WordPress.</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Team Management */}
          <Section id="team" expanded={expandedSection === "team"} onToggle={toggleSection} title="Manajemen Team" icon={Users} iconColor="bg-emerald-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Role Pengguna</h3>
                <div className="space-y-3 text-sm text-zinc-400">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-amber-500/20 rounded-lg">
                      <Crown className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Superadmin</p>
                      <p>Akses penuh. Bisa menambah/hapus member, mengubah settings, dan semua fitur lainnya.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-indigo-500/20 rounded-lg">
                      <Users className="w-4 h-4 text-indigo-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Admin</p>
                      <p>Akses ke semua fitur kecuali manajemen team member.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Menambah Team Member</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Hanya Superadmin yang bisa menambah member:</p>
                  <ol className="list-decimal list-inside ml-2 space-y-1">
                    <li>Pergi ke <strong className="text-white">Team</strong></li>
                    <li>Klik tab <strong className="text-white">Team Members</strong></li>
                    <li>Klik <strong className="text-white">Add Member</strong></li>
                    <li>Isi <strong className="text-white">username</strong>, nama, dan password</li>
                    <li>Member baru otomatis mendapat role Admin</li>
                  </ol>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Profile Settings</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Setiap user bisa mengubah profile mereka sendiri:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>Display Name</li>
                    <li>Password (perlu verifikasi password lama)</li>
                  </ul>
                  <p className="text-amber-400 text-xs mt-2">Note: Username tidak bisa diubah setelah dibuat.</p>
                </div>
              </div>
            </div>
          </Section>

          {/* Troubleshooting */}
          <Section id="troubleshooting" expanded={expandedSection === "troubleshooting"} onToggle={toggleSection} title="Troubleshooting" icon={AlertTriangle} iconColor="bg-red-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-3">Koneksi WordPress Gagal</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Jika status domain &quot;Disconnected&quot;, cek:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>URL WordPress benar dan menggunakan HTTPS</li>
                    <li>Username benar (bukan email)</li>
                    <li>Application Password benar (bukan password login)</li>
                    <li>REST API WordPress aktif (tidak diblokir plugin security)</li>
                    <li>Permalink WordPress tidak menggunakan &quot;Plain&quot;</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">AI Generation Error</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li><strong className="text-white">&quot;API key not configured&quot;</strong> - Tambahkan API key di Settings</li>
                    <li><strong className="text-white">&quot;Rate limit exceeded&quot;</strong> - Tunggu beberapa menit, atau upgrade plan OpenAI</li>
                    <li><strong className="text-white">&quot;Insufficient quota&quot;</strong> - Tambahkan credit di akun OpenAI</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-3">Loading Lambat</h3>
                <div className="space-y-2 text-sm text-zinc-400">
                  <p>Loading data dari WordPress bergantung pada:</p>
                  <ul className="list-disc list-inside ml-2 space-y-1">
                    <li>Kualitas hosting WordPress (shared hosting lebih lambat)</li>
                    <li>Jumlah plugin WordPress (lebih banyak = lebih lambat)</li>
                    <li>Lokasi server WordPress</li>
                  </ul>
                  <p className="mt-2">Tips: Gunakan fitur Cache untuk mempercepat loading berulang.</p>
                </div>
              </div>
            </div>
          </Section>

          {/* FAQ */}
          <Section id="faq" expanded={expandedSection === "faq"} onToggle={toggleSection} title="FAQ" icon={Shield} iconColor="bg-teal-500">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-white mb-2">Apakah API key saya aman?</h3>
                <p className="text-sm text-zinc-400">
                  Ya, API key disimpan dengan enkripsi di database. Key tidak pernah ditampilkan kembali setelah disimpan, 
                  hanya status &quot;key is set&quot; yang ditampilkan.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">Berapa biaya penggunaan AI?</h3>
                <p className="text-sm text-zinc-400">
                  WPMTools sendiri gratis. Biaya AI tergantung pada provider yang Anda gunakan (OpenAI, dll). 
                  Cek pricing di dashboard masing-masing provider. Estimasi: ~$0.01-0.05 per artikel (GPT-4o-mini).
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">Apakah bisa mengelola unlimited WordPress sites?</h3>
                <p className="text-sm text-zinc-400">
                  Ya, tidak ada batasan jumlah domain yang bisa ditambahkan.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">Apakah konten AI 100% original?</h3>
                <p className="text-sm text-zinc-400">
                  AI menghasilkan konten berdasarkan training data. Meskipun jarang, ada kemungkinan kesamaan dengan 
                  konten lain. Selalu review dan edit konten sebelum publish untuk memastikan originalitas dan akurasi.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium text-white mb-2">Bagaimana jika WordPress saya tidak support REST API?</h3>
                <p className="text-sm text-zinc-400">
                  WordPress versi 4.7+ sudah include REST API secara default. Jika tidak bisa diakses, cek apakah 
                  ada plugin security yang memblokir, atau permalink setting bukan &quot;Plain&quot;.
                </p>
              </div>
            </div>
          </Section>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">Dokumentasi</Link>
            <Link to="/terms" className="hover:text-white">Terms of Service</Link>
            <Link to="/fair-use" className="hover:text-white">Fair Use</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
