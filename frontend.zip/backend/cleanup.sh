#!/bin/bash
# ===========================================
# WPMTools - Pre-Deployment Cleanup Script
# ===========================================
# Jalankan script ini sebelum deploy ke client
# untuk menghapus test data dan reset database
#
# Usage: ./cleanup.sh
# ===========================================

set -e

echo ""
echo "=========================================="
echo "🧹 WPMTools Pre-Deployment Cleanup"
echo "=========================================="
echo ""

# Check if running from correct directory
if [ ! -f "server.py" ]; then
    echo "❌ Error: Jalankan script ini dari folder backend/"
    echo "   cd /var/www/wpmtools/backend"
    echo "   ./cleanup.sh"
    exit 1
fi

# Activate virtual environment if exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

echo "⚠️  Script ini akan:"
echo "   - Menghapus SEMUA domains"
echo "   - Menghapus SEMUA activity logs"
echo "   - Menghapus SEMUA users"
echo "   - Membuat ulang user superadmin default"
echo ""
read -p "Lanjutkan? (ketik 'YES'): " confirm

if [ "$confirm" != "YES" ]; then
    echo "❌ Dibatalkan"
    exit 0
fi

echo ""
echo "🔄 Resetting database..."
python3 seed.py reset

echo ""
echo "=========================================="
echo "✅ Cleanup selesai!"
echo "=========================================="
echo ""
echo "🔐 Login dengan:"
echo "   Username: superadmin"
echo "   Password: Superadmin123!"
echo ""
echo "⚠️  PENTING: Ganti password setelah login!"
echo ""
