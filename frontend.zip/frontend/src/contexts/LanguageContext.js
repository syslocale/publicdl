import { createContext, useContext, useState, useEffect } from 'react';
import { translations } from '../lib/translations';

const LanguageContext = createContext(null);

export const LanguageProvider = ({ children }) => {
  // Get initial language from localStorage or default to 'en'
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('wpmtools_language') || 'en';
  });

  // Save language preference to localStorage
  useEffect(() => {
    localStorage.setItem('wpmtools_language', language);
  }, [language]);

  // Get translation function
  const t = (key) => {
    return translations[language]?.[key] || translations['en']?.[key] || key;
  };

  // Toggle between languages
  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'id' : 'en');
  };

  // Set specific language
  const setLang = (lang) => {
    if (lang === 'en' || lang === 'id') {
      setLanguage(lang);
    }
  };

  return (
    <LanguageContext.Provider value={{ 
      language, 
      setLanguage: setLang, 
      toggleLanguage, 
      t 
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
