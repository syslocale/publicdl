import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { domainsApi, aiApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Textarea } from '../components/ui/textarea';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { Switch } from '../components/ui/switch';
import { toast } from 'sonner';
import {
  ArrowLeft, Sparkles, Send, Loader2, Check,
  ExternalLink, LogOut, FileText, RefreshCw, X, AlertCircle, Clock, Calendar, Globe
} from 'lucide-react';
import Logo from '../components/Logo';

export default function AutoPostPage() {
  const { user, logout } = useAuth();
  const [domains, setDomains] = useState([]);
  const [loadingDomains, setLoadingDomains] = useState(true);
  const [selectedDomains, setSelectedDomains] = useState([]);
  const [titles, setTitles] = useState('');
  const [posting, setPosting] = useState(false);
  const [results, setResults] = useState([]);
  const [currentProgress, setCurrentProgress] = useState({ current: 0, total: 0, title: '' });
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('09:00');

  useEffect(() => {
    fetchDomains();
  }, []);

  const fetchDomains = async () => {
    setLoadingDomains(true);
    try {
      const response = await domainsApi.list();
      setDomains(response.data);
    } catch (error) {
      toast.error('Failed to load domains');
    } finally {
      setLoadingDomains(false);
    }
  };

  const titleList = titles.split('\n').map(t => t.trim()).filter(t => t.length > 0);

  const toggleDomain = (domainId) => {
    setSelectedDomains(prev => 
      prev.includes(domainId) 
        ? prev.filter(id => id !== domainId)
        : [...prev, domainId]
    );
  };

  const selectAllDomains = () => {
    if (selectedDomains.length === domains.length) {
      setSelectedDomains([]);
    } else {
      setSelectedDomains(domains.map(d => d.id));
    }
  };

  const handleAutoPost = async () => {
    if (titleList.length === 0) {
      toast.error('Please enter at least one title');
      return;
    }
    if (selectedDomains.length === 0) {
      toast.error('Please select at least one domain');
      return;
    }
    if (scheduleEnabled && !scheduleDate) {
      toast.error('Please select a date for scheduling');
      return;
    }

    setPosting(true);
    setResults([]);
    
    // Build scheduled datetime in ISO format if scheduling is enabled
    let scheduledDatetime = null;
    if (scheduleEnabled && scheduleDate) {
      scheduledDatetime = `${scheduleDate}T${scheduleTime}:00`;
    }
    
    const totalPosts = titleList.length * selectedDomains.length;
    let completedPosts = 0;
    const newResults = [];

    for (const title of titleList) {
      for (const domainId of selectedDomains) {
        const domain = domains.find(d => d.id === domainId);
        setCurrentProgress({ 
          current: completedPosts + 1, 
          total: totalPosts, 
          title: title,
          domain: domain?.name 
        });

        try {
          const response = await aiApi.autoPost(domainId, title, scheduledDatetime);
          newResults.push({
            success: true,
            title: title,
            domain: domain,
            post: response.data.post,
            generated: response.data.generated,
            seo: response.data.seo,
            scheduled: scheduleEnabled
          });
        } catch (error) {
          newResults.push({
            success: false,
            title: title,
            domain: domain,
            error: error.response?.data?.detail || 'Failed to post'
          });
        }
        
        completedPosts++;
        setResults([...newResults]);
      }
    }

    setPosting(false);
    setCurrentProgress({ current: 0, total: 0, title: '' });
    
    const successCount = newResults.filter(r => r.success).length;
    const failCount = newResults.filter(r => !r.success).length;
    
    if (successCount > 0 && failCount === 0) {
      const action = scheduleEnabled ? 'scheduled' : 'published';
      toast.success(`All ${successCount} posts ${action} successfully!`);
    } else if (successCount > 0) {
      const action = scheduleEnabled ? 'scheduled' : 'published';
      toast.warning(`${successCount} posts ${action}, ${failCount} failed`);
    } else {
      toast.error('All posts failed');
    }
  };

  const handleReset = () => {
    setTitles('');
    setResults([]);
    setSelectedDomains([]);
  };

  const successResults = results.filter(r => r.success);
  const failedResults = results.filter(r => !r.success);

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400">{user?.name}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-[Chivo]">AI Auto Post</h1>
            <p className="text-zinc-400 text-sm">Bulk generate and publish content with AI</p>
          </div>
        </div>

        {results.length === 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: Titles Input */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">
                    Post Titles
                  </Label>
                  {titleList.length > 0 && (
                    <span className="text-xs text-indigo-400 font-mono bg-indigo-500/10 px-2 py-1 rounded">
                      {titleList.length} title{titleList.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
                <Textarea
                  value={titles}
                  onChange={(e) => setTitles(e.target.value)}
                  placeholder="Enter one title per line, e.g.:&#10;10 Tips for Better Productivity&#10;How to Start a Business in 2025&#10;The Ultimate Guide to Digital Marketing"
                  className="bg-zinc-900 border-white/10 text-white min-h-[200px] font-mono text-sm leading-relaxed"
                  disabled={posting}
                />
                <p className="text-xs text-zinc-600">
                  Enter one title per line. Each title will be posted to all selected domains.
                </p>
              </CardContent>
            </Card>

            {/* Right: Domain Selection */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">
                    Select Domains
                  </Label>
                  {selectedDomains.length > 0 && (
                    <span className="text-xs text-emerald-400 font-mono bg-emerald-500/10 px-2 py-1 rounded">
                      {selectedDomains.length} selected
                    </span>
                  )}
                </div>

                {loadingDomains ? (
                  <div className="flex items-center gap-2 text-zinc-500 py-8 justify-center">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Loading domains...</span>
                  </div>
                ) : domains.length === 0 ? (
                  <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                    <p className="text-sm text-amber-400">No domains found. Please add a domain first.</p>
                    <Button asChild size="sm" className="mt-2 bg-amber-600 hover:bg-amber-500">
                      <Link to="/dashboard">Go to Dashboard</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Select All */}
                    <div 
                      className="flex items-center gap-3 p-3 bg-zinc-800/50 border border-white/10 rounded-lg cursor-pointer hover:bg-zinc-800 transition-colors"
                      onClick={selectAllDomains}
                    >
                      <Checkbox 
                        checked={selectedDomains.length === domains.length && domains.length > 0}
                        onCheckedChange={selectAllDomains}
                        className="border-zinc-600"
                      />
                      <span className="text-sm text-zinc-300 font-medium">Select All Domains</span>
                      <span className="text-xs text-zinc-500 ml-auto font-mono">({domains.length})</span>
                    </div>

                    {/* Domain List */}
                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-2">
                      {domains.map((domain) => (
                        <div 
                          key={domain.id}
                          className={`flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-all ${
                            selectedDomains.includes(domain.id) 
                              ? 'bg-indigo-500/10 border-indigo-500/30' 
                              : 'bg-zinc-900/50 border-white/5 hover:border-white/10'
                          }`}
                          onClick={() => toggleDomain(domain.id)}
                        >
                          <Checkbox 
                            checked={selectedDomains.includes(domain.id)}
                            onCheckedChange={() => toggleDomain(domain.id)}
                            className="border-zinc-600"
                          />
                          <Globe className={`w-4 h-4 ${selectedDomains.includes(domain.id) ? 'text-indigo-400' : 'text-zinc-500'}`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-white font-medium truncate">{domain.name}</p>
                            <p className="text-xs text-zinc-500 truncate">{domain.url}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Bottom: Schedule & Summary & Action */}
            <div className="lg:col-span-2 space-y-4">
              {/* Schedule Option */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-amber-400" />
                      <div>
                        <Label className="text-sm text-white font-medium">Schedule Post</Label>
                        <p className="text-xs text-zinc-500">Set a future date and time to publish</p>
                      </div>
                    </div>
                    <Switch
                      checked={scheduleEnabled}
                      onCheckedChange={setScheduleEnabled}
                      disabled={posting}
                    />
                  </div>
                  
                  {scheduleEnabled && (
                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                      <div className="space-y-2">
                        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Date</Label>
                        <Input
                          type="date"
                          value={scheduleDate}
                          onChange={(e) => setScheduleDate(e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                          className="bg-zinc-900 border-white/10 text-white"
                          disabled={posting}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Time</Label>
                        <Input
                          type="time"
                          value={scheduleTime}
                          onChange={(e) => setScheduleTime(e.target.value)}
                          className="bg-zinc-900 border-white/10 text-white"
                          disabled={posting}
                        />
                      </div>
                      <div className="col-span-2">
                        <p className="text-xs text-amber-400/80 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Posts will be scheduled for {scheduleDate || '[select date]'} at {scheduleTime} (WordPress timezone)
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Summary */}
              {titleList.length > 0 && selectedDomains.length > 0 && (
                <div className="p-4 bg-gradient-to-r from-violet-500/10 to-indigo-500/10 border border-violet-500/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-5 h-5 text-violet-400" />
                    <div className="flex-1">
                      <p className="text-sm text-violet-300">
                        <span className="font-bold">{titleList.length}</span> title{titleList.length > 1 ? 's' : ''} × <span className="font-bold">{selectedDomains.length}</span> domain{selectedDomains.length > 1 ? 's' : ''} = <span className="font-bold text-white">{titleList.length * selectedDomains.length}</span> posts will be {scheduleEnabled ? 'scheduled' : 'created'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Progress */}
              {posting && (
                <div className="p-4 bg-zinc-900 border border-white/10 rounded-lg">
                  <div className="flex items-center gap-3 mb-3">
                    <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                    <div className="flex-1">
                      <p className="text-sm text-white">
                        Publishing {currentProgress.current} of {currentProgress.total}...
                      </p>
                      <p className="text-xs text-zinc-500 truncate">
                        &quot;{currentProgress.title}&quot; → {currentProgress.domain}
                      </p>
                    </div>
                    <span className="text-sm font-mono text-indigo-400">
                      {Math.round((currentProgress.current / currentProgress.total) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-800 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-violet-500 to-indigo-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(currentProgress.current / currentProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Generate Button */}
              <Button
                onClick={handleAutoPost}
                disabled={posting || titleList.length === 0 || selectedDomains.length === 0 || (scheduleEnabled && !scheduleDate)}
                className={`w-full text-white font-medium h-12 text-base transition-all duration-200 hover:-translate-y-0.5 disabled:opacity-50 disabled:hover:translate-y-0 ${
                  scheduleEnabled 
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500'
                }`}
              >
                {posting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    {scheduleEnabled ? 'Scheduling Posts...' : 'Publishing Posts...'}
                  </>
                ) : scheduleEnabled ? (
                  <>
                    <Calendar className="w-5 h-5 mr-2" />
                    Generate & Schedule {titleList.length * selectedDomains.length || ''} Post{(titleList.length * selectedDomains.length) > 1 ? 's' : ''}
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Generate & Publish {titleList.length * selectedDomains.length || ''} Post{(titleList.length * selectedDomains.length) > 1 ? 's' : ''}
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          /* Results View */
          <div className="space-y-6">
            {/* Summary Header */}
            <div className="flex items-center justify-between p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  failedResults.length === 0 ? 'bg-emerald-500' : failedResults.length === results.length ? 'bg-red-500' : 'bg-amber-500'
                }`}>
                  {failedResults.length === 0 ? (
                    <Check className="w-6 h-6 text-white" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    {failedResults.length === 0 ? 'All Posts Published!' : 
                     failedResults.length === results.length ? 'All Posts Failed' : 
                     'Partially Completed'}
                  </h2>
                  <p className="text-sm text-zinc-400">
                    {successResults.length} success, {failedResults.length} failed
                  </p>
                </div>
              </div>
              <Button onClick={handleReset} variant="outline" className="border-white/10 text-white hover:bg-zinc-800">
                <RefreshCw className="w-4 h-4 mr-2" />
                Create More
              </Button>
            </div>

            {/* Success Results */}
            {successResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm text-emerald-400 font-mono uppercase tracking-widest flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  {successResults[0]?.scheduled ? 'Successfully Scheduled' : 'Successfully Published'} ({successResults.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {successResults.map((result, i) => (
                    <div key={i} className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-white font-medium truncate">{result.title}</p>
                          <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1">
                            <Globe className="w-3 h-3" />
                            {result.domain?.name}
                          </p>
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <span className="text-xs text-zinc-600 font-mono">ID: {result.post?.id}</span>
                            <span className="text-xs text-zinc-600 font-mono">•</span>
                            <span className="text-xs text-zinc-600 font-mono">{result.generated?.word_count} words</span>
                            {result.generated?.has_featured_image && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className="text-xs text-indigo-400 font-mono">📷 Image</span>
                              </>
                            )}
                            {result.seo?.seo_score && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className={`text-xs font-mono ${
                                  result.seo.seo_score >= 80 ? 'text-emerald-400' :
                                  result.seo.seo_score >= 60 ? 'text-amber-400' : 'text-red-400'
                                }`}>
                                  SEO: {result.seo.seo_score}%
                                </span>
                              </>
                            )}
                            {result.post?.status === 'future' && (
                              <>
                                <span className="text-xs text-zinc-600 font-mono">•</span>
                                <span className="text-xs text-amber-400 font-mono flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Scheduled
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        <Button asChild size="sm" variant="ghost" className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10">
                          <a href={result.post?.link} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Failed Results */}
            {failedResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm text-red-400 font-mono uppercase tracking-widest flex items-center gap-2">
                  <X className="w-4 h-4" />
                  Failed ({failedResults.length})
                </h3>
                <div className="space-y-2">
                  {failedResults.map((result, i) => (
                    <div key={i} className="p-3 bg-red-500/5 border border-red-500/20 rounded-lg flex items-center gap-3">
                      <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white truncate">{result.title}</p>
                        <p className="text-xs text-zinc-500">{result.domain?.name} - {result.error}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
