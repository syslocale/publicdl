import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { settingsApi, cacheApi, limitsApi, subscriptionApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Switch } from '../components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import {
  ArrowLeft, Settings, Key, Sparkles, Save, Loader2,
  LogOut, Eye, EyeOff, Trash2, Languages, FileText, Image,
  Cpu, CheckCircle2, XCircle, MessageSquareText, Database, RefreshCw,
  Shield, Plus, Network, ScrollText, User, Clock, Gauge, Users, Globe, Zap,
  Calendar, AlertTriangle
} from 'lucide-react';
import Logo from '../components/Logo';
import { LanguageSwitcher } from '../components/LanguageSwitcher';

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [clearingCache, setClearingCache] = useState(false);
  const [cacheStats, setCacheStats] = useState(null);
  const [showKeys, setShowKeys] = useState({ openai: false, gemini: false, claude: false });
  // IP Whitelist state (Superadmin only)
  const [ipWhitelist, setIpWhitelist] = useState([]);
  const [newIpAddress, setNewIpAddress] = useState('');
  const [newIpDescription, setNewIpDescription] = useState('');
  const [addingIp, setAddingIp] = useState(false);
  // Activity Logs state (Superadmin only)
  const [activityLogs, setActivityLogs] = useState([]);
  const [logsTotal, setLogsTotal] = useState(0);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [clearingLogs, setClearingLogs] = useState(false);
  // App Limits state (Superadmin only) - Default: -1 = unlimited
  const [limits, setLimits] = useState({
    max_domains: -1,
    max_bulk_titles: 20,
    max_concurrent_domains: 5,
    delay_between_posts: 3,
    max_team_members: -1,
    max_posts_per_day: -1,
    max_ai_requests_per_day: -1
  });
  const [limitsUsage, setLimitsUsage] = useState(null);
  const [savingLimits, setSavingLimits] = useState(false);
  // Subscription state (Superadmin only)
  const [subscriptionDueDate, setSubscriptionDueDate] = useState('');
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [savingSubscription, setSavingSubscription] = useState(false);
  
  const isSuperadmin = user?.role === 'superadmin';
  const isStaff = user?.role === 'staff';
  const canEditSettings = !isStaff; // Staff cannot edit settings
  
  const [settings, setSettings] = useState({
    // Article AI
    article_ai_provider: 'openai',
    article_ai_model: 'gpt-4o-mini',
    openai_api_key: '',
    openai_api_key_set: false,
    gemini_api_key: '',
    gemini_api_key_set: false,
    claude_api_key: '',
    claude_api_key_set: false,
    // Image AI
    image_ai_provider: 'openai',
    image_ai_enabled: false,
    // Content
    default_post_status: 'draft',
    auto_generate_tags: true,
    auto_generate_categories: true,
    auto_generate_seo: true,
    ai_word_count: 800,
    language: 'id',
    // Custom Prompt
    custom_prompt_enabled: false,
    custom_prompt: ''
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await settingsApi.get();
      setSettings({
        ...response.data,
        openai_api_key: '',
        gemini_api_key: '',
        claude_api_key: ''
      });
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (isStaff) {
      toast.error('Staff members cannot modify settings');
      return;
    }
    setSaving(true);
    try {
      const dataToSave = { ...settings };
      // Only send API keys if user has entered new ones
      if (!dataToSave.openai_api_key) delete dataToSave.openai_api_key;
      if (!dataToSave.gemini_api_key) delete dataToSave.gemini_api_key;
      if (!dataToSave.claude_api_key) delete dataToSave.claude_api_key;
      delete dataToSave.openai_api_key_set;
      delete dataToSave.gemini_api_key_set;
      delete dataToSave.claude_api_key_set;

      const response = await settingsApi.update(dataToSave);
      setSettings({
        ...response.data,
        openai_api_key: '',
        gemini_api_key: '',
        claude_api_key: ''
      });
      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const toggleShowKey = (key) => {
    setShowKeys(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleResetApiKey = async (provider) => {
    if (!window.confirm(`Are you sure you want to delete your ${provider.toUpperCase()} API key?`)) return;
    
    try {
      await settingsApi.deleteSpecificApiKey(provider);
      setSettings(prev => ({
        ...prev,
        [`${provider}_api_key`]: '',
        [`${provider}_api_key_set`]: false
      }));
      toast.success(`${provider.charAt(0).toUpperCase() + provider.slice(1)} API key deleted`);
    } catch (error) {
      toast.error('Failed to delete API key');
    }
  };

  // IP Whitelist functions (Superadmin only)
  const fetchIpWhitelist = async () => {
    if (!isSuperadmin) return;
    try {
      const response = await settingsApi.getIpWhitelist();
      setIpWhitelist(response.data.whitelist || []);
    } catch (error) {
      console.error('Failed to fetch IP whitelist:', error);
    }
  };

  const handleAddIp = async () => {
    if (!newIpAddress.trim()) {
      toast.error('Please enter an IP address');
      return;
    }
    
    setAddingIp(true);
    try {
      const response = await settingsApi.addIpWhitelist(newIpAddress.trim(), newIpDescription.trim());
      setIpWhitelist(prev => [...prev, response.data.entry]);
      setNewIpAddress('');
      setNewIpDescription('');
      toast.success('IP added to whitelist');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to add IP');
    } finally {
      setAddingIp(false);
    }
  };

  const handleDeleteIp = async (ipId, ipAddress) => {
    if (!window.confirm(`Are you sure you want to remove ${ipAddress} from whitelist?`)) return;
    
    try {
      await settingsApi.deleteIpWhitelist(ipId);
      setIpWhitelist(prev => prev.filter(ip => ip.id !== ipId));
      toast.success('IP removed from whitelist');
    } catch (error) {
      toast.error('Failed to remove IP');
    }
  };

  // Activity Logs functions (Superadmin only)
  const fetchActivityLogs = async () => {
    if (!isSuperadmin) return;
    setLoadingLogs(true);
    try {
      const response = await settingsApi.getActivityLogs(100, 0);
      setActivityLogs(response.data.logs || []);
      setLogsTotal(response.data.total || 0);
    } catch (error) {
      console.error('Failed to fetch activity logs:', error);
    } finally {
      setLoadingLogs(false);
    }
  };

  const handleClearLogs = async () => {
    if (!window.confirm('Are you sure you want to clear all activity logs? This action cannot be undone.')) return;
    
    setClearingLogs(true);
    try {
      await settingsApi.clearActivityLogs();
      setActivityLogs([]);
      setLogsTotal(0);
      toast.success('Activity logs cleared');
    } catch (error) {
      toast.error('Failed to clear logs');
    } finally {
      setClearingLogs(false);
    }
  };

  const getActionColor = (action) => {
    switch (action) {
      case 'LOGIN': return 'bg-blue-500/20 text-blue-400';
      case 'CREATE_DOMAIN': return 'bg-emerald-500/20 text-emerald-400';
      case 'DELETE_DOMAIN': return 'bg-red-500/20 text-red-400';
      case 'AUTO_POST': return 'bg-violet-500/20 text-violet-400';
      default: return 'bg-zinc-500/20 text-zinc-400';
    }
  };

  const fetchCacheStats = async () => {
    try {
      const response = await cacheApi.stats();
      setCacheStats(response.data);
    } catch (error) {
      console.error('Failed to fetch cache stats:', error);
    }
  };

  const handleClearCache = async () => {
    setClearingCache(true);
    try {
      const response = await cacheApi.clear();
      toast.success(`Cache cleared! ${response.data.cleared} items removed`);
      setCacheStats({ total_items: 0, items: [] });
    } catch (error) {
      toast.error('Failed to clear cache');
    } finally {
      setClearingCache(false);
    }
  };

  // Fetch app limits and usage
  const fetchLimits = async () => {
    try {
      const [limitsRes, usageRes] = await Promise.all([
        limitsApi.get(),
        limitsApi.getUsage()
      ]);
      setLimits(limitsRes.data);
      setLimitsUsage(usageRes.data);
    } catch (error) {
      console.error('Failed to fetch limits:', error);
    }
  };

  const handleSaveLimits = async () => {
    setSavingLimits(true);
    try {
      await limitsApi.update(limits);
      toast.success('Limits saved successfully');
      fetchLimits(); // Refresh usage
    } catch (error) {
      toast.error('Failed to save limits');
    } finally {
      setSavingLimits(false);
    }
  };

  // Fetch subscription status (Superadmin only)
  const fetchSubscription = async () => {
    try {
      const response = await subscriptionApi.getStatus();
      setSubscriptionStatus(response.data);
      if (response.data.due_date) {
        setSubscriptionDueDate(response.data.due_date.split('T')[0]); // Get date part only
      }
    } catch (error) {
      console.error('Failed to fetch subscription:', error);
    }
  };

  const handleSaveSubscription = async () => {
    setSavingSubscription(true);
    try {
      await subscriptionApi.setDueDate(subscriptionDueDate || null);
      toast.success('Due date updated successfully');
      fetchSubscription(); // Refresh status
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save due date');
    } finally {
      setSavingSubscription(false);
    }
  };

  const handleClearDueDate = async () => {
    setSavingSubscription(true);
    try {
      await subscriptionApi.setDueDate(null);
      setSubscriptionDueDate('');
      toast.success('Due date removed (unlimited)');
      fetchSubscription();
    } catch (error) {
      toast.error('Failed to clear due date');
    } finally {
      setSavingSubscription(false);
    }
  };

  const aiModels = {
    openai: [
      { value: 'gpt-4o-mini', label: 'GPT-4o Mini (Fast & Cheap)' },
      { value: 'gpt-4o', label: 'GPT-4o (Balanced)' },
      { value: 'gpt-4.1-mini', label: 'GPT-4.1 Mini (Fast)' },
      { value: 'gpt-4.1', label: 'GPT-4.1 (Improved)' },
      { value: 'gpt-5', label: 'GPT-5 (Latest & Best)' },
      { value: 'gpt-5-mini', label: 'GPT-5 Mini (Latest Fast)' },
    ],
    gemini: [
      { value: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash (Fast)' },
      { value: 'gemini-1.5-pro', label: 'Gemini 1.5 Pro (Best)' },
      { value: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash (Latest)' },
      { value: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro (Latest Best)' },
    ],
    claude: [
      { value: 'claude-3-haiku', label: 'Claude 3 Haiku (Fast)' },
      { value: 'claude-3-sonnet', label: 'Claude 3 Sonnet (Balanced)' },
      { value: 'claude-3-opus', label: 'Claude 3 Opus (Best)' },
      { value: 'claude-sonnet-4', label: 'Claude Sonnet 4 (Latest)' },
    ]
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  const renderApiKeyStatus = (isSet) => (
    <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${isSet ? 'bg-emerald-500/10 text-emerald-400' : 'bg-zinc-500/10 text-zinc-500'}`}>
      {isSet ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
      {isSet ? 'Configured' : 'Not Set'}
    </span>
  );

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400">{user?.name}</span>
              <Button variant="ghost" size="sm" onClick={logout} className="text-zinc-400 hover:text-white hover:bg-zinc-800">
                <LogOut className="w-4 h-4 mr-2" />{t('logout')}
              </Button>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Staff Warning */}
        {isStaff && (
          <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
            <p className="text-sm text-amber-400 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              {t('staffViewOnly')}
            </p>
          </div>
        )}
        
        {/* Page Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-zinc-800 rounded-xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">{t('settings')}</h1>
            <p className="text-zinc-400 text-sm">{t('settingsDesc')}</p>
          </div>
        </div>

        <Tabs defaultValue="article" className="space-y-6" onValueChange={(v) => {
          if (v === 'cache') fetchCacheStats();
          if (v === 'security') fetchIpWhitelist();
          if (v === 'logs') fetchActivityLogs();
          if (v === 'limits') fetchLimits();
          if (v === 'subscription') fetchSubscription();
        }}>
          <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
            <TabsTrigger value="article" className="data-[state=active]:bg-indigo-600">
              <FileText className="w-4 h-4 mr-2" />{t('articleAI')}
            </TabsTrigger>
            <TabsTrigger value="image" className="data-[state=active]:bg-indigo-600">
              <Image className="w-4 h-4 mr-2" />{t('imageAI')}
            </TabsTrigger>
            <TabsTrigger value="content" className="data-[state=active]:bg-indigo-600">
              <Sparkles className="w-4 h-4 mr-2" />{t('content')}
            </TabsTrigger>
            <TabsTrigger value="cache" className="data-[state=active]:bg-indigo-600">
              <Database className="w-4 h-4 mr-2" />{t('cache')}
            </TabsTrigger>
            {isSuperadmin && (
              <TabsTrigger value="limits" className="data-[state=active]:bg-indigo-600">
                <Gauge className="w-4 h-4 mr-2" />{t('limits')}
              </TabsTrigger>
            )}
            {isSuperadmin && (
              <TabsTrigger value="subscription" className="data-[state=active]:bg-amber-600">
                <Calendar className="w-4 h-4 mr-2" />{t('dueDate')}
              </TabsTrigger>
            )}
            {isSuperadmin && (
              <TabsTrigger value="security" className="data-[state=active]:bg-indigo-600">
                <Shield className="w-4 h-4 mr-2" />{t('security')}
              </TabsTrigger>
            )}
            {isSuperadmin && (
              <TabsTrigger value="logs" className="data-[state=active]:bg-indigo-600">
                <ScrollText className="w-4 h-4 mr-2" />{t('logs')}
              </TabsTrigger>
            )}
          </TabsList>

          {/* Article AI Tab */}
          <TabsContent value="article" className="space-y-6">
            {/* Provider Selection */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-violet-500/10 border border-violet-500/20 rounded-lg flex items-center justify-center">
                    <Cpu className="w-5 h-5 text-violet-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">{t('aiProvider')}</CardTitle>
                    <CardDescription className="text-zinc-500">{t('aiProviderDesc')}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  {['openai', 'gemini', 'claude'].map((provider) => (
                    <button
                      key={provider}
                      onClick={() => setSettings({ ...settings, article_ai_provider: provider })}
                      className={`p-4 rounded-lg border transition-all ${
                        settings.article_ai_provider === provider
                          ? 'bg-indigo-500/10 border-indigo-500/50 ring-1 ring-indigo-500/30'
                          : 'bg-zinc-800/50 border-white/5 hover:border-white/10'
                      }`}
                    >
                      <p className="text-sm font-medium text-white capitalize">{provider}</p>
                      <p className="text-xs text-zinc-500 mt-1">
                        {provider === 'openai' && 'GPT-4o'}
                        {provider === 'gemini' && 'Gemini 1.5'}
                        {provider === 'claude' && 'Claude 3'}
                      </p>
                    </button>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Model</Label>
                  <Select 
                    value={settings.article_ai_model} 
                    onValueChange={(v) => setSettings({ ...settings, article_ai_model: v })}
                  >
                    <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-white/10">
                      {aiModels[settings.article_ai_provider]?.map((model) => (
                        <SelectItem key={model.value} value={model.value}>{model.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* API Keys */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center justify-center">
                    <Key className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">API Keys</CardTitle>
                    <CardDescription className="text-zinc-500">Configure API keys for each provider</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* OpenAI Key */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">OpenAI API Key</Label>
                    {renderApiKeyStatus(settings.openai_api_key_set)}
                  </div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        type={showKeys.openai ? 'text' : 'password'}
                        value={settings.openai_api_key}
                        onChange={(e) => setSettings({ ...settings, openai_api_key: e.target.value })}
                        placeholder={settings.openai_api_key_set ? '••••••••••••••••' : 'sk-...'}
                        className="bg-zinc-900 border-white/10 text-white pr-10 font-mono"
                      />
                      <button type="button" onClick={() => toggleShowKey('openai')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                        {showKeys.openai ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {settings.openai_api_key_set && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => handleResetApiKey('openai')}
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                        title="Delete API Key"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Gemini Key */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Gemini API Key</Label>
                    {renderApiKeyStatus(settings.gemini_api_key_set)}
                  </div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        type={showKeys.gemini ? 'text' : 'password'}
                        value={settings.gemini_api_key}
                        onChange={(e) => setSettings({ ...settings, gemini_api_key: e.target.value })}
                        placeholder={settings.gemini_api_key_set ? '••••••••••••••••' : 'AIza...'}
                        className="bg-zinc-900 border-white/10 text-white pr-10 font-mono"
                      />
                      <button type="button" onClick={() => toggleShowKey('gemini')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                        {showKeys.gemini ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {settings.gemini_api_key_set && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => handleResetApiKey('gemini')}
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                        title="Delete API Key"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Claude Key */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Claude API Key</Label>
                    {renderApiKeyStatus(settings.claude_api_key_set)}
                  </div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        type={showKeys.claude ? 'text' : 'password'}
                        value={settings.claude_api_key}
                        onChange={(e) => setSettings({ ...settings, claude_api_key: e.target.value })}
                        placeholder={settings.claude_api_key_set ? '••••••••••••••••' : 'sk-ant-...'}
                        className="bg-zinc-900 border-white/10 text-white pr-10 font-mono"
                      />
                      <button type="button" onClick={() => toggleShowKey('claude')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                        {showKeys.claude ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {settings.claude_api_key_set && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => handleResetApiKey('claude')}
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                        title="Delete API Key"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Image AI Tab */}
          <TabsContent value="image" className="space-y-6">
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-pink-500/10 border border-pink-500/20 rounded-lg flex items-center justify-center">
                    <Image className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">Featured Image Generation</CardTitle>
                    <CardDescription className="text-zinc-500">Auto-generate featured images for posts</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-lg border border-white/5">
                  <div>
                    <p className="text-sm text-white font-medium">Enable AI Image Generation</p>
                    <p className="text-xs text-zinc-500 mt-0.5">Generate featured images when creating posts</p>
                  </div>
                  <Switch
                    checked={settings.image_ai_enabled}
                    onCheckedChange={(checked) => setSettings({ ...settings, image_ai_enabled: checked })}
                  />
                </div>

                {settings.image_ai_enabled && (
                  <div className="space-y-4">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Image Provider</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {['openai', 'gemini'].map((provider) => (
                        <button
                          key={provider}
                          onClick={() => setSettings({ ...settings, image_ai_provider: provider })}
                          className={`p-4 rounded-lg border transition-all ${
                            settings.image_ai_provider === provider
                              ? 'bg-pink-500/10 border-pink-500/50 ring-1 ring-pink-500/30'
                              : 'bg-zinc-800/50 border-white/5 hover:border-white/10'
                          }`}
                        >
                          <p className="text-sm font-medium text-white capitalize">{provider}</p>
                          <p className="text-xs text-zinc-500 mt-1">
                            {provider === 'openai' && 'DALL-E 3'}
                            {provider === 'gemini' && 'Imagen 2'}
                          </p>
                        </button>
                      ))}
                    </div>
                    <p className="text-xs text-zinc-600">Uses the same API key from Article AI settings</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Settings Tab */}
          <TabsContent value="content" className="space-y-6">
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-cyan-500/10 border border-cyan-500/20 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">AI Generation Settings</CardTitle>
                    <CardDescription className="text-zinc-500">Configure AI content generation preferences</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Word Count</Label>
                    <Select value={String(settings.ai_word_count)} onValueChange={(v) => setSettings({ ...settings, ai_word_count: parseInt(v) })}>
                      <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-950 border-white/10">
                        <SelectItem value="500">500 words</SelectItem>
                        <SelectItem value="800">800 words</SelectItem>
                        <SelectItem value="1000">1000 words</SelectItem>
                        <SelectItem value="1500">1500 words</SelectItem>
                        <SelectItem value="2000">2000 words</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Language</Label>
                    <Select value={settings.language} onValueChange={(v) => setSettings({ ...settings, language: v })}>
                      <SelectTrigger className="bg-zinc-900 border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-950 border-white/10">
                        <SelectItem value="id">Bahasa Indonesia</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-lg border border-white/5">
                    <div>
                      <p className="text-sm text-white font-medium">Auto-generate Tags</p>
                      <p className="text-xs text-zinc-500 mt-0.5">AI will suggest relevant tags</p>
                    </div>
                    <Switch checked={settings.auto_generate_tags} onCheckedChange={(checked) => setSettings({ ...settings, auto_generate_tags: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-lg border border-white/5">
                    <div>
                      <p className="text-sm text-white font-medium">Auto-generate Categories</p>
                      <p className="text-xs text-zinc-500 mt-0.5">AI will suggest relevant categories</p>
                    </div>
                    <Switch checked={settings.auto_generate_categories} onCheckedChange={(checked) => setSettings({ ...settings, auto_generate_categories: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-zinc-800/30 rounded-lg border border-white/5">
                    <div>
                      <p className="text-sm text-white font-medium">Auto-generate SEO</p>
                      <p className="text-xs text-zinc-500 mt-0.5">Generate meta description & focus keyword</p>
                    </div>
                    <Switch checked={settings.auto_generate_seo} onCheckedChange={(checked) => setSettings({ ...settings, auto_generate_seo: checked })} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Custom Prompt Card */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-center">
                    <MessageSquareText className="w-5 h-5 text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-white">Custom Prompt</CardTitle>
                    <CardDescription className="text-zinc-500">Use your own prompt template for AI</CardDescription>
                  </div>
                  <Switch 
                    checked={settings.custom_prompt_enabled} 
                    onCheckedChange={(checked) => setSettings({ ...settings, custom_prompt_enabled: checked })} 
                  />
                </div>
              </CardHeader>
              {settings.custom_prompt_enabled && (
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Prompt Template</Label>
                    <Textarea
                      value={settings.custom_prompt}
                      onChange={(e) => setSettings({ ...settings, custom_prompt: e.target.value })}
                      placeholder="Write a comprehensive blog post about: {title}&#10;&#10;Requirements:&#10;- Write in {language}&#10;- Minimum {word_count} words&#10;- Use HTML formatting&#10;- Include introduction and conclusion"
                      className="bg-zinc-900 border-white/10 text-white min-h-[180px] font-mono text-sm leading-relaxed"
                    />
                    <div className="p-3 bg-zinc-800/50 rounded-lg border border-white/5">
                      <p className="text-xs text-zinc-400 font-medium mb-2">Available Variables:</p>
                      <div className="flex flex-wrap gap-2">
                        <code className="text-xs bg-orange-500/10 text-orange-400 px-2 py-0.5 rounded">{'{title}'}</code>
                        <code className="text-xs bg-orange-500/10 text-orange-400 px-2 py-0.5 rounded">{'{language}'}</code>
                        <code className="text-xs bg-orange-500/10 text-orange-400 px-2 py-0.5 rounded">{'{word_count}'}</code>
                        <code className="text-xs bg-orange-500/10 text-orange-400 px-2 py-0.5 rounded">{'{categories}'}</code>
                        <code className="text-xs bg-orange-500/10 text-orange-400 px-2 py-0.5 rounded">{'{tags}'}</code>
                      </div>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>

            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">Default Post Settings</CardTitle>
                    <CardDescription className="text-zinc-500">Default values for new posts</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Default Status</Label>
                  <Select value={settings.default_post_status} onValueChange={(v) => setSettings({ ...settings, default_post_status: v })}>
                    <SelectTrigger className="bg-zinc-900 border-white/10 text-white w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-white/10">
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="publish">Published</SelectItem>
                      <SelectItem value="pending">Pending Review</SelectItem>
                      <SelectItem value="private">Private</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cache Tab */}
          <TabsContent value="cache" className="space-y-6">
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center justify-center">
                    <Database className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <CardTitle className="text-white">{t('cacheManagement')}</CardTitle>
                    <CardDescription className="text-zinc-500">
                      {t('cacheManagementDesc')}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Cache Stats */}
                <div className="p-4 bg-zinc-800/50 rounded-lg border border-white/5">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm text-white font-medium">{t('cachedItems')}</p>
                      <p className="text-2xl font-bold text-emerald-400">{cacheStats?.total_items || 0}</p>
                    </div>
                    <Button
                      onClick={fetchCacheStats}
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-zinc-400 hover:text-white"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  {cacheStats?.items && cacheStats.items.length > 0 && (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {cacheStats.items.map((item, i) => (
                        <div key={i} className="flex items-center justify-between text-xs p-2 bg-zinc-900/50 rounded">
                          <span className="text-zinc-400 font-mono truncate flex-1">{item.key}</span>
                          <span className={`ml-2 px-2 py-0.5 rounded ${
                            item.expires_in > 3600 ? 'bg-emerald-500/20 text-emerald-400' :
                            item.expires_in > 0 ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {item.expires_in > 3600 ? `${Math.round(item.expires_in/3600)}h` :
                             item.expires_in > 60 ? `${Math.round(item.expires_in/60)}m` :
                             item.expires_in > 0 ? `${item.expires_in}s` : t('expired')}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Cache TTL Info */}
                <div className="p-4 bg-zinc-800/30 rounded-lg">
                  <p className="text-sm text-white font-medium mb-2">{t('cacheDuration')}</p>
                  <p className="text-xs text-zinc-400">{t('cacheDurationDesc')}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 font-mono font-bold">24 {t('hours')}</span>
                  </div>
                </div>

                {/* Clear Cache Button */}
                <div className="pt-4 border-t border-white/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white font-medium">{t('clearAllCache')}</p>
                      <p className="text-xs text-zinc-500">{t('clearAllCacheDesc')}</p>
                    </div>
                    <Button
                      onClick={handleClearCache}
                      disabled={clearingCache}
                      variant="destructive"
                      className="bg-red-600 hover:bg-red-500"
                    >
                      {clearingCache ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4 mr-2" />
                      )}
                      {t('clearCache')}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Limits Tab (Superadmin Only) */}
          {isSuperadmin && (
            <TabsContent value="limits" className="space-y-6">
              {/* Usage Overview */}
              {limitsUsage && (
                <Card className="bg-zinc-900/50 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Gauge className="w-5 h-5 text-cyan-400" />
                      Current Usage
                    </CardTitle>
                    <CardDescription className="text-zinc-500">
                      Resource usage against configured limits
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="p-4 bg-zinc-800/50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Globe className="w-4 h-4 text-blue-400" />
                          <span className="text-xs text-zinc-500 uppercase">Domains</span>
                        </div>
                        <p className="text-2xl font-bold text-white">
                          {limitsUsage.usage.domains}<span className="text-sm text-zinc-500">/{limits.max_domains < 0 ? '∞' : limits.max_domains}</span>
                        </p>
                      </div>
                      <div className="p-4 bg-zinc-800/50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Users className="w-4 h-4 text-green-400" />
                          <span className="text-xs text-zinc-500 uppercase">Team</span>
                        </div>
                        <p className="text-2xl font-bold text-white">
                          {limitsUsage.usage.team_members}<span className="text-sm text-zinc-500">/{limits.max_team_members < 0 ? '∞' : limits.max_team_members}</span>
                        </p>
                      </div>
                      <div className="p-4 bg-zinc-800/50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <FileText className="w-4 h-4 text-violet-400" />
                          <span className="text-xs text-zinc-500 uppercase">Posts Today</span>
                        </div>
                        <p className="text-2xl font-bold text-white">
                          {limitsUsage.usage.posts_today}<span className="text-sm text-zinc-500">/{limits.max_posts_per_day < 0 ? '∞' : limits.max_posts_per_day}</span>
                        </p>
                      </div>
                      <div className="p-4 bg-zinc-800/50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Zap className="w-4 h-4 text-amber-400" />
                          <span className="text-xs text-zinc-500 uppercase">AI Requests</span>
                        </div>
                        <p className="text-2xl font-bold text-white">
                          {limitsUsage.usage.ai_requests_today}<span className="text-sm text-zinc-500">/{limits.max_ai_requests_per_day < 0 ? '∞' : limits.max_ai_requests_per_day}</span>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Limits Configuration */}
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="w-5 h-5 text-indigo-400" />
                    Limit Configuration
                  </CardTitle>
                  <CardDescription className="text-zinc-500">
                    Set maximum limits for the application. Use -1 for unlimited.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Legend */}
                  <div className="p-3 bg-zinc-800/30 rounded-lg text-xs text-zinc-500">
                    <span className="font-medium text-zinc-400">Nilai:</span> -1 = Unlimited (∞), 0 = Disabled, &gt;0 = Limit aktif
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    {/* Max Domains */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Globe className="w-4 h-4" />
                        Max Domains
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="1000"
                        value={limits.max_domains}
                        onChange={(e) => setLimits({ ...limits, max_domains: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Maksimal WordPress site yang bisa di-manage</p>
                    </div>

                    {/* Max Team Members */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Max Team Members
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={limits.max_team_members}
                        onChange={(e) => setLimits({ ...limits, max_team_members: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Maksimal user (tidak termasuk superadmin)</p>
                    </div>

                    {/* Max Bulk Titles */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        Max Bulk Titles
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={limits.max_bulk_titles}
                        onChange={(e) => setLimits({ ...limits, max_bulk_titles: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Maksimal judul per bulk auto-post</p>
                    </div>

                    {/* Max Concurrent Domains */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Network className="w-4 h-4" />
                        Max Concurrent Domains
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="20"
                        value={limits.max_concurrent_domains}
                        onChange={(e) => setLimits({ ...limits, max_concurrent_domains: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Maksimal domain yang diproses bersamaan</p>
                    </div>

                    {/* Delay Between Posts */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Delay Between Posts (seconds)
                      </Label>
                      <Input
                        type="number"
                        min="0"
                        max="60"
                        value={limits.delay_between_posts}
                        onChange={(e) => setLimits({ ...limits, delay_between_posts: parseInt(e.target.value) || 0 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Jeda antar post untuk menghindari spam</p>
                    </div>

                    {/* Max Posts Per Day */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Sparkles className="w-4 h-4" />
                        Max Posts Per Day
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="1000"
                        value={limits.max_posts_per_day}
                        onChange={(e) => setLimits({ ...limits, max_posts_per_day: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Batas auto-post per hari</p>
                    </div>

                    {/* Max AI Requests Per Day */}
                    <div className="space-y-2 col-span-2">
                      <Label className="text-zinc-400 flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Max AI Requests Per Day
                      </Label>
                      <Input
                        type="number"
                        min="1"
                        max="10000"
                        value={limits.max_ai_requests_per_day}
                        onChange={(e) => setLimits({ ...limits, max_ai_requests_per_day: parseInt(e.target.value) || 1 })}
                        className="bg-zinc-900 border-white/10 text-white"
                      />
                      <p className="text-xs text-zinc-600">Batas request ke AI API per hari (untuk kontrol biaya)</p>
                    </div>
                  </div>

                  <div className="flex justify-end pt-4 border-t border-white/5">
                    <Button onClick={handleSaveLimits} disabled={savingLimits} className="bg-indigo-600 hover:bg-indigo-500">
                      {savingLimits ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                      Save Limits
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Security Tab (Superadmin Only) */}
          {isSuperadmin && (
            <TabsContent value="security" className="space-y-6">
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center justify-center">
                      <Shield className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <CardTitle className="text-white">IP Whitelist</CardTitle>
                      <CardDescription className="text-zinc-500">
                        Manage whitelisted IP addresses for security
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New IP */}
                  <div className="p-4 bg-zinc-800/50 rounded-lg border border-white/5">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono mb-3 block">
                      Add New IP Address
                    </Label>
                    <div className="flex gap-3">
                      <div className="flex-1">
                        <Input
                          placeholder="192.168.1.1 or 10.0.0.0/24"
                          value={newIpAddress}
                          onChange={(e) => setNewIpAddress(e.target.value)}
                          className="bg-zinc-900 border-white/10 text-white font-mono"
                        />
                      </div>
                      <div className="flex-1">
                        <Input
                          placeholder="Description (optional)"
                          value={newIpDescription}
                          onChange={(e) => setNewIpDescription(e.target.value)}
                          className="bg-zinc-900 border-white/10 text-white"
                        />
                      </div>
                      <Button
                        onClick={handleAddIp}
                        disabled={addingIp || !newIpAddress.trim()}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white"
                      >
                        {addingIp ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Plus className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* IP List */}
                  <div className="space-y-3">
                    <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">
                      Whitelisted IPs ({ipWhitelist.length})
                    </Label>
                    
                    {ipWhitelist.length === 0 ? (
                      <div className="p-8 bg-zinc-800/30 rounded-lg border border-white/5 text-center">
                        <Network className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
                        <p className="text-zinc-500 text-sm">No IP addresses whitelisted</p>
                        <p className="text-zinc-600 text-xs mt-1">Add IP addresses above to enable whitelisting</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-80 overflow-y-auto">
                        {ipWhitelist.map((ip) => (
                          <div
                            key={ip.id}
                            className="flex items-center justify-between p-3 bg-zinc-800/30 rounded-lg border border-white/5 group hover:border-white/10 transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                                <Network className="w-4 h-4 text-emerald-400" />
                              </div>
                              <div>
                                <p className="text-sm text-white font-mono">{ip.ip_address}</p>
                                <p className="text-xs text-zinc-500">
                                  {ip.description || 'No description'} • Added by {ip.added_by_name}
                                </p>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteIp(ip.id, ip.ip_address)}
                              className="text-zinc-500 hover:text-red-400 hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Info Box */}
                  <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-lg">
                    <p className="text-xs text-amber-400">
                      <strong>Note:</strong> IP whitelisting is for security purposes. Only whitelisted IPs will have access when enabled.
                      Use CIDR notation (e.g., 192.168.1.0/24) to whitelist IP ranges.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Activity Logs Tab (Superadmin Only) */}
          {isSuperadmin && (
            <TabsContent value="logs" className="space-y-6">
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-center">
                        <ScrollText className="w-5 h-5 text-orange-400" />
                      </div>
                      <div>
                        <CardTitle className="text-white">Activity Logs</CardTitle>
                        <CardDescription className="text-zinc-500">
                          View all user activities ({logsTotal} total)
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={fetchActivityLogs}
                        variant="outline"
                        size="sm"
                        disabled={loadingLogs}
                        className="border-white/10 text-zinc-400 hover:text-white"
                      >
                        <RefreshCw className={`w-4 h-4 ${loadingLogs ? 'animate-spin' : ''}`} />
                      </Button>
                      <Button
                        onClick={handleClearLogs}
                        variant="destructive"
                        size="sm"
                        disabled={clearingLogs || activityLogs.length === 0}
                        className="bg-red-600 hover:bg-red-500"
                      >
                        {clearingLogs ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {loadingLogs ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
                    </div>
                  ) : activityLogs.length === 0 ? (
                    <div className="p-8 bg-zinc-800/30 rounded-lg border border-white/5 text-center">
                      <ScrollText className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
                      <p className="text-zinc-500 text-sm">No activity logs yet</p>
                      <p className="text-zinc-600 text-xs mt-1">User activities will appear here</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {activityLogs.map((log) => (
                        <div
                          key={log.id}
                          className="flex items-start gap-3 p-3 bg-zinc-800/30 rounded-lg border border-white/5"
                        >
                          <div className="w-8 h-8 bg-zinc-700/50 rounded-full flex items-center justify-center flex-shrink-0">
                            <User className="w-4 h-4 text-zinc-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm text-white font-medium">{log.user_name}</span>
                              <span className="text-xs text-zinc-500">{log.user_email}</span>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${getActionColor(log.action)}`}>
                                {log.action}
                              </span>
                            </div>
                            <p className="text-sm text-zinc-400 mt-1 truncate">{log.details}</p>
                            <div className="flex items-center gap-3 mt-1 text-xs text-zinc-600">
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(log.created_at).toLocaleString('id-ID')}
                              </span>
                              {log.ip_address && (
                                <span className="flex items-center gap-1">
                                  <Network className="w-3 h-3" />
                                  {log.ip_address}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Subscription Due Date Tab (Superadmin Only) */}
          {isSuperadmin && (
            <TabsContent value="subscription" className="space-y-6">
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <CardTitle className="text-white">Subscription Due Date</CardTitle>
                      <CardDescription>
                        Set tanggal jatuh tempo langganan. Setelah tanggal ini, admin dan staff tidak bisa menggunakan fitur apapun.
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Current Status */}
                  {subscriptionStatus && (
                    <div className={`p-4 rounded-lg border ${
                      subscriptionStatus.status === 'expired' 
                        ? 'bg-red-500/10 border-red-500/30' 
                        : subscriptionStatus.status === 'warning'
                        ? 'bg-amber-500/10 border-amber-500/30'
                        : 'bg-emerald-500/10 border-emerald-500/30'
                    }`}>
                      <div className="flex items-center gap-2">
                        {subscriptionStatus.status === 'expired' && (
                          <AlertTriangle className="w-5 h-5 text-red-400" />
                        )}
                        {subscriptionStatus.status === 'warning' && (
                          <AlertTriangle className="w-5 h-5 text-amber-400" />
                        )}
                        {subscriptionStatus.status === 'active' && (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        )}
                        <span className={`font-medium ${
                          subscriptionStatus.status === 'expired' 
                            ? 'text-red-400' 
                            : subscriptionStatus.status === 'warning'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}>
                          Status: {subscriptionStatus.status === 'expired' ? 'EXPIRED' : 
                                   subscriptionStatus.status === 'warning' ? 'WARNING' : 'ACTIVE'}
                        </span>
                      </div>
                      {subscriptionStatus.days_remaining !== null && (
                        <p className="text-sm text-zinc-400 mt-2">
                          {subscriptionStatus.days_remaining >= 0 
                            ? `${subscriptionStatus.days_remaining} hari tersisa` 
                            : `Expired ${Math.abs(subscriptionStatus.days_remaining)} hari yang lalu`}
                        </p>
                      )}
                      {!subscriptionStatus.due_date && (
                        <p className="text-sm text-zinc-400 mt-2">
                          Tidak ada due date (unlimited)
                        </p>
                      )}
                    </div>
                  )}

                  {/* Due Date Input */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-zinc-300">Due Date</Label>
                      <div className="flex gap-2">
                        <Input
                          type="date"
                          value={subscriptionDueDate}
                          onChange={(e) => setSubscriptionDueDate(e.target.value)}
                          className="bg-zinc-800 border-zinc-700 text-white flex-1"
                        />
                        <Button
                          onClick={handleClearDueDate}
                          variant="outline"
                          className="border-zinc-700 text-zinc-400 hover:text-white"
                          disabled={savingSubscription || !subscriptionDueDate}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-zinc-500">
                        Kosongkan untuk unlimited (tidak ada jatuh tempo)
                      </p>
                    </div>

                    <Button
                      onClick={handleSaveSubscription}
                      disabled={savingSubscription}
                      className="bg-amber-600 hover:bg-amber-500 text-white"
                    >
                      {savingSubscription ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4 mr-2" />
                      )}
                      Save Due Date
                    </Button>
                  </div>

                  {/* Info */}
                  <div className="p-4 bg-zinc-800/50 rounded-lg border border-zinc-700">
                    <h4 className="font-medium text-zinc-300 mb-2">Bagaimana ini bekerja?</h4>
                    <ul className="text-sm text-zinc-400 space-y-1 list-disc list-inside">
                      <li><span className="text-amber-400">H-7</span>: Admin/Staff melihat warning banner dan popup (1x/hari)</li>
                      <li><span className="text-red-400">Expired</span>: Semua fitur disabled untuk admin/staff</li>
                      <li><span className="text-emerald-400">Superadmin</span> tidak terpengaruh dan bisa update due date kapanpun</li>
                      <li>Admin/Staff tidak bisa melihat tab ini</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>

        {/* Save Button */}
        {canEditSettings && (
          <div className="flex justify-end pt-6">
            <Button onClick={handleSave} disabled={saving} className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-8 h-11">
              {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Save Settings
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
