import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Globe } from 'lucide-react';

export function LanguageSwitcher() {
  const { language, toggleLanguage } = useLanguage();
  
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleLanguage}
      className="flex items-center gap-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 px-2"
    >
      <Globe className="w-4 h-4" />
      <span className="font-medium text-xs">
        {language === 'en' ? 'EN' : 'ID'}
      </span>
    </Button>
  );
}
