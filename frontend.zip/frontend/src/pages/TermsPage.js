import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from '../components/LanguageSwitcher';
import Logo from '../components/Logo';
import { ArrowLeft, Scale } from 'lucide-react';

export default function TermsPage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/docs">{t('legalDocsTitle')}</Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <Link to="/fair-use">{t('legalFairUseTitle')}</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center">
            <Scale className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">{t('termsTitle')}</h1>
            <p className="text-zinc-400">{t('termsLastUpdated')}</p>
          </div>
        </div>

        <div className="prose prose-invert prose-zinc max-w-none">
          <div className="space-y-8 text-zinc-300 text-sm leading-relaxed">
            
            {/* Preamble */}
            <section className="p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg">
              <p className="text-zinc-400 italic">
                {t('termsPreamble')}
              </p>
            </section>

            {/* Section 1 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS1Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">1.1</strong> {t('termsS1P1')}</p>
                <p><strong className="text-white">1.2</strong> {t('termsS1P2')}</p>
                <p><strong className="text-white">1.3</strong> {t('termsS1P3')}</p>
                <p><strong className="text-white">1.4</strong> {t('termsS1P4')}</p>
                <p><strong className="text-white">1.5</strong> {t('termsS1P5')}</p>
              </div>
            </section>

            {/* Section 2 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS2Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">2.1</strong> {t('termsS2P1')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS2L1')}</li>
                  <li>{t('termsS2L2')}</li>
                  <li>{t('termsS2L3')}</li>
                  <li>{t('termsS2L4')}</li>
                  <li>{t('termsS2L5')}</li>
                </ul>
                <p><strong className="text-white">2.2</strong> {t('termsS2P2')}</p>
              </div>
            </section>

            {/* Section 3 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS3Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">3.1</strong> {t('termsS3P1')}</p>
                <p><strong className="text-white">3.2</strong> {t('termsS3P2')}</p>
                <p><strong className="text-white">3.3</strong> {t('termsS3P3')}</p>
                <p><strong className="text-white">3.4</strong> {t('termsS3P4')}</p>
              </div>
            </section>

            {/* Section 4 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS4Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">4.1</strong> {t('termsS4P1')}</p>
                <p><strong className="text-white">4.2</strong> {t('termsS4P2')}</p>
                <p><strong className="text-white">4.3</strong> {t('termsS4P3')}</p>
                <p><strong className="text-white">4.4</strong> {t('termsS4P4')}</p>
              </div>
            </section>

            {/* Section 5 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS5Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">5.1</strong> {t('termsS5P1')}</p>
                <p><strong className="text-white">5.2</strong> {t('termsS5P2')}</p>
                <p><strong className="text-white">5.3</strong> {t('termsS5P3')}</p>
                <p><strong className="text-white">5.4</strong> {t('termsS5P4')}</p>
              </div>
            </section>

            {/* Section 6 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS6Title')}</h2>
              <div className="space-y-2">
                <p>{t('termsS6Intro')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS6L1')}</li>
                  <li>{t('termsS6L2')}</li>
                  <li>{t('termsS6L3')}</li>
                  <li>{t('termsS6L4')}</li>
                  <li>{t('termsS6L5')}</li>
                  <li>{t('termsS6L6')}</li>
                  <li>{t('termsS6L7')}</li>
                  <li>{t('termsS6L8')}</li>
                  <li>{t('termsS6L9')}</li>
                </ul>
              </div>
            </section>

            {/* Section 7 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS7Title')}</h2>
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg mb-4">
                <p className="text-red-300 font-medium">{t('termsS7Important')}</p>
              </div>
              <div className="space-y-2">
                <p><strong className="text-white">7.1</strong> {t('termsS7P1')}</p>
                
                <p><strong className="text-white">7.2</strong> {t('termsS7P2')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS7L1')}</li>
                  <li>{t('termsS7L2')}</li>
                  <li>{t('termsS7L3')}</li>
                  <li>{t('termsS7L4')}</li>
                </ul>

                <p><strong className="text-white">7.3</strong> {t('termsS7P3')}</p>
                <p><strong className="text-white">7.4</strong> {t('termsS7P4')}</p>
                <p><strong className="text-white">7.5</strong> {t('termsS7P5')}</p>

                <p><strong className="text-white">7.6</strong> {t('termsS7P6')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS7L5')}</li>
                  <li>{t('termsS7L6')}</li>
                  <li>{t('termsS7L7')}</li>
                  <li>{t('termsS7L8')}</li>
                  <li>{t('termsS7L9')}</li>
                  <li>{t('termsS7L10')}</li>
                </ul>

                <p><strong className="text-white">7.7</strong> {t('termsS7P7')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS7L11')}</li>
                  <li>{t('termsS7L12')}</li>
                  <li>{t('termsS7L13')}</li>
                  <li>{t('termsS7L14')}</li>
                  <li>{t('termsS7L15')}</li>
                  <li>{t('termsS7L16')}</li>
                </ul>
              </div>
            </section>

            {/* Section 8 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS8Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">8.1</strong> {t('termsS8P1')}</p>
                <p><strong className="text-white">8.2</strong> {t('termsS8P2')}</p>
                <p><strong className="text-white">8.3</strong> {t('termsS8P3')}</p>
              </div>
            </section>

            {/* Section 9 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS9Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">9.1</strong> {t('termsS9P1')}</p>
                <p><strong className="text-white">9.2</strong> {t('termsS9P2')}</p>
                <p><strong className="text-white">9.3</strong> {t('termsS9P3')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS9L1')}</li>
                  <li>{t('termsS9L2')}</li>
                  <li>{t('termsS9L3')}</li>
                  <li>{t('termsS9L4')}</li>
                </ul>
                <p><strong className="text-white">9.4</strong> {t('termsS9P4')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS9L5')}</li>
                  <li>{t('termsS9L6')}</li>
                  <li>{t('termsS9L7')}</li>
                  <li>{t('termsS9L8')}</li>
                  <li>{t('termsS9L9')}</li>
                  <li>{t('termsS9L10')}</li>
                  <li>{t('termsS9L11')}</li>
                </ul>
                <p><strong className="text-white">9.5</strong> {t('termsS9P5')}</p>
              </div>
            </section>

            {/* Section 10 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS10Title')}</h2>
              <div className="space-y-2">
                <p>{t('termsS10Intro')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS10L1')}</li>
                  <li>{t('termsS10L2')}</li>
                  <li>{t('termsS10L3')}</li>
                  <li>{t('termsS10L4')}</li>
                </ul>
              </div>
            </section>

            {/* Section 11 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS11Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">11.1</strong> {t('termsS11P1')}</p>
                <p><strong className="text-white">11.2</strong> {t('termsS11P2')}</p>
                <ul className="list-disc list-inside ml-4 text-zinc-400 space-y-1">
                  <li>{t('termsS11L1')}</li>
                  <li>{t('termsS11L2')}</li>
                  <li>{t('termsS11L3')}</li>
                </ul>
                <p><strong className="text-white">11.3</strong> {t('termsS11P3')}</p>
              </div>
            </section>

            {/* Section 12 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS12Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">12.1</strong> {t('termsS12P1')}</p>
                <p><strong className="text-white">12.2</strong> {t('termsS12P2')}</p>
                <p><strong className="text-white">12.3</strong> {t('termsS12P3')}</p>
              </div>
            </section>

            {/* Section 13 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS13Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">13.1</strong> {t('termsS13P1')}</p>
                <p><strong className="text-white">13.2</strong> {t('termsS13P2')}</p>
              </div>
            </section>

            {/* Section 14 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS14Title')}</h2>
              <div className="space-y-2">
                <p><strong className="text-white">14.1</strong> {t('termsS14P1')}</p>
                <p><strong className="text-white">14.2</strong> {t('termsS14P2')}</p>
                <p><strong className="text-white">14.3</strong> {t('termsS14P3')}</p>
                <p><strong className="text-white">14.4</strong> {t('termsS14P4')}</p>
              </div>
            </section>

            {/* Section 15 */}
            <section>
              <h2 className="text-xl font-bold text-white mb-4">{t('termsS15Title')}</h2>
              <div className="space-y-2">
                <p>{t('termsS15Intro')}</p>
                <div className="p-4 bg-zinc-800/50 rounded-lg mt-2">
                  <p className="text-zinc-400">Email: support@wpmtools.com</p>
                </div>
              </div>
            </section>

            {/* Acceptance */}
            <section className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-blue-300">
                <strong>{t('termsAcceptance')}</strong>
              </p>
            </section>

          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-zinc-500">
          <div className="flex justify-center gap-6 mb-4">
            <Link to="/docs" className="hover:text-white">{t('legalDocsTitle')}</Link>
            <Link to="/terms" className="hover:text-white">{t('legalTermsTitle')}</Link>
            <Link to="/fair-use" className="hover:text-white">{t('legalFairUseTitle')}</Link>
          </div>
          <p>© 2024 WPMTools. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
