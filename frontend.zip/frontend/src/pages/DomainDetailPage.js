import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { domainsApi, postsApi, pagesApi, tagsApi, usersApi, cacheApi, widgetsApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Checkbox } from '../components/ui/checkbox';
import {
  ArrowLeft, CheckCircle2, XCircle, RefreshCw,
  FileText, File, Tag, Users, Plus, Edit, Trash2, Loader2,
  ExternalLink, LogOut, Zap, LayoutGrid, GripVertical, Settings,
  Search, Filter, X
} from 'lucide-react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import Logo from '../components/Logo';

export default function DomainDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [domain, setDomain] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState(false);
  const [purging, setPurging] = useState(false);
  const [activeTab, setActiveTab] = useState('posts');

  useEffect(() => {
    fetchInitialData();
  }, [id]);

  // OPTIMIZED: Fetch domain and stats in PARALLEL
  const fetchInitialData = async () => {
    try {
      const [domainRes, statsRes] = await Promise.all([
        domainsApi.get(id),
        domainsApi.stats(id).catch(() => ({ data: null }))
      ]);
      
      setDomain(domainRes.data);
      if (statsRes.data) setStats(statsRes.data);
    } catch (error) {
      toast.error('Failed to load domain');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const fetchDomain = async () => {
    try {
      const response = await domainsApi.get(id);
      setDomain(response.data);
    } catch (error) {
      toast.error('Failed to load domain');
    }
  };

  const fetchStats = async () => {
    try {
      const response = await domainsApi.stats(id);
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    try {
      const response = await domainsApi.test(id);
      if (response.data.success) {
        toast.success('Connection successful!');
        fetchDomain();
        fetchStats();
      } else {
        toast.error(response.data.message || 'Connection failed');
      }
    } catch (error) {
      toast.error('Connection test failed');
    } finally {
      setTesting(false);
    }
  };

  const handlePurgeCache = async () => {
    setPurging(true);
    try {
      // Add slight delay for better UX feedback
      await new Promise(resolve => setTimeout(resolve, 800));
      const response = await cacheApi.purge(id);
      if (response.data.success) {
        toast.success('Cache refreshed successfully!', {
          description: 'All cached pages have been updated'
        });
      }
    } catch (error) {
      toast.error('Failed to refresh cache');
    } finally {
      setPurging(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-500 spinner" />
      </div>
    );
  }

  if (!domain) return null;

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400">{user?.name}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                data-testid="logout-btn"
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Domain Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className={`w-3 h-3 rounded-full ${domain.is_connected ? 'status-connected' : 'status-disconnected'}`} />
              <h1 className="text-3xl font-bold text-white" data-testid="domain-title">{domain.name}</h1>
            </div>
            <a
              href={domain.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-zinc-400 hover:text-indigo-400 flex items-center gap-2 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              {domain.url}
            </a>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handlePurgeCache}
              disabled={purging}
              data-testid="purge-cache-btn"
              className="bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30"
            >
              {purging ? (
                <Loader2 className="w-4 h-4 mr-2 spinner" />
              ) : (
                <Zap className="w-4 h-4 mr-2" />
              )}
              Purge Cache
            </Button>
            <Button
              onClick={handleTest}
              disabled={testing}
              data-testid="test-connection-btn"
              className="bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700"
            >
              {testing ? (
                <Loader2 className="w-4 h-4 mr-2 spinner" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Test Connection
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <StatCard icon={<FileText className="w-5 h-5" />} label="Posts" value={stats?.posts_count ?? '-'} testId="stat-posts" />
          <StatCard icon={<File className="w-5 h-5" />} label="Pages" value={stats?.pages_count ?? '-'} testId="stat-pages" />
          <StatCard icon={<Users className="w-5 h-5" />} label="Users" value={stats?.users_count ?? '-'} testId="stat-users" />
          <StatCard icon={<Tag className="w-5 h-5" />} label="Tags" value={stats?.tags_count ?? '-'} testId="stat-tags" />
          <StatCard icon={<Tag className="w-5 h-5" />} label="Categories" value={stats?.categories_count ?? '-'} testId="stat-categories" />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
            <TabsTrigger
              value="posts"
              data-testid="tab-posts"
              className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white text-zinc-400"
            >
              <FileText className="w-4 h-4 mr-2" />
              Posts
            </TabsTrigger>
            <TabsTrigger
              value="pages"
              data-testid="tab-pages"
              className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white text-zinc-400"
            >
              <File className="w-4 h-4 mr-2" />
              Pages
            </TabsTrigger>
            <TabsTrigger
              value="tags"
              data-testid="tab-tags"
              className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white text-zinc-400"
            >
              <Tag className="w-4 h-4 mr-2" />
              Tags
            </TabsTrigger>
            <TabsTrigger
              value="users"
              data-testid="tab-users"
              className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white text-zinc-400"
            >
              <Users className="w-4 h-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger
              value="widgets"
              data-testid="tab-widgets"
              className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white text-zinc-400"
            >
              <LayoutGrid className="w-4 h-4 mr-2" />
              Widgets
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts">
            <PostsTab domainId={id} />
          </TabsContent>
          <TabsContent value="pages">
            <PagesTab domainId={id} />
          </TabsContent>
          <TabsContent value="tags">
            <TagsTab domainId={id} />
          </TabsContent>
          <TabsContent value="users">
            <UsersTab domainId={id} />
          </TabsContent>
          <TabsContent value="widgets">
            <WidgetsTab domainId={id} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function StatCard({ icon, label, value, testId }) {
  return (
    <Card className="bg-zinc-900/50 border-zinc-800" data-testid={testId}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center text-indigo-400">
            {icon}
          </div>
          <div>
            <p className="text-sm text-zinc-400">{label}</p>
            <p className="text-xl font-bold text-white">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ==================== POSTS TAB ====================
function PostsTab({ domainId }) {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const PER_PAGE = 20;

  useEffect(() => {
    // Reset and fetch when domainId changes
    setPosts([]);
    setPage(1);
    setHasMore(true);
    fetchPosts(1, true);
  }, [domainId]);

  const fetchPosts = async (pageNum = page, reset = false) => {
    if (reset) {
      setLoading(true);
    } else {
      setLoadingMore(true);
    }
    
    try {
      const response = await postsApi.list(domainId, pageNum, PER_PAGE);
      const newItems = response.data.items || [];
      const totalItems = response.data.total || 0;
      
      if (reset) {
        setPosts(newItems);
      } else {
        setPosts(prev => [...prev, ...newItems]);
      }
      
      setTotal(totalItems);
      setHasMore(pageNum * PER_PAGE < totalItems);
      setSelectedIds([]);
    } catch (error) {
      toast.error('Failed to load posts');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchPosts(nextPage, false);
  };

  const refresh = () => {
    setPosts([]);
    setPage(1);
    setHasMore(true);
    fetchPosts(1, true);
  };

  const handleDelete = async (postId) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await postsApi.delete(domainId, postId, true);
      toast.success('Post deleted');
      refresh();
    } catch (error) {
      toast.error('Failed to delete post');
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedIds.length} posts?`)) return;
    
    setBulkDeleting(true);
    try {
      const response = await postsApi.bulkDelete(domainId, selectedIds);
      toast.success(`${response.data.total_deleted} posts deleted`);
      refresh();
    } catch (error) {
      toast.error('Failed to delete posts');
    } finally {
      setBulkDeleting(false);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredPosts.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredPosts.map(p => p.id));
    }
  };

  const toggleSelect = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const filteredPosts = posts.filter(post => {
    const title = post.title?.rendered || post.title || '';
    const matchesSearch = title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || post.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const loadedCount = posts.length;

  return (
    <div className="space-y-6">
      {/* Control Room Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/20 rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 tracking-tight font-[Chivo]">Posts Control</h2>
            <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Content Management</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-zinc-950 border border-white/10 rounded-lg">
            <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Loaded:</span>
            <span className="text-sm text-emerald-400 font-mono font-bold">{loadedCount} / {total}</span>
          </div>
          <Button 
            onClick={() => navigate(`/domains/${domainId}/posts/new`)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 h-10 transition-all duration-200 hover:-translate-y-0.5" 
            data-testid="add-posts-btn"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Post
          </Button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Search posts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-zinc-900 border-white/10 text-white"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 bg-zinc-900 border-white/10 text-white">
            <Filter className="w-4 h-4 mr-2 text-zinc-500" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="publish">Published</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="private">Private</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bulk Actions Bar */}
      {selectedIds.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-red-500/10 border border-red-500/20 rounded-lg animate-in fade-in slide-in-from-top-2">
          <span className="text-sm text-red-400 font-mono">
            {selectedIds.length} item{selectedIds.length > 1 ? 's' : ''} selected
          </span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setSelectedIds([])} className="text-zinc-400 hover:text-white">
              Clear
            </Button>
            <Button 
              size="sm" 
              onClick={handleBulkDelete}
              disabled={bulkDeleting}
              className="bg-red-600 hover:bg-red-500 text-white"
            >
              {bulkDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
              Delete Selected
            </Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-indigo-500 spinner" />
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10">
              <FileText className="w-8 h-8 text-zinc-600" />
            </div>
            <p className="text-zinc-300 font-medium">{searchQuery || statusFilter !== 'all' ? 'No matching posts' : 'No posts found'}</p>
            <p className="text-zinc-500 text-sm mt-1">{searchQuery || statusFilter !== 'all' ? 'Try adjusting your filters' : 'Create your first post to get started'}</p>
          </div>
        </div>
      ) : (
        <div className="space-y-3" data-testid="posts-list">
          {/* Select All */}
          <div className="flex items-center gap-3 px-4 py-2 bg-zinc-900/30 rounded-lg border border-white/5">
            <Checkbox 
              checked={selectedIds.length === filteredPosts.length && filteredPosts.length > 0}
              onCheckedChange={toggleSelectAll}
              className="border-zinc-600"
            />
            <span className="text-xs text-zinc-500 font-mono">Select All ({filteredPosts.length})</span>
          </div>
          {filteredPosts.map((item, index) => (
            <PostItem
              key={item.id}
              item={item}
              index={index}
              domainId={domainId}
              selected={selectedIds.includes(item.id)}
              onSelect={() => toggleSelect(item.id)}
              onDelete={() => handleDelete(item.id)}
            />
          ))}
        </div>
      )}

      {/* Load More Button */}
      {hasMore && !loading && (
        <div className="flex flex-col items-center gap-3 pt-4">
          <Button
            variant="outline"
            onClick={loadMore}
            disabled={loadingMore}
            className="bg-zinc-900 border-white/10 text-white hover:bg-zinc-800 font-mono px-8"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Load More ({total - loadedCount} remaining)
              </>
            )}
          </Button>
          <div className="w-48 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-500 transition-all duration-300"
              style={{ width: `${(loadedCount / total) * 100}%` }}
            />
          </div>
          <p className="text-xs text-zinc-500 font-mono">{loadedCount} of {total} loaded</p>
        </div>
      )}
      
      {!hasMore && posts.length > 0 && (
        <p className="text-center text-xs text-zinc-600 font-mono pt-4">
          All {total} posts loaded
        </p>
      )}
    </div>
  );
}

function PostItem({ item, index, domainId, selected, onSelect, onDelete }) {
  const navigate = useNavigate();
  
  const getStatusStyle = (status) => {
    const styles = {
      publish: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      draft: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
      pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      private: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
    };
    return styles[status] || styles.draft;
  };

  return (
    <div 
      className={`group relative flex items-stretch bg-zinc-900/40 backdrop-blur-md border rounded-lg overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg ${selected ? 'border-indigo-500/50 bg-indigo-500/5' : 'border-white/10 hover:border-indigo-500/30'}`}
      data-testid={`post-item-${item.id}`}
    >
      {/* Checkbox */}
      <div className="flex items-center justify-center w-12 bg-zinc-800/50 border-r border-white/5">
        <Checkbox 
          checked={selected}
          onCheckedChange={onSelect}
          className="border-zinc-600"
        />
      </div>

      {/* Content */}
      <div className="flex-1 p-4 min-w-0">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-zinc-200 truncate" dangerouslySetInnerHTML={{ __html: item.title?.rendered || item.title }} />
            <div className="flex items-center gap-3 mt-2">
              <span className={`text-xs font-mono px-2 py-0.5 rounded-full border ${getStatusStyle(item.status)}`}>
                {item.status}
              </span>
              <span className="text-xs text-zinc-600 font-mono">
                {new Date(item.date || item.modified).toLocaleDateString()}
              </span>
              <span className="text-xs text-zinc-700 font-mono">
                ID: {item.id}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate(`/domains/${domainId}/posts/${item.id}/edit`)} 
              data-testid={`edit-post-${item.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700"
            >
              <Edit className="w-3.5 h-3.5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onDelete} 
              data-testid={`delete-post-${item.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/20"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Old PostForm kept for reference but not used anymore
function PostFormLegacy({ domainId, post, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: post?.title?.rendered || '',
    content: post?.content?.rendered?.replace(/<[^>]*>/g, '') || '',
    status: post?.status || 'draft'
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (post) {
        await postsApi.update(domainId, post.id, formData);
        toast.success('Post updated');
      } else {
        await postsApi.create(domainId, formData);
        toast.success('Post created');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label className="text-zinc-300">Title</Label>
        <Input
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
          data-testid="post-title-input"
          className="bg-zinc-800/50 border-zinc-700 text-white"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-zinc-300">Content</Label>
        <Textarea
          value={formData.content}
          onChange={(e) => setFormData({ ...formData, content: e.target.value })}
          rows={6}
          data-testid="post-content-input"
          className="bg-zinc-800/50 border-zinc-700 text-white"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-zinc-300">Status</Label>
        <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
          <SelectTrigger data-testid="post-status-select" className="bg-zinc-800/50 border-zinc-700 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="publish">Published</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="private">Private</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit" disabled={loading} data-testid="post-submit-btn" className="w-full bg-indigo-500 hover:bg-indigo-600 text-white">
        {loading ? <Loader2 className="w-4 h-4 spinner" /> : post ? 'Update Post' : 'Create Post'}
      </Button>
    </form>
  );
}

// ==================== PAGES TAB ====================
function PagesTab({ domainId }) {
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const PER_PAGE = 20;

  useEffect(() => {
    setPages([]);
    setPage(1);
    setHasMore(true);
    fetchPages(1, true);
  }, [domainId]);

  const fetchPages = async (pageNum = page, reset = false) => {
    if (reset) {
      setLoading(true);
    } else {
      setLoadingMore(true);
    }
    
    try {
      const response = await pagesApi.list(domainId, pageNum, PER_PAGE);
      const newItems = response.data.items || [];
      const totalItems = response.data.total || 0;
      
      if (reset) {
        setPages(newItems);
      } else {
        setPages(prev => [...prev, ...newItems]);
      }
      
      setTotal(totalItems);
      setHasMore(pageNum * PER_PAGE < totalItems);
      setSelectedIds([]);
    } catch (error) {
      toast.error('Failed to load pages');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchPages(nextPage, false);
  };

  const refresh = () => {
    setPages([]);
    setPage(1);
    setHasMore(true);
    fetchPages(1, true);
  };

  const handleDelete = async (pageId) => {
    if (!window.confirm('Are you sure you want to delete this page?')) return;
    try {
      await pagesApi.delete(domainId, pageId, true);
      toast.success('Page deleted');
      refresh();
    } catch (error) {
      toast.error('Failed to delete page');
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedIds.length} pages?`)) return;
    
    setBulkDeleting(true);
    try {
      const response = await pagesApi.bulkDelete(domainId, selectedIds);
      toast.success(`${response.data.total_deleted} pages deleted`);
      refresh();
    } catch (error) {
      toast.error('Failed to delete pages');
    } finally {
      setBulkDeleting(false);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredPages.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredPages.map(p => p.id));
    }
  };

  const toggleSelect = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const filteredPages = pages.filter(p => {
    const title = p.title?.rendered || p.title || '';
    const matchesSearch = title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const loadedCount = pages.length;

  return (
    <div className="space-y-6">
      {/* Control Room Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-cyan-500/10 border border-cyan-500/20 rounded-lg flex items-center justify-center">
            <File className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 tracking-tight font-[Chivo]">Pages Control</h2>
            <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Static Content</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-zinc-950 border border-white/10 rounded-lg">
            <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Loaded:</span>
            <span className="text-sm text-emerald-400 font-mono font-bold">{loadedCount} / {total}</span>
          </div>
          <Dialog open={showDialog || !!editItem} onOpenChange={(open) => {
            if (!open) {
              setShowDialog(false);
              setEditItem(null);
            } else {
              setShowDialog(true);
            }
          }}>
            <DialogTrigger asChild>
              <Button 
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 h-10 transition-all duration-200 hover:-translate-y-0.5" 
                data-testid="add-pages-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Page
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-zinc-950 border border-zinc-800 text-white max-w-lg backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="font-[Chivo] text-xl tracking-tight">
                  {editItem ? 'Edit Page' : 'Add New Page'}
                </DialogTitle>
              </DialogHeader>
              <PageForm
                domainId={domainId}
                page={editItem}
                onSuccess={() => {
                  setShowDialog(false);
                  setEditItem(null);
                  refresh();
                }}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input placeholder="Search pages..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 bg-zinc-900 border-white/10 text-white" />
          {searchQuery && (<button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"><X className="w-4 h-4" /></button>)}
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 bg-zinc-900 border-white/10 text-white"><Filter className="w-4 h-4 mr-2 text-zinc-500" /><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="publish">Published</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="private">Private</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bulk Actions Bar */}
      {selectedIds.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-red-500/10 border border-red-500/20 rounded-lg animate-in fade-in slide-in-from-top-2">
          <span className="text-sm text-red-400 font-mono">{selectedIds.length} item{selectedIds.length > 1 ? 's' : ''} selected</span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setSelectedIds([])} className="text-zinc-400 hover:text-white">Clear</Button>
            <Button size="sm" onClick={handleBulkDelete} disabled={bulkDeleting} className="bg-red-600 hover:bg-red-500 text-white">
              {bulkDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}Delete Selected
            </Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-cyan-500 spinner" />
        </div>
      ) : filteredPages.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10">
              <File className="w-8 h-8 text-zinc-600" />
            </div>
            <p className="text-zinc-300 font-medium">{searchQuery || statusFilter !== 'all' ? 'No matching pages' : 'No pages found'}</p>
            <p className="text-zinc-500 text-sm mt-1">{searchQuery || statusFilter !== 'all' ? 'Try adjusting your filters' : 'Create your first page to get started'}</p>
          </div>
        </div>
      ) : (
        <div className="space-y-3" data-testid="pages-list">
          <div className="flex items-center gap-3 px-4 py-2 bg-zinc-900/30 rounded-lg border border-white/5">
            <Checkbox checked={selectedIds.length === filteredPages.length && filteredPages.length > 0} onCheckedChange={toggleSelectAll} className="border-zinc-600" />
            <span className="text-xs text-zinc-500 font-mono">Select All ({filteredPages.length})</span>
          </div>
          {filteredPages.map((item, index) => (
            <PageItem key={item.id} item={item} index={index} selected={selectedIds.includes(item.id)} onSelect={() => toggleSelect(item.id)} onEdit={() => setEditItem(item)} onDelete={() => handleDelete(item.id)} />
          ))}
        </div>
      )}

      {/* Load More Button */}
      {hasMore && !loading && (
        <div className="flex flex-col items-center gap-3 pt-4">
          <Button
            variant="outline"
            onClick={loadMore}
            disabled={loadingMore}
            className="bg-zinc-900 border-white/10 text-white hover:bg-zinc-800 font-mono px-8"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Load More ({total - loadedCount} remaining)
              </>
            )}
          </Button>
          <div className="w-48 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-cyan-500 transition-all duration-300"
              style={{ width: `${(loadedCount / total) * 100}%` }}
            />
          </div>
          <p className="text-xs text-zinc-500 font-mono">{loadedCount} of {total} loaded</p>
        </div>
      )}
      
      {!hasMore && pages.length > 0 && (
        <p className="text-center text-xs text-zinc-600 font-mono pt-4">
          All {total} pages loaded
        </p>
      )}
    </div>
  );
}

function PageItem({ item, index, selected, onSelect, onEdit, onDelete }) {
  const getStatusStyle = (status) => {
    const styles = {
      publish: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      draft: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
      pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      private: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
    };
    return styles[status] || styles.draft;
  };

  return (
    <div 
      className={`group relative flex items-stretch bg-zinc-900/40 backdrop-blur-md border rounded-lg overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg ${selected ? 'border-cyan-500/50 bg-cyan-500/5' : 'border-white/10 hover:border-cyan-500/30'}`}
      data-testid={`page-item-${item.id}`}
    >
      {/* Checkbox */}
      <div className="flex items-center justify-center w-12 bg-zinc-800/50 border-r border-white/5">
        <Checkbox checked={selected} onCheckedChange={onSelect} className="border-zinc-600" />
      </div>

      {/* Content */}
      <div className="flex-1 p-4 min-w-0">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-zinc-200 truncate" dangerouslySetInnerHTML={{ __html: item.title?.rendered || item.title }} />
            <div className="flex items-center gap-3 mt-2">
              <span className={`text-xs font-mono px-2 py-0.5 rounded-full border ${getStatusStyle(item.status)}`}>
                {item.status}
              </span>
              <span className="text-xs text-zinc-600 font-mono">
                {new Date(item.date || item.modified).toLocaleDateString()}
              </span>
              <span className="text-xs text-zinc-700 font-mono">
                ID: {item.id}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button variant="ghost" size="icon" onClick={onEdit} data-testid={`edit-page-${item.id}`} className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700">
              <Edit className="w-3.5 h-3.5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={onDelete} data-testid={`delete-page-${item.id}`} className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/20">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PageForm({ domainId, page, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: page?.title?.rendered || '',
    content: page?.content?.rendered?.replace(/<[^>]*>/g, '') || '',
    status: page?.status || 'draft'
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (page) {
        await pagesApi.update(domainId, page.id, formData);
        toast.success('Page updated');
      } else {
        await pagesApi.create(domainId, formData);
        toast.success('Page created');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Title</Label>
        <Input
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
          placeholder="Page title"
          data-testid="page-title-input"
          className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-cyan-500"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Content</Label>
        <Textarea
          value={formData.content}
          onChange={(e) => setFormData({ ...formData, content: e.target.value })}
          rows={6}
          placeholder="Page content..."
          data-testid="page-content-input"
          className="bg-zinc-900 border-white/10 text-white font-mono text-sm focus:ring-2 focus:ring-cyan-500 leading-relaxed"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Status</Label>
        <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
          <SelectTrigger data-testid="page-status-select" className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-cyan-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            <SelectItem value="draft" className="font-mono">Draft</SelectItem>
            <SelectItem value="publish" className="font-mono">Published</SelectItem>
            <SelectItem value="pending" className="font-mono">Pending</SelectItem>
            <SelectItem value="private" className="font-mono">Private</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button 
        type="submit" 
        disabled={loading} 
        data-testid="page-submit-btn" 
        className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-medium h-11 transition-all duration-200 hover:-translate-y-0.5"
      >
        {loading ? <Loader2 className="w-4 h-4 spinner" /> : page ? 'Update Page' : 'Create Page'}
      </Button>
    </form>
  );
}

// ==================== TAGS TAB ====================
function TagsTab({ domainId }) {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const PER_PAGE = 50;

  useEffect(() => {
    setTags([]);
    setPage(1);
    setHasMore(true);
    fetchTags(1, true);
  }, [domainId]);

  const fetchTags = async (pageNum = page, reset = false) => {
    if (reset) {
      setLoading(true);
    } else {
      setLoadingMore(true);
    }
    
    try {
      const response = await tagsApi.list(domainId, pageNum, PER_PAGE);
      const newItems = response.data.items || [];
      const totalItems = response.data.total || 0;
      
      if (reset) {
        setTags(newItems);
      } else {
        setTags(prev => [...prev, ...newItems]);
      }
      
      setTotal(totalItems);
      setHasMore(pageNum * PER_PAGE < totalItems);
      setSelectedIds([]);
    } catch (error) {
      toast.error('Failed to load tags');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchTags(nextPage, false);
  };

  const refresh = () => {
    setTags([]);
    setPage(1);
    setHasMore(true);
    fetchTags(1, true);
  };

  const handleDelete = async (tagId) => {
    if (!window.confirm('Are you sure you want to delete this tag?')) return;
    try {
      await tagsApi.delete(domainId, tagId, true);
      toast.success('Tag deleted');
      refresh();
    } catch (error) {
      toast.error('Failed to delete tag');
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedIds.length} tags?`)) return;
    
    setBulkDeleting(true);
    try {
      const response = await tagsApi.bulkDelete(domainId, selectedIds);
      toast.success(`${response.data.total_deleted} tags deleted`);
      refresh();
    } catch (error) {
      toast.error('Failed to delete tags');
    } finally {
      setBulkDeleting(false);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredTags.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredTags.map(t => t.id));
    }
  };

  const toggleSelect = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const filteredTags = tags.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.slug.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const loadedCount = tags.length;

  return (
    <div className="space-y-6">
      {/* Control Room Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center justify-center">
            <Tag className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 tracking-tight font-[Chivo]">Tags Control</h2>
            <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Taxonomy Management</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-zinc-950 border border-white/10 rounded-lg">
            <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Loaded:</span>
            <span className="text-sm text-emerald-400 font-mono font-bold">{loadedCount} / {total}</span>
          </div>
          <Dialog open={showDialog || !!editItem} onOpenChange={(open) => {
            if (!open) { setShowDialog(false); setEditItem(null); } else { setShowDialog(true); }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-amber-600 hover:bg-amber-500 text-white font-medium px-4 h-10 transition-all duration-200 hover:-translate-y-0.5" data-testid="add-tags-btn">
                <Plus className="w-4 h-4 mr-2" />Add Tag
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-zinc-950 border border-zinc-800 text-white max-w-lg backdrop-blur-xl">
              <DialogHeader><DialogTitle className="font-[Chivo] text-xl tracking-tight">{editItem ? 'Edit Tag' : 'Add New Tag'}</DialogTitle></DialogHeader>
              <TagForm domainId={domainId} tag={editItem} onSuccess={() => { setShowDialog(false); setEditItem(null); refresh(); }} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <Input placeholder="Search tags..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 bg-zinc-900 border-white/10 text-white" />
        {searchQuery && (<button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"><X className="w-4 h-4" /></button>)}
      </div>

      {/* Bulk Actions Bar */}
      {selectedIds.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-red-500/10 border border-red-500/20 rounded-lg animate-in fade-in slide-in-from-top-2">
          <span className="text-sm text-red-400 font-mono">{selectedIds.length} tag{selectedIds.length > 1 ? 's' : ''} selected</span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setSelectedIds([])} className="text-zinc-400 hover:text-white">Clear</Button>
            <Button size="sm" onClick={handleBulkDelete} disabled={bulkDeleting} className="bg-red-600 hover:bg-red-500 text-white">
              {bulkDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}Delete Selected
            </Button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 text-amber-500 spinner" /></div>
      ) : filteredTags.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10"><Tag className="w-8 h-8 text-zinc-600" /></div>
            <p className="text-zinc-300 font-medium">{searchQuery ? 'No matching tags' : 'No tags found'}</p>
            <p className="text-zinc-500 text-sm mt-1">{searchQuery ? 'Try a different search' : 'Create your first tag to organize content'}</p>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-3 px-4 py-2 bg-zinc-900/30 rounded-lg border border-white/5">
            <Checkbox checked={selectedIds.length === filteredTags.length && filteredTags.length > 0} onCheckedChange={toggleSelectAll} className="border-zinc-600" />
            <span className="text-xs text-zinc-500 font-mono">Select All ({filteredTags.length})</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3" data-testid="tags-list">
            {filteredTags.map((item, index) => (
              <TagItem key={item.id} item={item} index={index} selected={selectedIds.includes(item.id)} onSelect={() => toggleSelect(item.id)} onEdit={() => setEditItem(item)} onDelete={() => handleDelete(item.id)} />
            ))}
          </div>
        </>
      )}

      {/* Load More Button */}
      {hasMore && !loading && (
        <div className="flex flex-col items-center gap-3 pt-4">
          <Button
            variant="outline"
            onClick={loadMore}
            disabled={loadingMore}
            className="bg-zinc-900 border-white/10 text-white hover:bg-zinc-800 font-mono px-8"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Load More ({total - loadedCount} remaining)
              </>
            )}
          </Button>
          <div className="w-48 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-amber-500 transition-all duration-300"
              style={{ width: `${(loadedCount / total) * 100}%` }}
            />
          </div>
          <p className="text-xs text-zinc-500 font-mono">{loadedCount} of {total} loaded</p>
        </div>
      )}
      
      {!hasMore && tags.length > 0 && (
        <p className="text-center text-xs text-zinc-600 font-mono pt-4">
          All {total} tags loaded
        </p>
      )}
    </div>
  );
}

function TagItem({ item, index, selected, onSelect, onEdit, onDelete }) {
  return (
    <div 
      className={`group relative bg-zinc-900/40 backdrop-blur-md border rounded-lg overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg p-4 ${selected ? 'border-amber-500/50 bg-amber-500/5' : 'border-white/10 hover:border-amber-500/30'}`}
      data-testid={`tag-item-${item.id}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <Checkbox checked={selected} onCheckedChange={onSelect} className="border-zinc-600 mt-1" />
          <div className="flex-1 min-w-0">
            {/* Tag Name with Badge Style */}
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/10 text-amber-400 rounded-md border border-amber-500/20">
                <Tag className="w-3 h-3" />
                <span className="text-sm font-medium truncate">{item.name}</span>
              </span>
            </div>
            
            {/* Slug */}
            <p className="text-xs text-zinc-600 font-mono mb-1">/{item.slug}</p>
            
            {/* Description */}
            {item.description && (
              <p className="text-xs text-zinc-400 line-clamp-2 mt-2">{item.description}</p>
            )}
            
            {/* ID */}
            <p className="text-xs text-zinc-700 font-mono mt-2">ID: {item.id}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <Button variant="ghost" size="icon" onClick={onEdit} data-testid={`edit-tag-${item.id}`} className="h-7 w-7 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700">
            <Edit className="w-3 h-3" />
          </Button>
          <Button variant="ghost" size="icon" onClick={onDelete} data-testid={`delete-tag-${item.id}`} className="h-7 w-7 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/20">
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function TagForm({ domainId, tag, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: tag?.name || '',
    slug: tag?.slug || '',
    description: tag?.description || ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = { ...formData };
      if (!data.slug) delete data.slug;
      if (tag) {
        await tagsApi.update(domainId, tag.id, data);
        toast.success('Tag updated');
      } else {
        await tagsApi.create(domainId, data);
        toast.success('Tag created');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Name</Label>
        <Input
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
          placeholder="Tag name"
          data-testid="tag-name-input"
          className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-amber-500"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Slug (optional)</Label>
        <Input
          value={formData.slug}
          onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
          placeholder="tag-slug"
          data-testid="tag-slug-input"
          className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-amber-500"
        />
        <p className="text-xs text-zinc-600 font-mono">Auto-generated if left empty</p>
      </div>
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Description</Label>
        <Textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={3}
          placeholder="Tag description..."
          data-testid="tag-description-input"
          className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-amber-500"
        />
      </div>
      <Button 
        type="submit" 
        disabled={loading} 
        data-testid="tag-submit-btn" 
        className="w-full bg-amber-600 hover:bg-amber-500 text-white font-medium h-11 transition-all duration-200 hover:-translate-y-0.5"
      >
        {loading ? <Loader2 className="w-4 h-4 spinner" /> : tag ? 'Update Tag' : 'Create Tag'}
      </Button>
    </form>
  );
}

// ==================== USERS TAB ====================
function UsersTab({ domainId }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const PER_PAGE = 20;

  useEffect(() => {
    setUsers([]);
    setPage(1);
    setHasMore(true);
    fetchUsers(1, true);
  }, [domainId]);

  const fetchUsers = async (pageNum = page, reset = false) => {
    if (reset) {
      setLoading(true);
    } else {
      setLoadingMore(true);
    }
    
    try {
      const response = await usersApi.list(domainId, pageNum, PER_PAGE);
      const newItems = response.data.items || [];
      const totalItems = response.data.total || 0;
      
      if (reset) {
        setUsers(newItems);
      } else {
        setUsers(prev => [...prev, ...newItems]);
      }
      
      setTotal(totalItems);
      setHasMore(pageNum * PER_PAGE < totalItems);
    } catch (error) {
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchUsers(nextPage, false);
  };

  const refresh = () => {
    setUsers([]);
    setPage(1);
    setHasMore(true);
    fetchUsers(1, true);
  };

  const handleDelete = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await usersApi.delete(domainId, userId, null, true);
      toast.success('User deleted');
      refresh();
    } catch (error) {
      toast.error('Failed to delete user');
    }
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.slug?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.roles?.includes(roleFilter);
    return matchesSearch && matchesRole;
  });

  const loadedCount = users.length;

  return (
    <div className="space-y-6">
      {/* Control Room Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-violet-500/10 border border-violet-500/20 rounded-lg flex items-center justify-center">
            <Users className="w-5 h-5 text-violet-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 tracking-tight font-[Chivo]">Users Control</h2>
            <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Account Management</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-zinc-950 border border-white/10 rounded-lg">
            <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Loaded:</span>
            <span className="text-sm text-emerald-400 font-mono font-bold">{loadedCount} / {total}</span>
          </div>
          <Dialog open={showDialog || !!editItem} onOpenChange={(open) => {
            if (!open) { setShowDialog(false); setEditItem(null); } else { setShowDialog(true); }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-violet-600 hover:bg-violet-500 text-white font-medium px-4 h-10 transition-all duration-200 hover:-translate-y-0.5" data-testid="add-users-btn">
                <Plus className="w-4 h-4 mr-2" />Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-zinc-950 border border-zinc-800 text-white max-w-lg backdrop-blur-xl">
              <DialogHeader><DialogTitle className="font-[Chivo] text-xl tracking-tight">{editItem ? 'Edit User' : 'Add New User'}</DialogTitle></DialogHeader>
              <UserForm domainId={domainId} user={editItem} onSuccess={() => { setShowDialog(false); setEditItem(null); refresh(); }} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input placeholder="Search users..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 bg-zinc-900 border-white/10 text-white" />
          {searchQuery && (<button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"><X className="w-4 h-4" /></button>)}
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-44 bg-zinc-900 border-white/10 text-white"><Filter className="w-4 h-4 mr-2 text-zinc-500" /><SelectValue placeholder="Role" /></SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            <SelectItem value="all">All Roles</SelectItem>
            <SelectItem value="administrator">Administrator</SelectItem>
            <SelectItem value="editor">Editor</SelectItem>
            <SelectItem value="author">Author</SelectItem>
            <SelectItem value="contributor">Contributor</SelectItem>
            <SelectItem value="subscriber">Subscriber</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 text-violet-500 spinner" /></div>
      ) : filteredUsers.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10"><Users className="w-8 h-8 text-zinc-600" /></div>
            <p className="text-zinc-300 font-medium">{searchQuery || roleFilter !== 'all' ? 'No matching users' : 'No users found'}</p>
            <p className="text-zinc-500 text-sm mt-1">{searchQuery || roleFilter !== 'all' ? 'Try adjusting your filters' : 'Add your first user to get started'}</p>
          </div>
        </div>
      ) : (
        <div className="space-y-3" data-testid="users-list">
          {filteredUsers.map((item, index) => (
            <UserItem key={item.id} item={item} index={index} onEdit={() => setEditItem(item)} onDelete={() => handleDelete(item.id)} />
          ))}
        </div>
      )}

      {/* Load More Button */}
      {hasMore && !loading && (
        <div className="flex flex-col items-center gap-3 pt-4">
          <Button
            variant="outline"
            onClick={loadMore}
            disabled={loadingMore}
            className="bg-zinc-900 border-white/10 text-white hover:bg-zinc-800 font-mono px-8"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Load More ({total - loadedCount} remaining)
              </>
            )}
          </Button>
          <div className="w-48 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-violet-500 transition-all duration-300"
              style={{ width: `${(loadedCount / total) * 100}%` }}
            />
          </div>
          <p className="text-xs text-zinc-500 font-mono">{loadedCount} of {total} loaded</p>
        </div>
      )}
      
      {!hasMore && users.length > 0 && (
        <p className="text-center text-xs text-zinc-600 font-mono pt-4">
          All {total} users loaded
        </p>
      )}
    </div>
  );
}

function UserItem({ item, index, onEdit, onDelete }) {
  const getRoleBadgeStyle = (role) => {
    const styles = {
      administrator: 'bg-red-500/10 text-red-400 border-red-500/20',
      editor: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
      author: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
      contributor: 'bg-teal-500/10 text-teal-400 border-teal-500/20',
      subscriber: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'
    };
    return styles[role] || styles.subscriber;
  };

  const primaryRole = item.roles?.[0] || 'subscriber';

  return (
    <div 
      className="group relative flex items-stretch bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg overflow-hidden transition-all duration-200 hover:border-violet-500/30 hover:-translate-y-0.5 hover:shadow-lg" 
      data-testid={`user-item-${item.id}`}
    >
      {/* Index Badge */}
      <div className="flex items-center justify-center w-12 bg-zinc-800/50 border-r border-white/5">
        <span className="text-xs font-mono text-zinc-600">#{index + 1}</span>
      </div>

      {/* Content */}
      <div className="flex-1 p-4 min-w-0">
        <div className="flex items-center gap-4">
          {/* Avatar */}
          {item.avatar_urls?.['48'] ? (
            <img src={item.avatar_urls['48']} alt="" className="w-11 h-11 rounded-full border-2 border-white/10" />
          ) : (
            <div className="w-11 h-11 bg-gradient-to-br from-violet-500/20 to-purple-500/20 rounded-full flex items-center justify-center border-2 border-white/10">
              <Users className="w-5 h-5 text-violet-400" />
            </div>
          )}

          {/* User Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3">
              <h4 className="text-sm font-medium text-zinc-200 truncate">{item.name}</h4>
              <span className={`text-xs font-mono px-2 py-0.5 rounded-full border ${getRoleBadgeStyle(primaryRole)}`}>
                {primaryRole}
              </span>
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-xs text-zinc-500 font-mono">@{item.slug}</span>
              <span className="text-xs text-zinc-700 font-mono">ID: {item.id}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onEdit} 
              data-testid={`edit-user-${item.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700"
            >
              <Edit className="w-3.5 h-3.5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onDelete} 
              data-testid={`delete-user-${item.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/20"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function UserForm({ domainId, user, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: user?.slug || '',
    email: user?.email || '',
    password: '',
    first_name: user?.first_name || '',
    last_name: user?.last_name || '',
    roles: user?.roles || ['subscriber']
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (user) {
        const updateData = {
          email: formData.email,
          first_name: formData.first_name,
          last_name: formData.last_name,
          roles: formData.roles
        };
        await usersApi.update(domainId, user.id, updateData);
        toast.success('User updated');
      } else {
        await usersApi.create(domainId, formData);
        toast.success('User created');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {!user && (
        <div className="space-y-2">
          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Username</Label>
          <Input
            value={formData.username}
            onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            required
            placeholder="username"
            data-testid="user-username-input"
            className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-violet-500"
          />
        </div>
      )}
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Email</Label>
        <Input
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required
          placeholder="user@example.com"
          data-testid="user-email-input"
          className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-violet-500"
        />
      </div>
      {!user && (
        <div className="space-y-2">
          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Password</Label>
          <Input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            required
            placeholder="••••••••"
            data-testid="user-password-input"
            className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-violet-500"
          />
        </div>
      )}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">First Name</Label>
          <Input
            value={formData.first_name}
            onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
            placeholder="John"
            data-testid="user-firstname-input"
            className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-violet-500"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Last Name</Label>
          <Input
            value={formData.last_name}
            onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
            placeholder="Doe"
            data-testid="user-lastname-input"
            className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-violet-500"
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Role</Label>
        <Select value={formData.roles[0]} onValueChange={(v) => setFormData({ ...formData, roles: [v] })}>
          <SelectTrigger data-testid="user-role-select" className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-violet-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            <SelectItem value="subscriber" className="font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-zinc-400"></span>
                Subscriber
              </span>
            </SelectItem>
            <SelectItem value="contributor" className="font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                Contributor
              </span>
            </SelectItem>
            <SelectItem value="author" className="font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                Author
              </span>
            </SelectItem>
            <SelectItem value="editor" className="font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-orange-400"></span>
                Editor
              </span>
            </SelectItem>
            <SelectItem value="administrator" className="font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-400"></span>
                Administrator
              </span>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button 
        type="submit" 
        disabled={loading} 
        data-testid="user-submit-btn" 
        className="w-full bg-violet-600 hover:bg-violet-500 text-white font-medium h-11 transition-all duration-200 hover:-translate-y-0.5"
      >
        {loading ? <Loader2 className="w-4 h-4 spinner" /> : user ? 'Update User' : 'Create User'}
      </Button>
    </form>
  );
}

// ==================== WIDGETS TAB ====================
function WidgetsTab({ domainId }) {
  const [sidebars, setSidebars] = useState([]);
  const [widgets, setWidgets] = useState([]);
  const [widgetTypes, setWidgetTypes] = useState([]);
  const [selectedSidebar, setSelectedSidebar] = useState('');
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editWidget, setEditWidget] = useState(null);

  useEffect(() => {
    fetchData();
  }, [domainId]);

  useEffect(() => {
    if (selectedSidebar) {
      fetchWidgets();
    }
  }, [selectedSidebar]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [sidebarsRes, typesRes] = await Promise.all([
        widgetsApi.listSidebars(domainId),
        widgetsApi.listWidgetTypes(domainId)
      ]);
      setSidebars(sidebarsRes.data || []);
      setWidgetTypes(typesRes.data || []);
      
      // Select first sidebar by default
      if (sidebarsRes.data?.length > 0) {
        setSelectedSidebar(sidebarsRes.data[0].id);
      }
    } catch (error) {
      console.log('Failed to load sidebars/widget types');
    } finally {
      setLoading(false);
    }
  };

  const fetchWidgets = async () => {
    try {
      const response = await widgetsApi.list(domainId, selectedSidebar);
      setWidgets(response.data || []);
    } catch (error) {
      console.log('Failed to load widgets');
      setWidgets([]);
    }
  };

  const handleDelete = async (widgetId) => {
    if (!window.confirm('Are you sure you want to delete this widget?')) return;
    try {
      await widgetsApi.delete(domainId, widgetId);
      toast.success('Widget deleted');
      fetchWidgets();
    } catch (error) {
      toast.error('Failed to delete widget');
    }
  };

  const handleMoveWidget = async (widgetId, newSidebar) => {
    try {
      await widgetsApi.update(domainId, widgetId, { sidebar: newSidebar });
      toast.success('Widget moved');
      fetchWidgets();
    } catch (error) {
      toast.error('Failed to move widget');
    }
  };

  // Drag and Drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = async (event) => {
    const { active, over } = event;
    
    if (active.id !== over?.id) {
      const oldIndex = widgets.findIndex((w) => w.id === active.id);
      const newIndex = widgets.findIndex((w) => w.id === over.id);
      
      // Optimistically update UI
      const newWidgets = arrayMove(widgets, oldIndex, newIndex);
      setWidgets(newWidgets);
      
      // Update on server
      try {
        const widgetIds = newWidgets.map(w => w.id);
        await widgetsApi.reorder(domainId, selectedSidebar, widgetIds);
        toast.success('Widget order updated');
      } catch (error) {
        // Revert on error
        fetchWidgets();
        toast.error('Failed to reorder widgets');
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="w-6 h-6 text-indigo-500 spinner" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Control Room Header */}
      <div className="relative">
        {/* Sidebar Selector Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/20 rounded-lg flex items-center justify-center">
              <LayoutGrid className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-zinc-100 tracking-tight font-[Chivo]">Widget Control</h2>
              <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Sidebar Management</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Sidebar Selector - Terminal Style */}
            <div className="flex items-center gap-2 px-4 py-2 bg-zinc-950 border border-white/10 rounded-lg">
              <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Sidebar:</span>
              <Select value={selectedSidebar} onValueChange={setSelectedSidebar}>
                <SelectTrigger className="w-40 h-8 bg-transparent border-0 text-indigo-400 font-mono text-sm focus:ring-0 p-0" data-testid="sidebar-select">
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent className="bg-zinc-950 border border-white/10">
                  {sidebars.map((sidebar) => (
                    <SelectItem key={sidebar.id} value={sidebar.id} className="font-mono text-sm">
                      {sidebar.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Widget Count Badge */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-zinc-950 border border-white/10 rounded-lg">
              <span className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Count:</span>
              <span className="text-sm text-emerald-400 font-mono font-bold">{widgets.length}</span>
            </div>

            {/* Add Widget Button */}
            <Dialog open={showDialog || !!editWidget} onOpenChange={(open) => {
              if (!open) {
                setShowDialog(false);
                setEditWidget(null);
              } else {
                setShowDialog(true);
              }
            }}>
              <DialogTrigger asChild>
                <Button className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 h-10 transition-all duration-200 hover:-translate-y-0.5" data-testid="add-widget-btn">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Widget
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-zinc-950 border border-zinc-800 text-white max-w-lg backdrop-blur-xl">
                <DialogHeader>
                  <DialogTitle className="font-[Chivo] text-xl tracking-tight">
                    {editWidget ? 'Edit Widget' : 'Add New Widget'}
                  </DialogTitle>
                </DialogHeader>
                <WidgetForm
                  domainId={domainId}
                  widget={editWidget}
                  widgetTypes={widgetTypes}
                  sidebars={sidebars}
                  currentSidebar={selectedSidebar}
                  onSuccess={() => {
                    setShowDialog(false);
                    setEditWidget(null);
                    fetchWidgets();
                  }}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Widgets List */}
      {sidebars.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'url(https://images.unsplash.com/photo-1737505598998-693328b57ae3?w=800)', backgroundSize: 'cover', backgroundPosition: 'center'}} />
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10">
              <LayoutGrid className="w-8 h-8 text-zinc-600" />
            </div>
            <p className="text-zinc-300 font-medium">No sidebars found</p>
            <p className="text-zinc-500 text-sm mt-1">This WordPress site has no widget areas configured</p>
          </div>
        </div>
      ) : widgets.length === 0 ? (
        <div className="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-900/20">
          <div className="absolute inset-0 opacity-5" style={{backgroundImage: 'url(https://images.unsplash.com/photo-1737505598998-693328b57ae3?w=800)', backgroundSize: 'cover', backgroundPosition: 'center'}} />
          <div className="relative text-center py-16 px-6">
            <div className="w-16 h-16 bg-zinc-800/50 rounded-xl flex items-center justify-center mx-auto mb-4 border border-white/10">
              <Plus className="w-8 h-8 text-zinc-600" />
            </div>
            <p className="text-zinc-300 font-medium">No widgets in this sidebar</p>
            <p className="text-zinc-500 text-sm mt-2">Click &quot;Add Widget&quot; to get started</p>
          </div>
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={widgets.map(w => w.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-3" data-testid="widgets-list">
              {widgets.map((widget, index) => (
                <SortableWidgetItem
                  key={widget.id}
                  widget={widget}
                  index={index}
                  sidebars={sidebars}
                  onEdit={() => setEditWidget(widget)}
                  onDelete={() => handleDelete(widget.id)}
                  onMove={(newSidebar) => handleMoveWidget(widget.id, newSidebar)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
}

function SortableWidgetItem({ widget, index, sidebars, onEdit, onDelete, onMove }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: widget.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 1000 : 1,
  };

  const getWidgetTitle = () => {
    if (widget.instance?.title) return widget.instance.title;
    if (widget.id_base) return widget.id_base.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    return `Widget ${index + 1}`;
  };

  const getWidgetPreview = () => {
    const instance = widget.instance || {};
    if (instance.text) return instance.text.replace(/<[^>]*>/g, '').substring(0, 120);
    if (instance.content) return instance.content.replace(/<[^>]*>/g, '').substring(0, 120);
    if (widget.rendered) {
      const text = widget.rendered.replace(/<[^>]*>/g, '');
      return text.substring(0, 120);
    }
    return null;
  };

  const preview = getWidgetPreview();

  return (
    <div 
      ref={setNodeRef}
      style={style}
      className={`group relative flex items-stretch bg-zinc-900/40 backdrop-blur-md border border-white/10 rounded-lg overflow-hidden transition-all duration-200 hover:border-indigo-500/30 ${isDragging ? 'shadow-2xl border-indigo-500/50' : 'hover:-translate-y-0.5 hover:shadow-lg'}`}
      data-testid={`widget-item-${widget.id}`}
    >
      {/* Drag Handle - Textured Pattern */}
      <div 
        {...attributes}
        {...listeners}
        className="flex items-center justify-center w-10 bg-zinc-800/50 border-r border-white/5 cursor-grab active:cursor-grabbing hover:bg-zinc-700/50 transition-colors"
        aria-label="Drag to reorder"
      >
        <div className="flex flex-col gap-1">
          <div className="flex gap-1">
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
          </div>
          <div className="flex gap-1">
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
          </div>
          <div className="flex gap-1">
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
            <div className="w-1 h-1 rounded-full bg-zinc-600" />
          </div>
        </div>
      </div>

      {/* Widget Content */}
      <div className="flex-1 p-4 min-w-0">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            {/* Title + Type Badge Row */}
            <div className="flex items-center gap-3 mb-2">
              <h4 className="text-sm font-medium text-zinc-200 font-mono truncate">
                {getWidgetTitle()}
              </h4>
              <span className="shrink-0 text-xs font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {widget.id_base || 'widget'}
              </span>
            </div>
            
            {/* ID */}
            <p className="text-xs text-zinc-600 font-mono mb-2">
              ID: {widget.id}
            </p>

            {/* Preview */}
            {preview && (
              <p className="text-sm text-zinc-400 leading-relaxed line-clamp-2">
                {preview}...
              </p>
            )}
          </div>

          {/* Actions - Show on hover */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            {/* Move Dropdown */}
            <Select onValueChange={onMove}>
              <SelectTrigger 
                className="h-8 w-8 p-0 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700 focus:ring-2 focus:ring-indigo-500" 
                data-testid={`move-widget-${widget.id}`}
              >
                <Settings className="w-3.5 h-3.5" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-950 border border-white/10">
                <div className="px-3 py-2 text-xs text-zinc-500 uppercase tracking-widest font-mono border-b border-white/5">
                  Move to
                </div>
                {sidebars.map((sidebar) => (
                  <SelectItem key={sidebar.id} value={sidebar.id} className="font-mono text-sm">
                    {sidebar.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onEdit} 
              data-testid={`edit-widget-${widget.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-700 focus:ring-2 focus:ring-indigo-500"
            >
              <Edit className="w-3.5 h-3.5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onDelete} 
              data-testid={`delete-widget-${widget.id}`} 
              className="h-8 w-8 bg-zinc-800/50 border border-white/10 rounded-md text-zinc-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/20 focus:ring-2 focus:ring-red-500"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Index Badge */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-0">
        <span className="text-xs font-mono text-zinc-600">#{index + 1}</span>
      </div>
    </div>
  );
}

function WidgetForm({ domainId, widget, widgetTypes, sidebars, currentSidebar, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    id_base: widget?.id_base || 'text',  // Default to text widget
    sidebar: widget?.sidebar || currentSidebar,
    instance: widget?.instance || {}
  });

  // Extract content from various widget formats
  const extractContent = () => {
    if (!widget) return '';
    
    // Try instance.text first (classic text widget)
    if (widget.instance?.text) return widget.instance.text;
    
    // Try instance.content (custom_html widget)
    if (widget.instance?.content) {
      // If it's block markup, strip the comments
      const content = widget.instance.content;
      if (content.includes('<!-- wp:')) {
        return content.replace(/<!-- wp:[^\n]+ -->\n?/g, '').replace(/<!-- \/wp:[^\n]+ -->\n?/g, '').trim();
      }
      return content;
    }
    
    // Try instance.raw (block widget)
    if (widget.instance?.raw) {
      const raw = typeof widget.instance.raw === 'string' 
        ? widget.instance.raw 
        : widget.instance.raw?.content || '';
      return raw.replace(/<!-- wp:[^\n]+ -->\n?/g, '').replace(/<!-- \/wp:[^\n]+ -->\n?/g, '').trim();
    }
    
    // Try rendered HTML as fallback (strip all HTML for preview but keep for editing)
    if (widget.rendered) {
      // Keep the HTML structure for editing
      const div = document.createElement('div');
      div.innerHTML = widget.rendered;
      // Remove widget wrapper if exists
      const inner = div.querySelector('.textwidget, .widget-content') || div;
      return inner.innerHTML.trim();
    }
    
    return '';
  };

  // Common widget instance fields
  const [title, setTitle] = useState(widget?.instance?.title || '');
  const [text, setText] = useState(extractContent());
  
  // Recommend widget types for easier selection
  const recommendedTypes = ['text', 'custom_html', 'block', 'recent-posts', 'categories', 'search'];
  const sortedTypes = widgetTypes.sort((a, b) => {
    const aRecommended = recommendedTypes.includes(a.id);
    const bRecommended = recommendedTypes.includes(b.id);
    if (aRecommended && !bRecommended) return -1;
    if (!aRecommended && bRecommended) return 1;
    return a.name.localeCompare(b.name);
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const instance = { ...formData.instance };
      if (title) instance.title = title;
      if (text) {
        instance.text = text;
        instance.content = text;
      }

      if (widget) {
        // Update existing widget
        await widgetsApi.update(domainId, widget.id, {
          sidebar: formData.sidebar,
          instance
        });
        toast.success('Widget updated');
      } else {
        // Create new widget
        await widgetsApi.create(domainId, {
          id_base: formData.id_base,
          sidebar: formData.sidebar,
          instance
        });
        toast.success('Widget created');
      }
      onSuccess();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Show widget type info when editing */}
      {widget && (
        <div className="p-4 bg-zinc-900 rounded-lg border border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/20 rounded-lg flex items-center justify-center">
              <LayoutGrid className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Widget Type</p>
              <p className="text-sm text-white font-mono font-medium">{widget.id_base || 'unknown'}</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/5">
            <p className="text-xs text-zinc-600 font-mono">ID: {widget.id}</p>
          </div>
        </div>
      )}
      
      {/* Widget Type (only for new widgets) */}
      {!widget && (
        <div className="space-y-2">
          <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Widget Type</Label>
          <Select value={formData.id_base} onValueChange={(v) => setFormData({ ...formData, id_base: v })}>
            <SelectTrigger className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-indigo-500" data-testid="widget-type-select">
              <SelectValue placeholder="Select widget type" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-950 border-white/10 max-h-60">
              {sortedTypes.map((type) => (
                <SelectItem key={type.id} value={type.id} className="font-mono">
                  <span className="flex items-center gap-2">
                    {type.name}
                    {recommendedTypes.includes(type.id) && (
                      <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">★</span>
                    )}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-zinc-600">
            ★ Recommended: Text, Custom HTML, or Block widget
          </p>
        </div>
      )}

      {/* Sidebar */}
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Target Sidebar</Label>
        <Select value={formData.sidebar} onValueChange={(v) => setFormData({ ...formData, sidebar: v })}>
          <SelectTrigger className="bg-zinc-900 border-white/10 text-white font-mono focus:ring-2 focus:ring-indigo-500" data-testid="widget-sidebar-select">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-white/10">
            {sidebars.map((sidebar) => (
              <SelectItem key={sidebar.id} value={sidebar.id} className="font-mono">
                {sidebar.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Title */}
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Title (optional)</Label>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Widget title"
          data-testid="widget-title-input"
          className="bg-zinc-900 border-white/10 text-white focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Content/Text */}
      <div className="space-y-2">
        <Label className="text-xs text-zinc-500 uppercase tracking-widest font-mono">Content</Label>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="<a href='https://example.com'>Link text</a>"
          rows={8}
          data-testid="widget-content-input"
          className="bg-zinc-900 border-white/10 text-white font-mono text-sm focus:ring-2 focus:ring-indigo-500 leading-relaxed"
        />
        <p className="text-xs text-zinc-600 font-mono">HTML supported • Use &lt;ul&gt;&lt;li&gt; for lists</p>
      </div>

      <Button
        type="submit"
        disabled={loading || (!widget && !formData.id_base)}
        data-testid="widget-submit-btn"
        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium h-11 transition-all duration-200 hover:-translate-y-0.5"
      >
        {loading ? (
          <Loader2 className="w-4 h-4 spinner" />
        ) : (
          widget ? 'Update Widget' : 'Create Widget'
        )}
      </Button>
    </form>
  );
}
