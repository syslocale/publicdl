#!/usr/bin/env python3
"""
WPMTools Database Seeder
========================
Script untuk membuat user superadmin default.

Cara pakai:
    cd /var/www/wpmtools/backend
    source venv/bin/activate
    python3 seed.py

Options:
    python3 seed.py          # Create default users
    python3 seed.py list     # List existing users
    python3 seed.py reset    # Reset and recreate users (DESTRUCTIVE!)
"""

import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import bcrypt
import uuid
from datetime import datetime, timezone
import os
from dotenv import load_dotenv

# Load environment
load_dotenv()

# ========================================
# KONFIGURASI USER DEFAULT
# ========================================
DEFAULT_USERS = [
    {
        "username": "superadmin",
        "password": "Superadmin123!",  # GANTI SETELAH LOGIN!
        "name": "Super Admin",
        "role": "superadmin"
    }
]
# ========================================


async def seed_database():
    """Create default users in database"""
    
    # Connect to MongoDB
    mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
    db_name = os.environ.get('DB_NAME', 'wpmtools')
    
    print(f"\n{'='*50}")
    print("🌱 WPMTools Database Seeder")
    print(f"{'='*50}")
    print("\n🔌 Connecting to MongoDB...")
    print(f"📁 Database: {db_name}")
    print("-" * 50)
    
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # Manage indexes
    print("\n📇 Creating indexes...")
    
    # Drop old 'email' index if exists (legacy)
    try:
        await db.users.drop_index("email_1")
    except Exception:
        pass
    
    # Create indexes
    await db.users.create_index("username", unique=True)
    await db.users.create_index("id", unique=True)
    await db.domains.create_index("user_id")
    await db.domains.create_index("id", unique=True)
    await db.activity_logs.create_index([("timestamp", -1)])
    print("✅ Indexes created")
    
    # Create users
    print("\n👤 Creating users...")
    print("-" * 50)
    
    created_count = 0
    skipped_count = 0
    
    for user_data in DEFAULT_USERS:
        username = user_data["username"]
        
        # Check if exists
        existing = await db.users.find_one({"username": username})
        if existing:
            print(f"⏭️  User '{username}' sudah ada - SKIP")
            skipped_count += 1
            continue
        
        # Hash password
        password_hash = bcrypt.hashpw(
            user_data["password"].encode('utf-8'), 
            bcrypt.gensalt()
        ).decode('utf-8')
        
        # Create user document
        user_doc = {
            "id": str(uuid.uuid4()),
            "username": username,
            "name": user_data["name"],
            "password_hash": password_hash,
            "role": user_data["role"],
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Insert
        await db.users.insert_one(user_doc)
        print(f"✅ User '{username}' dibuat (role: {user_data['role']})")
        created_count += 1
    
    print("-" * 50)
    print(f"📊 Summary: {created_count} created, {skipped_count} skipped")
    
    # Show credentials
    if created_count > 0:
        print("\n" + "=" * 50)
        print("🔐 KREDENSIAL LOGIN:")
        print("=" * 50)
        for user_data in DEFAULT_USERS:
            print(f"\n   Username : {user_data['username']}")
            print(f"   Password : {user_data['password']}")
            print(f"   Role     : {user_data['role']}")
        print("\n" + "=" * 50)
        print("⚠️  PENTING: Segera ganti password setelah login!")
        print("=" * 50)
    
    client.close()
    print("\n✅ Seeding complete!\n")


async def reset_database():
    """Reset all users (USE WITH CAUTION!)"""
    
    mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
    db_name = os.environ.get('DB_NAME', 'wpmtools')
    
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # Delete all users
    result = await db.users.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} users")
    
    # Delete all domains
    result = await db.domains.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} domains")
    
    # Delete all activity logs
    result = await db.activity_logs.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} activity logs")
    
    # Delete app settings
    result = await db.app_settings.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} app settings")
    
    client.close()


async def list_users():
    """List all users in database"""
    
    mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
    db_name = os.environ.get('DB_NAME', 'wpmtools')
    
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    users = await db.users.find({}, {"_id": 0, "username": 1, "name": 1, "role": 1}).to_list(100)
    
    print(f"\n📋 Users in database ({len(users)} total):")
    print("-" * 50)
    for u in users:
        role_emoji = "👑" if u.get('role') == 'superadmin' else "👤" if u.get('role') == 'admin' else "📝"
        print(f"   {role_emoji} {u.get('username')} ({u.get('role')}) - {u.get('name')}")
    
    if not users:
        print("   (Tidak ada user)")
    
    client.close()


async def clear_test_data():
    """Clear test domains and logs only (keep users)"""
    
    mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
    db_name = os.environ.get('DB_NAME', 'wpmtools')
    
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # Delete all domains
    result = await db.domains.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} domains")
    
    # Delete all activity logs
    result = await db.activity_logs.delete_many({})
    print(f"🗑️  Deleted {result.deleted_count} activity logs")
    
    client.close()
    print("✅ Test data cleared (users preserved)")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "reset":
            print("\n⚠️  WARNING: Ini akan menghapus SEMUA data!")
            print("   - Semua users")
            print("   - Semua domains")
            print("   - Semua activity logs")
            print("   - Semua settings")
            confirm = input("\nKetik 'YES' untuk konfirmasi: ")
            if confirm == "YES":
                asyncio.run(reset_database())
                asyncio.run(seed_database())
            else:
                print("❌ Dibatalkan")
        
        elif command == "list":
            asyncio.run(list_users())
        
        elif command == "clear":
            print("\n⚠️  Ini akan menghapus domains dan logs (users tetap)")
            confirm = input("Ketik 'YES' untuk konfirmasi: ")
            if confirm == "YES":
                asyncio.run(clear_test_data())
            else:
                print("❌ Dibatalkan")
        
        else:
            print(f"❌ Unknown command: {command}")
            print("\nUsage:")
            print("  python3 seed.py          # Create default users")
            print("  python3 seed.py list     # List existing users")
            print("  python3 seed.py clear    # Clear domains & logs only")
            print("  python3 seed.py reset    # Reset ALL data (destructive!)")
    else:
        asyncio.run(seed_database())
