import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { teamApi, profileApi } from '../lib/api';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog';
import { toast } from 'sonner';
import {
  ArrowLeft, Users, UserPlus, Shield, Trash2,
  Loader2, LogOut, Lock, User, Edit, Save, X, Crown, Briefcase, Key
} from 'lucide-react';
import Logo from '../components/Logo';
import { LanguageSwitcher } from '../components/LanguageSwitcher';

export default function TeamPage() {
  const { user, logout, refreshUser } = useAuth();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [members, setMembers] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Add member form
  const [newMember, setNewMember] = useState({ name: '', username: '', password: '' });
  
  // Profile edit
  const [profileEdit, setProfileEdit] = useState({ name: '' });
  const [passwordChange, setPasswordChange] = useState({ current_password: '', new_password: '', confirm_password: '' });
  
  // Reset password modal
  const [resetPasswordModal, setResetPasswordModal] = useState(false);
  const [resetPasswordTarget, setResetPasswordTarget] = useState(null);
  const [newPasswordForMember, setNewPasswordForMember] = useState('');
  const [resettingPassword, setResettingPassword] = useState(false);

  const isSuperadmin = user?.role === 'superadmin';
  const isAdmin = user?.role === 'admin';
  const canManageMembers = isSuperadmin || isAdmin;
  
  // Determine what role the current user can create
  const canCreateRole = isSuperadmin ? 'Admin' : isAdmin ? 'Staff' : null;

  useEffect(() => {
    fetchMembers();
    if (user) {
      setProfileEdit({ name: user.name || '' });
    }
  }, [user]);

  const fetchMembers = async () => {
    try {
      const response = await teamApi.listMembers();
      setMembers(response.data.members || []);
    } catch (error) {
      console.error('Failed to load team members:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleResetPassword = (member) => {
    setResetPasswordTarget(member);
    setNewPasswordForMember('');
    setResetPasswordModal(true);
  };
  
  const handleConfirmResetPassword = async () => {
    if (!newPasswordForMember || newPasswordForMember.length < 6) {
      toast.error(t('passwordMinLength'));
      return;
    }
    
    setResettingPassword(true);
    try {
      await teamApi.resetMemberPassword(resetPasswordTarget.id, newPasswordForMember);
      toast.success(t('passwordReset'));
      setResetPasswordModal(false);
      setResetPasswordTarget(null);
      setNewPasswordForMember('');
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedToSave'));
    } finally {
      setResettingPassword(false);
    }
  };

  const handleAddMember = async (e) => {
    e.preventDefault();
    if (!newMember.username || !newMember.password) {
      toast.error(t('usernamePasswordRequired'));
      return;
    }
    
    setSaving(true);
    try {
      // Send username to backend
      await teamApi.createMember({
        name: newMember.name || newMember.username,
        username: newMember.username,
        password: newMember.password
      });
      toast.success(t('memberAdded'));
      setNewMember({ name: '', username: '', password: '' });
      setShowAddForm(false);
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedToAddMember'));
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteMember = async (memberId, memberName) => {
    if (!window.confirm(`${t('confirmDelete')} ${memberName}?`)) return;
    
    try {
      await teamApi.deleteMember(memberId);
      toast.success('Team member removed');
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to remove member');
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await profileApi.update(profileEdit);
      toast.success('Profile updated');
      if (refreshUser) refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (passwordChange.new_password !== passwordChange.confirm_password) {
      toast.error(t('passwordsDoNotMatch'));
      return;
    }
    if (passwordChange.new_password.length < 6) {
      toast.error(t('passwordMinLength'));
      return;
    }
    
    setSaving(true);
    try {
      await profileApi.changePassword({
        current_password: passwordChange.current_password,
        new_password: passwordChange.new_password
      });
      toast.success(t('passwordChanged'));
      setPasswordChange({ current_password: '', new_password: '', confirm_password: '' });
    } catch (error) {
      toast.error(error.response?.data?.detail || t('failedToSave'));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="text-zinc-400 hover:text-white transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Logo className="w-9 h-9" />
              <span className="text-xl font-bold text-white">WPMTools</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400 flex items-center gap-1">
                {user?.role === 'superadmin' && <Crown className="w-4 h-4 text-amber-400" />}
                {user?.name}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {t('logout')}
              </Button>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Users className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-[Chivo]">{t('teamMembers')}</h1>
            <p className="text-zinc-400 text-sm">{t('teamDesc')}</p>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-zinc-800 p-1">
            <TabsTrigger value="profile" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <User className="w-4 h-4 mr-2" />{t('myProfile')}
            </TabsTrigger>
            <TabsTrigger value="team" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />{t('teamMembers')}
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            {/* Profile Info */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Edit className="w-5 h-5 text-indigo-400" />
                  {t('myProfile')}
                </CardTitle>
                <CardDescription className="text-zinc-500">
                  {t('teamDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-zinc-400">{t('name')}</Label>
                      <Input
                        value={profileEdit.name}
                        onChange={(e) => setProfileEdit({ ...profileEdit, name: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder={t('name')}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-zinc-400">{t('username')}</Label>
                      <Input
                        value={user?.username || ''}
                        disabled
                        className="bg-zinc-800 border-white/10 text-zinc-400 cursor-not-allowed"
                      />
                      <p className="text-xs text-zinc-600">{t('usernameCannotChange')}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-2">
                    <span className="text-xs text-zinc-500">{t('role')}:</span>
                    <span className={`text-xs px-2 py-1 rounded font-medium ${
                      user?.role === 'superadmin' 
                        ? 'bg-amber-500/20 text-amber-400' 
                        : user?.role === 'admin'
                        ? 'bg-indigo-500/20 text-indigo-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {user?.role === 'superadmin' ? t('superadmin') : user?.role === 'admin' ? t('admin') : t('staff')}
                    </span>
                  </div>
                  <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-500">
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    {t('save')}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Change Password */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-amber-400" />
                  {t('changePassword')}
                </CardTitle>
                <CardDescription className="text-zinc-500">
                  {t('changePasswordDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-400">{t('currentPassword')}</Label>
                    <Input
                      type="password"
                      value={passwordChange.current_password}
                      onChange={(e) => setPasswordChange({ ...passwordChange, current_password: e.target.value })}
                      className="bg-zinc-900 border-white/10 text-white"
                      placeholder="••••••••"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-zinc-400">{t('newPassword')}</Label>
                      <Input
                        type="password"
                        value={passwordChange.new_password}
                        onChange={(e) => setPasswordChange({ ...passwordChange, new_password: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder="••••••••"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-zinc-400">{t('confirmPassword')}</Label>
                      <Input
                        type="password"
                        value={passwordChange.confirm_password}
                        onChange={(e) => setPasswordChange({ ...passwordChange, confirm_password: e.target.value })}
                        className="bg-zinc-900 border-white/10 text-white"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  <Button type="submit" disabled={saving} className="bg-amber-600 hover:bg-amber-500">
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Lock className="w-4 h-4 mr-2" />}
                    {t('changePassword')}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team Tab */}
          <TabsContent value="team" className="space-y-6">
            {/* Add Member Button */}
            {canManageMembers && (
              <div className="flex justify-end">
                <Button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className={showAddForm ? "bg-zinc-700" : "bg-indigo-600 hover:bg-indigo-500"}
                >
                  {showAddForm ? <X className="w-4 h-4 mr-2" /> : <UserPlus className="w-4 h-4 mr-2" />}
                  {showAddForm ? t('cancel') : `${t('addMember')} ${canCreateRole}`}
                </Button>
              </div>
            )}

            {/* Add Member Form */}
            {showAddForm && canManageMembers && (
              <Card className="bg-zinc-900/50 border-zinc-800 border-indigo-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-indigo-400" />
                    {t('addNewMember')} {canCreateRole}
                  </CardTitle>
                  <CardDescription className="text-zinc-500">
                    {isSuperadmin 
                      ? t('createAdminDesc')
                      : t('createStaffDesc')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddMember} className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label className="text-zinc-400">{t('name')} <span className="text-zinc-600">({t('optional')})</span></Label>
                        <Input
                          value={newMember.name}
                          onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-zinc-400">{t('username')} <span className="text-red-400">*</span></Label>
                        <Input
                          value={newMember.username}
                          onChange={(e) => setNewMember({ ...newMember, username: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="johndoe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-zinc-400">{t('password')} <span className="text-red-400">*</span></Label>
                        <Input
                          type="password"
                          value={newMember.password}
                          onChange={(e) => setNewMember({ ...newMember, password: e.target.value })}
                          className="bg-zinc-900 border-white/10 text-white"
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-zinc-500">
                      <span>{t('willBeCreatedAs')}:</span>
                      <span className={`px-2 py-0.5 rounded font-medium ${
                        canCreateRole === 'Admin' 
                          ? 'bg-indigo-500/20 text-indigo-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}>
                        {canCreateRole}
                      </span>
                    </div>
                    <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-500">
                      {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <UserPlus className="w-4 h-4 mr-2" />}
                      Add {canCreateRole}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            )}

            {/* Team Members List */}
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-400" />
                  Team Members ({members.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {members.map((member) => {
                    // Determine if current user can manage this member
                    const canManage = (
                      member.id !== user?.id && // Cannot manage self
                      member.role !== 'superadmin' && // Cannot manage superadmin
                      (
                        isSuperadmin || // Superadmin can manage admin & staff
                        (isAdmin && member.role === 'staff') // Admin can only manage staff
                      )
                    );
                    
                    return (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-4 bg-zinc-800/50 border border-white/5 rounded-lg"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            member.role === 'superadmin' 
                              ? 'bg-amber-500/20' 
                              : member.role === 'admin'
                              ? 'bg-indigo-500/20'
                              : 'bg-emerald-500/20'
                          }`}>
                            {member.role === 'superadmin' 
                              ? <Crown className="w-5 h-5 text-amber-400" />
                              : member.role === 'admin'
                              ? <Shield className="w-5 h-5 text-indigo-400" />
                              : <Briefcase className="w-5 h-5 text-emerald-400" />
                            }
                          </div>
                          <div>
                            <p className="text-sm font-medium text-white flex items-center gap-2">
                              {member.name || member.username}
                              {member.id === user?.id && (
                                <span className="text-xs bg-zinc-700 px-2 py-0.5 rounded text-zinc-400">You</span>
                              )}
                            </p>
                            <p className="text-xs text-zinc-500 flex items-center gap-1">
                              <User className="w-3 h-3" />
                              @{member.username}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`text-xs px-2 py-1 rounded font-medium ${
                            member.role === 'superadmin' 
                              ? 'bg-amber-500/20 text-amber-400' 
                              : member.role === 'admin'
                              ? 'bg-indigo-500/20 text-indigo-400'
                              : 'bg-emerald-500/20 text-emerald-400'
                          }`}>
                            {member.role === 'superadmin' ? 'Superadmin' : member.role === 'admin' ? 'Admin' : 'Staff'}
                          </span>
                          {canManage && (
                            <>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleResetPassword(member)}
                                className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                                title="Reset Password"
                              >
                                <Key className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteMember(member.id, member.name || member.username)}
                                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                title="Delete Member"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {!canManageMembers && (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <p className="text-sm text-amber-400 flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Staff members cannot add or remove team members
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      {/* Reset Password Modal */}
      <Dialog open={resetPasswordModal} onOpenChange={setResetPasswordModal}>
        <DialogContent className="bg-zinc-900 border-zinc-800">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-amber-400" />
              Reset Password
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-zinc-400">
              Reset password untuk <span className="font-medium text-white">{resetPasswordTarget?.name || resetPasswordTarget?.username}</span>
            </p>
            <div className="space-y-2">
              <Label className="text-zinc-400">Password Baru</Label>
              <Input
                type="password"
                value={newPasswordForMember}
                onChange={(e) => setNewPasswordForMember(e.target.value)}
                placeholder="Minimal 6 karakter"
                className="bg-zinc-800 border-zinc-700 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setResetPasswordModal(false)}
              className="text-zinc-400"
            >
              Batal
            </Button>
            <Button
              onClick={handleConfirmResetPassword}
              disabled={resettingPassword || !newPasswordForMember}
              className="bg-amber-600 hover:bg-amber-500"
            >
              {resettingPassword ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Key className="w-4 h-4 mr-2" />}
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
